import type { Express, Request } from "express";
import { createServer, type Server } from "http";
import multer from "multer";
import path from "path";
import { storage } from "./storage";
import { insertFileSchema, insertToolOperationSchema } from "@shared/schema";
import adminRoutes from "./admin-routes";

interface RequestWithFile extends Request {
  file?: Express.Multer.File;
  files?: Express.Multer.File[];
}

const upload = multer({ 
  dest: 'uploads/',
  limits: { fileSize: 100 * 1024 * 1024 } // 100MB limit
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Admin routes for ads management
  app.use("/api", adminRoutes);
  
  // File upload endpoint
  app.post("/api/upload", upload.single("file"), async (req: RequestWithFile, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      const { toolType } = req.body;
      if (!toolType) {
        return res.status(400).json({ message: "Tool type is required" });
      }

      const fileData = {
        filename: req.file.filename,
        originalName: req.file.originalname,
        mimetype: req.file.mimetype,
        size: req.file.size,
        userId: req.body.userId || null,
        toolType,
        status: "uploaded"
      };

      const file = await storage.createFile(fileData);
      res.json(file);
    } catch (error) {
      console.error("Upload error:", error);
      res.status(500).json({ message: "Upload failed" });
    }
  });

  // Multiple file upload endpoint
  app.post("/api/upload-multiple", upload.array("files", 10), async (req: RequestWithFile, res) => {
    try {
      if (!req.files || !Array.isArray(req.files) || req.files.length === 0) {
        return res.status(400).json({ message: "No files uploaded" });
      }

      const { toolType } = req.body;
      if (!toolType) {
        return res.status(400).json({ message: "Tool type is required" });
      }

      const uploadedFiles = [];
      for (const file of req.files) {
        const fileData = {
          filename: file.filename,
          originalName: file.originalname,
          mimetype: file.mimetype,
          size: file.size,
          userId: req.body.userId || null,
          toolType,
          status: "uploaded"
        };

        const savedFile = await storage.createFile(fileData);
        uploadedFiles.push(savedFile);
      }

      res.json(uploadedFiles);
    } catch (error) {
      console.error("Multiple upload error:", error);
      res.status(500).json({ message: "Upload failed" });
    }
  });

  // PDF Tools endpoints
  app.post("/api/pdf/merge", async (req, res) => {
    try {
      const { fileIds } = req.body;
      if (!fileIds || !Array.isArray(fileIds) || fileIds.length < 2) {
        return res.status(400).json({ message: "At least 2 files required for merging" });
      }

      // Create operation record
      const operation = await storage.createToolOperation({
        fileId: fileIds[0],
        operation: "merge",
        parameters: JSON.stringify({ fileIds }),
        status: "processing"
      });

      // Simulate processing
      setTimeout(async () => {
        await storage.updateToolOperationStatus(operation.id, "completed", `merged_${Date.now()}.pdf`);
      }, 2000);

      res.json({ operationId: operation.id, message: "PDF merge started" });
    } catch (error) {
      console.error("PDF merge error:", error);
      res.status(500).json({ message: "PDF merge failed" });
    }
  });

  app.post("/api/pdf/split", async (req, res) => {
    try {
      const { fileId, pages } = req.body;
      if (!fileId) {
        return res.status(400).json({ message: "File ID is required" });
      }

      const operation = await storage.createToolOperation({
        fileId,
        operation: "split",
        parameters: JSON.stringify({ pages }),
        status: "processing"
      });

      setTimeout(async () => {
        await storage.updateToolOperationStatus(operation.id, "completed", `split_${Date.now()}.pdf`);
      }, 1500);

      res.json({ operationId: operation.id, message: "PDF split started" });
    } catch (error) {
      console.error("PDF split error:", error);
      res.status(500).json({ message: "PDF split failed" });
    }
  });

  app.post("/api/pdf/compress", async (req, res) => {
    try {
      const { fileId, compressionLevel } = req.body;
      if (!fileId) {
        return res.status(400).json({ message: "File ID is required" });
      }

      const operation = await storage.createToolOperation({
        fileId,
        operation: "compress",
        parameters: JSON.stringify({ compressionLevel }),
        status: "processing"
      });

      setTimeout(async () => {
        await storage.updateToolOperationStatus(operation.id, "completed", `compressed_${Date.now()}.pdf`);
      }, 3000);

      res.json({ operationId: operation.id, message: "PDF compression started" });
    } catch (error) {
      console.error("PDF compress error:", error);
      res.status(500).json({ message: "PDF compression failed" });
    }
  });

  // Audio Tools endpoints
  app.post("/api/audio/convert", async (req, res) => {
    try {
      const { fileId, outputFormat } = req.body;
      if (!fileId || !outputFormat) {
        return res.status(400).json({ message: "File ID and output format are required" });
      }

      const operation = await storage.createToolOperation({
        fileId,
        operation: "convert",
        parameters: JSON.stringify({ outputFormat }),
        status: "processing"
      });

      setTimeout(async () => {
        await storage.updateToolOperationStatus(operation.id, "completed", `converted_${Date.now()}.${outputFormat}`);
      }, 2500);

      res.json({ operationId: operation.id, message: "Audio conversion started" });
    } catch (error) {
      console.error("Audio convert error:", error);
      res.status(500).json({ message: "Audio conversion failed" });
    }
  });

  app.post("/api/audio/enhance", async (req, res) => {
    try {
      const { fileId, enhancementType } = req.body;
      if (!fileId) {
        return res.status(400).json({ message: "File ID is required" });
      }

      const operation = await storage.createToolOperation({
        fileId,
        operation: "enhance",
        parameters: JSON.stringify({ enhancementType }),
        status: "processing"
      });

      setTimeout(async () => {
        await storage.updateToolOperationStatus(operation.id, "completed", `enhanced_${Date.now()}.mp3`);
      }, 4000);

      res.json({ operationId: operation.id, message: "Audio enhancement started" });
    } catch (error) {
      console.error("Audio enhance error:", error);
      res.status(500).json({ message: "Audio enhancement failed" });
    }
  });

  // Image Tools endpoints
  app.post("/api/image/resize", async (req, res) => {
    try {
      const { fileId, width, height } = req.body;
      if (!fileId || !width || !height) {
        return res.status(400).json({ message: "File ID, width, and height are required" });
      }

      const operation = await storage.createToolOperation({
        fileId,
        operation: "resize",
        parameters: JSON.stringify({ width, height }),
        status: "processing"
      });

      setTimeout(async () => {
        await storage.updateToolOperationStatus(operation.id, "completed", `resized_${Date.now()}.jpg`);
      }, 1000);

      res.json({ operationId: operation.id, message: "Image resize started" });
    } catch (error) {
      console.error("Image resize error:", error);
      res.status(500).json({ message: "Image resize failed" });
    }
  });

  app.post("/api/image/remove-background", async (req, res) => {
    try {
      const { fileId } = req.body;
      if (!fileId) {
        return res.status(400).json({ message: "File ID is required" });
      }

      const operation = await storage.createToolOperation({
        fileId,
        operation: "remove-background",
        parameters: JSON.stringify({}),
        status: "processing"
      });

      setTimeout(async () => {
        await storage.updateToolOperationStatus(operation.id, "completed", `no_bg_${Date.now()}.png`);
      }, 5000);

      res.json({ operationId: operation.id, message: "Background removal started" });
    } catch (error) {
      console.error("Background removal error:", error);
      res.status(500).json({ message: "Background removal failed" });
    }
  });

  // AI Tools endpoints
  app.post("/api/ai/generate-text", async (req, res) => {
    try {
      const { prompt, contentType } = req.body;
      if (!prompt) {
        return res.status(400).json({ message: "Prompt is required" });
      }

      // Simulate AI text generation
      setTimeout(() => {
        const generatedText = `This is AI-generated content based on your prompt: "${prompt}". The content would be much longer and more detailed in a real implementation.`;
        res.json({ generatedText, contentType });
      }, 3000);

    } catch (error) {
      console.error("AI text generation error:", error);
      res.status(500).json({ message: "AI text generation failed" });
    }
  });

  app.post("/api/ai/analyze-image", async (req, res) => {
    try {
      const { fileId, analysisType } = req.body;
      if (!fileId) {
        return res.status(400).json({ message: "File ID is required" });
      }

      setTimeout(() => {
        const analysis = {
          objects: ["person", "car", "building"],
          text: "Sample extracted text",
          description: "A photo showing various objects in an urban setting",
          colors: ["#FF5733", "#33FF57", "#3357FF"]
        };
        res.json({ analysis, analysisType });
      }, 2000);

    } catch (error) {
      console.error("AI image analysis error:", error);
      res.status(500).json({ message: "AI image analysis failed" });
    }
  });

  // Video Tools endpoints
  app.post("/api/video/convert", async (req, res) => {
    try {
      const { fileId, outputFormat } = req.body;
      if (!fileId || !outputFormat) {
        return res.status(400).json({ message: "File ID and output format are required" });
      }

      const operation = await storage.createToolOperation({
        fileId,
        operation: "convert",
        parameters: JSON.stringify({ outputFormat }),
        status: "processing"
      });

      setTimeout(async () => {
        await storage.updateToolOperationStatus(operation.id, "completed", `converted_${Date.now()}.${outputFormat}`);
      }, 8000);

      res.json({ operationId: operation.id, message: "Video conversion started" });
    } catch (error) {
      console.error("Video convert error:", error);
      res.status(500).json({ message: "Video conversion failed" });
    }
  });

  // Get operation status
  app.get("/api/operation/:id", async (req, res) => {
    try {
      const operation = await storage.getToolOperation(req.params.id);
      if (!operation) {
        return res.status(404).json({ message: "Operation not found" });
      }
      res.json(operation);
    } catch (error) {
      console.error("Get operation error:", error);
      res.status(500).json({ message: "Failed to get operation status" });
    }
  });

  // Download processed file
  app.get("/api/download/:filename", async (req, res) => {
    try {
      const filename = req.params.filename;
      const filePath = path.join(process.cwd(), 'uploads', filename);
      res.download(filePath);
    } catch (error) {
      console.error("Download error:", error);
      res.status(500).json({ message: "Download failed" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
