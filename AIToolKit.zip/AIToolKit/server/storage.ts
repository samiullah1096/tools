import { type User, type InsertUser, type File, type InsertFile, type ToolOperation, type InsertToolOperation } from "@shared/schema";
import { 
  type AdminUser, 
  type Advertisement, 
  type AdSlot,
  type InsertAdminUser, 
  type InsertAdvertisement, 
  type InsertAdSlot 
} from "@shared/ad-schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Admin operations
  createAdminUser(user: InsertAdminUser): Promise<AdminUser>;
  getAdminUser(username: string): Promise<AdminUser | undefined>;
  
  // Advertisement operations
  createAdvertisement(ad: InsertAdvertisement): Promise<Advertisement>;
  getAdvertisement(id: string): Promise<Advertisement | undefined>;
  getAdvertisementsBySlot(slotId: string): Promise<Advertisement[]>;
  getAllAdvertisements(): Promise<Advertisement[]>;
  updateAdvertisement(id: string, ad: Partial<InsertAdvertisement>): Promise<Advertisement>;
  deleteAdvertisement(id: string): Promise<void>;
  
  createFile(file: InsertFile): Promise<File>;
  getFile(id: string): Promise<File | undefined>;
  updateFileStatus(id: string, status: string, resultPath?: string): Promise<void>;
  getFilesByUserId(userId: string): Promise<File[]>;
  
  createToolOperation(operation: InsertToolOperation): Promise<ToolOperation>;
  getToolOperation(id: string): Promise<ToolOperation | undefined>;
  updateToolOperationStatus(id: string, status: string, resultPath?: string): Promise<void>;
  getOperationsByFileId(fileId: string): Promise<ToolOperation[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private files: Map<string, File>;
  private toolOperations: Map<string, ToolOperation>;
  private adminUsers: Map<string, AdminUser>;
  private advertisements: Map<string, Advertisement>;

  constructor() {
    this.users = new Map();
    this.files = new Map();
    this.toolOperations = new Map();
    this.adminUsers = new Map();
    this.advertisements = new Map();
    
    // Create default admin user
    this.createDefaultAdmin();
  }
  
  private async createDefaultAdmin() {
    const defaultAdmin: AdminUser = {
      id: randomUUID(),
      username: "admin",
      passwordHash: "$2b$10$N8V1H7/9Z2nzPq4X5J8P6.qSvW9kNhMU4YfGTcR3bJ1QvNx5Hy2K.", // password: admin123
      email: "admin@toolsuite.pro",
      role: "admin",
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.adminUsers.set(defaultAdmin.username, defaultAdmin);
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createFile(insertFile: InsertFile): Promise<File> {
    const id = randomUUID();
    const file: File = { 
      ...insertFile, 
      id, 
      status: insertFile.status || "pending",
      createdAt: new Date()
    };
    this.files.set(id, file);
    return file;
  }

  async getFile(id: string): Promise<File | undefined> {
    return this.files.get(id);
  }

  async updateFileStatus(id: string, status: string, resultPath?: string): Promise<void> {
    const file = this.files.get(id);
    if (file) {
      file.status = status;
      if (resultPath) {
        file.resultPath = resultPath;
      }
      this.files.set(id, file);
    }
  }

  async getFilesByUserId(userId: string): Promise<File[]> {
    return Array.from(this.files.values()).filter(file => file.userId === userId);
  }

  async createToolOperation(insertOperation: InsertToolOperation): Promise<ToolOperation> {
    const id = randomUUID();
    const operation: ToolOperation = { 
      ...insertOperation, 
      id,
      status: insertOperation.status || "pending",
      createdAt: new Date()
    };
    this.toolOperations.set(id, operation);
    return operation;
  }

  async getToolOperation(id: string): Promise<ToolOperation | undefined> {
    return this.toolOperations.get(id);
  }

  async updateToolOperationStatus(id: string, status: string, resultPath?: string): Promise<void> {
    const operation = this.toolOperations.get(id);
    if (operation) {
      operation.status = status;
      if (resultPath) {
        operation.resultPath = resultPath;
      }
      this.toolOperations.set(id, operation);
    }
  }

  async getOperationsByFileId(fileId: string): Promise<ToolOperation[]> {
    return Array.from(this.toolOperations.values()).filter(op => op.fileId === fileId);
  }
  
  // Admin operations
  async createAdminUser(insertAdminUser: InsertAdminUser): Promise<AdminUser> {
    const id = randomUUID();
    const admin: AdminUser = { 
      ...insertAdminUser, 
      id,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.adminUsers.set(admin.username, admin);
    return admin;
  }

  async getAdminUser(username: string): Promise<AdminUser | undefined> {
    return this.adminUsers.get(username);
  }
  
  // Advertisement operations
  async createAdvertisement(insertAd: InsertAdvertisement): Promise<Advertisement> {
    const id = randomUUID();
    const ad: Advertisement = { 
      ...insertAd, 
      id,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.advertisements.set(id, ad);
    return ad;
  }

  async getAdvertisement(id: string): Promise<Advertisement | undefined> {
    return this.advertisements.get(id);
  }

  async getAdvertisementsBySlot(slotId: string): Promise<Advertisement[]> {
    return Array.from(this.advertisements.values()).filter(
      (ad) => ad.slotId === slotId
    );
  }

  async getAllAdvertisements(): Promise<Advertisement[]> {
    return Array.from(this.advertisements.values());
  }

  async updateAdvertisement(id: string, updateData: Partial<InsertAdvertisement>): Promise<Advertisement> {
    const ad = this.advertisements.get(id);
    if (!ad) {
      throw new Error(`Advertisement with id ${id} not found`);
    }
    
    const updatedAd: Advertisement = {
      ...ad,
      ...updateData,
      updatedAt: new Date()
    };
    this.advertisements.set(id, updatedAd);
    return updatedAd;
  }

  async deleteAdvertisement(id: string): Promise<void> {
    if (!this.advertisements.has(id)) {
      throw new Error(`Advertisement with id ${id} not found`);
    }
    this.advertisements.delete(id);
  }
}

export const storage = new MemStorage();
