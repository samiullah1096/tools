import { Router } from 'express';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { storage } from './storage';
import { insertAdvertisementSchema } from '@shared/ad-schema';

const router = Router();
const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';

// Admin authentication middleware
async function authenticateAdmin(req: any, res: any, next: any) {
  const token = req.headers.authorization?.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ message: 'No token provided' });
  }
  
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as any;
    const admin = await storage.getAdminUser(decoded.username);
    
    if (!admin || !admin.isActive) {
      return res.status(401).json({ message: 'Invalid or inactive admin' });
    }
    
    req.admin = admin;
    next();
  } catch (error) {
    return res.status(401).json({ message: 'Invalid token' });
  }
}

// Admin login
router.post('/admin/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    
    const admin = await storage.getAdminUser(username);
    if (!admin) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }
    
    const isValid = await bcrypt.compare(password, admin.passwordHash);
    if (!isValid) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }
    
    const token = jwt.sign({ username: admin.username }, JWT_SECRET, { expiresIn: '24h' });
    
    res.json({
      token,
      admin: {
        id: admin.id,
        username: admin.username,
        email: admin.email,
        role: admin.role
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ message: 'Login failed' });
  }
});

// Get all advertisements
router.get('/admin/ads', authenticateAdmin, async (req, res) => {
  try {
    const ads = await storage.getAllAdvertisements();
    res.json(ads);
  } catch (error) {
    console.error('Failed to fetch ads:', error);
    res.status(500).json({ message: 'Failed to fetch advertisements' });
  }
});

// Create advertisement
router.post('/admin/ads', authenticateAdmin, async (req: any, res) => {
  try {
    const adData = insertAdvertisementSchema.parse({
      ...req.body,
      createdBy: req.admin.id
    });
    
    const ad = await storage.createAdvertisement(adData);
    res.status(201).json(ad);
  } catch (error) {
    console.error('Failed to create ad:', error);
    res.status(400).json({ message: 'Failed to create advertisement' });
  }
});

// Update advertisement
router.put('/admin/ads/:id', authenticateAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    const adData = req.body;
    
    const ad = await storage.updateAdvertisement(id, adData);
    res.json(ad);
  } catch (error) {
    console.error('Failed to update ad:', error);
    res.status(400).json({ message: 'Failed to update advertisement' });
  }
});

// Delete advertisement
router.delete('/admin/ads/:id', authenticateAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    await storage.deleteAdvertisement(id);
    res.status(204).send();
  } catch (error) {
    console.error('Failed to delete ad:', error);
    res.status(500).json({ message: 'Failed to delete advertisement' });
  }
});

// Public route to get ads for a specific slot
router.get('/ads/:slotId', async (req, res) => {
  try {
    const { slotId } = req.params;
    const ads = await storage.getAdvertisementsBySlot(slotId);
    
    // Return only active ads and pick one randomly if multiple exist
    const activeAds = ads.filter(ad => ad.active);
    
    if (activeAds.length === 0) {
      return res.status(404).json({ message: 'No active ads found for this slot' });
    }
    
    // Pick random ad if multiple exist
    const randomAd = activeAds[Math.floor(Math.random() * activeAds.length)];
    res.json(randomAd);
  } catch (error) {
    console.error('Failed to fetch ad:', error);
    res.status(404).json({ message: 'Ad not found' });
  }
});

export default router;