import { sql } from 'drizzle-orm';
import {
  boolean,
  pgTable,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Admin users table for authentication
export const adminUsers = pgTable("admin_users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: varchar("username").unique().notNull(),
  passwordHash: varchar("password_hash").notNull(),
  email: varchar("email").unique(),
  role: varchar("role").default("admin"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Advertisements table
export const advertisements = pgTable("advertisements", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  slotId: varchar("slot_id").notNull(),
  title: varchar("title").notNull(),
  description: text("description"),
  provider: varchar("provider").notNull(), // 'google', 'custom', 'html'
  code: text("code"), // For Google AdSense or other code-based ads
  imageUrl: varchar("image_url"), // For custom image ads
  clickUrl: varchar("click_url"), // For custom ads
  htmlContent: text("html_content"), // For custom HTML ads
  active: boolean("active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  createdBy: varchar("created_by").references(() => adminUsers.id),
});

// Ad slots configuration
export const adSlots = pgTable("ad_slots", {
  id: varchar("id").primaryKey(),
  name: varchar("name").notNull(),
  position: varchar("position").notNull(), // 'header', 'sidebar', 'content', 'footer', 'modal'
  size: varchar("size").notNull(), // 'small', 'medium', 'large', 'banner', 'skyscraper', 'square'
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Types
export type AdminUser = typeof adminUsers.$inferSelect;
export type Advertisement = typeof advertisements.$inferSelect;
export type AdSlot = typeof adSlots.$inferSelect;

// Insert schemas
export const insertAdminUserSchema = createInsertSchema(adminUsers).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertAdvertisementSchema = createInsertSchema(advertisements).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertAdSlotSchema = createInsertSchema(adSlots).omit({
  createdAt: true,
});

// Insert types
export type InsertAdminUser = z.infer<typeof insertAdminUserSchema>;
export type InsertAdvertisement = z.infer<typeof insertAdvertisementSchema>;
export type InsertAdSlot = z.infer<typeof insertAdSlotSchema>;