import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const files = pgTable("files", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  filename: text("filename").notNull(),
  originalName: text("original_name").notNull(),
  mimetype: text("mimetype").notNull(),
  size: integer("size").notNull(),
  userId: varchar("user_id"),
  toolType: text("tool_type").notNull(), // 'pdf', 'audio', 'image', 'ai', 'video', 'text', 'converter', 'productivity', 'developer', 'security'
  status: text("status").notNull().default("pending"), // 'pending', 'processing', 'completed', 'failed'
  resultPath: text("result_path"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const toolOperations = pgTable("tool_operations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fileId: varchar("file_id").notNull(),
  operation: text("operation").notNull(), // 'merge', 'split', 'compress', etc.
  parameters: text("parameters"), // JSON string of operation parameters
  status: text("status").notNull().default("pending"),
  resultPath: text("result_path"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertFileSchema = createInsertSchema(files).omit({
  id: true,
  createdAt: true,
});

export const insertToolOperationSchema = createInsertSchema(toolOperations).omit({
  id: true,
  createdAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertFile = z.infer<typeof insertFileSchema>;
export type File = typeof files.$inferSelect;
export type InsertToolOperation = z.infer<typeof insertToolOperationSchema>;
export type ToolOperation = typeof toolOperations.$inferSelect;
