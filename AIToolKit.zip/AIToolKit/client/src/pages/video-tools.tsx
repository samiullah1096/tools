import { useState } from "react";
import { motion } from "framer-motion";
import { 
  Video, 
  RotateCcw, 
  Combine, 
  Scissors, 
  Music, 
  Layers, 
  Sparkles,
  Loader2
} from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import ToolCard from "@/components/ui/tool-card";
import UploadZone from "@/components/ui/upload-zone";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { pageTransition, staggerContainer } from "@/lib/animations";

export default function VideoTools() {
  const { toast } = useToast();
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);

  const processMutation = useMutation({
    mutationFn: async (data: { files: File[], operation: string, params?: any }) => {
      const formData = new FormData();
      data.files.forEach(file => formData.append('files', file));
      formData.append('toolType', 'video');
      formData.append('operation', data.operation);
      if (data.params) {
        formData.append('params', JSON.stringify(data.params));
      }
      
      return apiRequest('POST', '/api/upload-multiple', formData);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Video processing started successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to process video. Please try again.",
        variant: "destructive",
      });
    },
  });

  return (
    <motion.div {...pageTransition}>
      <section className="py-20">
        <div className="container mx-auto px-6">
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="w-20 h-20 bg-gradient-to-r from-orange-500 to-red-500 rounded-2xl flex items-center justify-center mx-auto mb-6 animate-float">
              <Video className="text-3xl text-white" />
            </div>
            <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-orange-400 to-red-400 bg-clip-text text-transparent">
              Video Suite
            </h1>
            <p className="text-xl text-slate-300 max-w-2xl mx-auto">
              Professional video processing with compression, conversion, and enhancement tools
            </p>
          </motion.div>

          <motion.div 
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
            variants={staggerContainer}
            initial="initial"
            animate="animate"
          >
            {/* Video Converter */}
            <ToolCard
              icon={<RotateCcw className="text-2xl text-white" />}
              title="Format Converter"
              description="Convert between MP4, AVI, MOV, WebM and other video formats."
              gradient="bg-gradient-to-r from-orange-500 to-red-500"
              delay={0.1}
            >
              <UploadZone
                onFilesSelected={setSelectedFiles}
                accept={{ 'video/*': ['.mp4', '.avi', '.mov', '.webm', '.mkv'] }}
                multiple={false}
                icon={<Video className="w-8 h-8" />}
                title="Upload video to convert"
              />
              
              <div className="mb-4">
                <Label className="block text-sm font-medium text-slate-300 mb-2">Output Format</Label>
                <Select defaultValue="mp4">
                  <SelectTrigger className="w-full bg-slate-800 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="mp4">MP4</SelectItem>
                    <SelectItem value="avi">AVI</SelectItem>
                    <SelectItem value="mov">MOV</SelectItem>
                    <SelectItem value="webm">WebM</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <Button 
                onClick={() => processMutation.mutate({ files: selectedFiles, operation: 'convert', params: { format: 'mp4' } })}
                disabled={processMutation.isPending || selectedFiles.length !== 1}
                className="w-full py-3 bg-gradient-to-r from-orange-500 to-red-500 rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
              >
                {processMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <RotateCcw className="mr-2 h-4 w-4" />
                )}
                Convert Video
              </Button>
            </ToolCard>

            {/* Video Compressor */}
            <ToolCard
              icon={<Combine className="text-2xl text-white" />}
              title="Video Compressor"
              description="Reduce video file size while maintaining optimal quality."
              gradient="bg-gradient-to-r from-red-500 to-pink-500"
              delay={0.2}
            >
              <UploadZone
                onFilesSelected={setSelectedFiles}
                accept={{ 'video/*': ['.mp4', '.avi', '.mov', '.webm'] }}
                multiple={false}
                icon={<Combine className="w-8 h-8" />}
                title="Upload video to compress"
              />
              
              <div className="mb-4">
                <Label className="block text-sm font-medium text-slate-300 mb-2">Compression Level</Label>
                <Select defaultValue="balanced">
                  <SelectTrigger className="w-full bg-slate-800 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="light">Light (High Quality)</SelectItem>
                    <SelectItem value="balanced">Medium (Balanced)</SelectItem>
                    <SelectItem value="strong">Strong (Small Size)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <Button 
                onClick={() => processMutation.mutate({ files: selectedFiles, operation: 'compress' })}
                disabled={processMutation.isPending || selectedFiles.length !== 1}
                className="w-full py-3 bg-gradient-to-r from-red-500 to-pink-500 rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
              >
                {processMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Combine className="mr-2 h-4 w-4" />
                )}
                Combine Video
              </Button>
            </ToolCard>

            {/* Video Trimmer */}
            <ToolCard
              icon={<Scissors className="text-2xl text-white" />}
              title="Video Trimmer"
              description="Cut and trim videos with frame-perfect precision."
              gradient="bg-gradient-to-r from-purple-500 to-violet-500"
              delay={0.3}
            >
              <UploadZone
                onFilesSelected={setSelectedFiles}
                accept={{ 'video/*': ['.mp4', '.avi', '.mov', '.webm'] }}
                multiple={false}
                icon={<Scissors className="w-8 h-8" />}
                title="Upload video to trim"
              />
              
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <Label className="block text-sm font-medium text-slate-300 mb-2">Start Time</Label>
                  <Input 
                    type="text" 
                    className="w-full bg-slate-800 border-slate-600 text-white" 
                    placeholder="00:00:00" 
                  />
                </div>
                <div>
                  <Label className="block text-sm font-medium text-slate-300 mb-2">End Time</Label>
                  <Input 
                    type="text" 
                    className="w-full bg-slate-800 border-slate-600 text-white" 
                    placeholder="00:01:30" 
                  />
                </div>
              </div>
              
              <Button 
                onClick={() => processMutation.mutate({ files: selectedFiles, operation: 'trim' })}
                disabled={processMutation.isPending || selectedFiles.length !== 1}
                className="w-full py-3 bg-gradient-to-r from-purple-500 to-violet-500 rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
              >
                {processMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Scissors className="mr-2 h-4 w-4" />
                )}
                Trim Video
              </Button>
            </ToolCard>

            {/* Video to Audio */}
            <ToolCard
              icon={<Music className="text-2xl text-white" />}
              title="Extract Audio"
              description="Extract audio tracks from videos in various formats."
              gradient="bg-gradient-to-r from-blue-500 to-cyan-500"
              delay={0.4}
            >
              <UploadZone
                onFilesSelected={setSelectedFiles}
                accept={{ 'video/*': ['.mp4', '.avi', '.mov', '.webm'] }}
                multiple={false}
                icon={<Music className="w-8 h-8" />}
                title="Upload video file"
              />
              
              <div className="mb-4">
                <Label className="block text-sm font-medium text-slate-300 mb-2">Audio Format</Label>
                <Select defaultValue="mp3">
                  <SelectTrigger className="w-full bg-slate-800 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="mp3">MP3</SelectItem>
                    <SelectItem value="wav">WAV</SelectItem>
                    <SelectItem value="aac">AAC</SelectItem>
                    <SelectItem value="flac">FLAC</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <Button 
                onClick={() => processMutation.mutate({ files: selectedFiles, operation: 'extract-audio' })}
                disabled={processMutation.isPending || selectedFiles.length !== 1}
                className="w-full py-3 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
              >
                {processMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Music className="mr-2 h-4 w-4" />
                )}
                Extract Audio
              </Button>
            </ToolCard>

            {/* Video Merger */}
            <ToolCard
              icon={<Layers className="text-2xl text-white" />}
              title="Video Merger"
              description="Combine multiple videos into one seamless file."
              gradient="bg-gradient-to-r from-green-500 to-teal-500"
              delay={0.5}
            >
              <UploadZone
                onFilesSelected={setSelectedFiles}
                accept={{ 'video/*': ['.mp4', '.avi', '.mov', '.webm'] }}
                multiple={true}
                icon={<Layers className="w-8 h-8" />}
                title="Select multiple video files"
              />
              
              <div className="mb-4">
                <Label className="block text-sm font-medium text-slate-300 mb-2">Transition Type</Label>
                <Select defaultValue="none">
                  <SelectTrigger className="w-full bg-slate-800 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">None</SelectItem>
                    <SelectItem value="fade">Fade</SelectItem>
                    <SelectItem value="dissolve">Dissolve</SelectItem>
                    <SelectItem value="wipe">Wipe</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <Button 
                onClick={() => processMutation.mutate({ files: selectedFiles, operation: 'merge' })}
                disabled={processMutation.isPending || selectedFiles.length < 2}
                className="w-full py-3 bg-gradient-to-r from-green-500 to-teal-500 rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
              >
                {processMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Layers className="mr-2 h-4 w-4" />
                )}
                Merge Videos
              </Button>
            </ToolCard>

            {/* Video Enhancer */}
            <ToolCard
              icon={<Sparkles className="text-2xl text-white" />}
              title="AI Enhance"
              description="Improve video quality with AI-powered enhancement algorithms."
              gradient="bg-gradient-to-r from-indigo-500 to-purple-500"
              delay={0.6}
            >
              <UploadZone
                onFilesSelected={setSelectedFiles}
                accept={{ 'video/*': ['.mp4', '.avi', '.mov', '.webm'] }}
                multiple={false}
                icon={<Sparkles className="w-8 h-8" />}
                title="Upload video to enhance"
              />
              
              <div className="mb-4">
                <Label className="block text-sm font-medium text-slate-300 mb-2">Enhancement Type</Label>
                <Select defaultValue="upscale">
                  <SelectTrigger className="w-full bg-slate-800 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="upscale">Upscale Resolution</SelectItem>
                    <SelectItem value="stabilize">Stabilize Video</SelectItem>
                    <SelectItem value="colors">Improve Colors</SelectItem>
                    <SelectItem value="denoise">Reduce Noise</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <Button 
                onClick={() => processMutation.mutate({ files: selectedFiles, operation: 'enhance' })}
                disabled={processMutation.isPending || selectedFiles.length !== 1}
                className="w-full py-3 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
              >
                {processMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Sparkles className="mr-2 h-4 w-4" />
                )}
                Enhance Video
              </Button>
            </ToolCard>
          </motion.div>
        </div>
      </section>
    </motion.div>
  );
}
