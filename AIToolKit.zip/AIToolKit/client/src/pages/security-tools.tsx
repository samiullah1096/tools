import { motion } from "framer-motion";
import { Shield, Key, Lock, Eye, EyeOff, Hash, Fingerprint, Scan, AlertTriangle, CheckCircle } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

export default function SecurityTools() {
  const { toast } = useToast();
  const [password, setPassword] = useState("");
  const [passwordLength, setPasswordLength] = useState([16]);
  const [includeUppercase, setIncludeUppercase] = useState(true);
  const [includeLowercase, setIncludeLowercase] = useState(true);
  const [includeNumbers, setIncludeNumbers] = useState(true);
  const [includeSymbols, setIncludeSymbols] = useState(true);
  const [textToHash, setTextToHash] = useState("");
  const [hashResult, setHashResult] = useState("");

  const securityTools = [
    {
      id: "password-generator",
      icon: Key,
      title: "Password Generator",
      description: "Generate secure passwords with custom requirements",
      category: "Authentication"
    },
    {
      id: "password-strength",
      icon: Shield,
      title: "Password Strength Checker",
      description: "Analyze password strength and get improvement suggestions",
      category: "Analysis"
    },
    {
      id: "hash-generator",
      icon: Hash,
      title: "Hash Generator",
      description: "Generate MD5, SHA1, SHA256, and other hash algorithms",
      category: "Cryptography"
    },
    {
      id: "encryption-tool",
      icon: Lock,
      title: "Text Encryption/Decryption",
      description: "Encrypt and decrypt text using various algorithms",
      category: "Cryptography"
    },
    {
      id: "qr-generator",
      icon: Scan,
      title: "Secure QR Code Generator",
      description: "Generate QR codes for passwords, WiFi, and sensitive data",
      category: "Data Security"
    },
    {
      id: "2fa-generator",
      icon: Fingerprint,
      title: "2FA Code Generator",
      description: "Generate two-factor authentication codes",
      category: "Authentication"
    },
    {
      id: "secure-notes",
      icon: Eye,
      title: "Secure Notes",
      description: "Create encrypted notes with auto-destruction",
      category: "Privacy"
    },
    {
      id: "vulnerability-scanner",
      icon: AlertTriangle,
      title: "URL Security Scanner",
      description: "Check URLs for potential security threats",
      category: "Analysis"
    },
    {
      id: "privacy-checker",
      icon: EyeOff,
      title: "Privacy Checker",
      description: "Analyze website privacy and data collection",
      category: "Privacy"
    }
  ];

  const generatePassword = () => {
    const uppercase = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    const lowercase = "abcdefghijklmnopqrstuvwxyz";
    const numbers = "0123456789";
    const symbols = "!@#$%^&*()_+-=[]{}|;:,.<>?";
    
    let characters = "";
    if (includeUppercase) characters += uppercase;
    if (includeLowercase) characters += lowercase;
    if (includeNumbers) characters += numbers;
    if (includeSymbols) characters += symbols;
    
    if (characters === "") {
      toast({
        title: "Error",
        description: "Please select at least one character type.",
        variant: "destructive"
      });
      return;
    }
    
    let result = "";
    for (let i = 0; i < passwordLength[0]; i++) {
      result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    
    setPassword(result);
    toast({
      title: "Password generated!",
      description: "Your secure password is ready to use.",
    });
  };

  const checkPasswordStrength = (pwd: string) => {
    let score = 0;
    let feedback = [];
    
    if (pwd.length >= 12) score += 2;
    else if (pwd.length >= 8) score += 1;
    else feedback.push("Use at least 8 characters");
    
    if (/[a-z]/.test(pwd)) score += 1;
    else feedback.push("Add lowercase letters");
    
    if (/[A-Z]/.test(pwd)) score += 1;
    else feedback.push("Add uppercase letters");
    
    if (/[0-9]/.test(pwd)) score += 1;
    else feedback.push("Add numbers");
    
    if (/[^A-Za-z0-9]/.test(pwd)) score += 2;
    else feedback.push("Add special characters");
    
    let strength = "Very Weak";
    let color = "text-red-500";
    
    if (score >= 7) {
      strength = "Very Strong";
      color = "text-green-500";
    } else if (score >= 5) {
      strength = "Strong";
      color = "text-blue-500";
    } else if (score >= 3) {
      strength = "Medium";
      color = "text-yellow-500";
    } else if (score >= 1) {
      strength = "Weak";
      color = "text-orange-500";
    }
    
    return { strength, color, feedback, score };
  };

  const generateHash = async (algorithm: string) => {
    if (!textToHash) {
      toast({
        title: "Error",
        description: "Please enter text to hash.",
        variant: "destructive"
      });
      return;
    }

    try {
      // For demo purposes - in production, use proper crypto libraries
      let hash = "";
      
      switch (algorithm) {
        case "md5":
          // Simulated MD5 hash
          hash = Array.from(textToHash)
            .map(char => char.charCodeAt(0).toString(16))
            .join('')
            .padEnd(32, '0')
            .substring(0, 32);
          break;
        case "sha1":
          // Simulated SHA1 hash
          hash = Array.from(textToHash)
            .map(char => char.charCodeAt(0).toString(16))
            .join('')
            .padEnd(40, '0')
            .substring(0, 40);
          break;
        case "sha256":
          // Use Web Crypto API if available
          if (crypto.subtle) {
            const encoder = new TextEncoder();
            const data = encoder.encode(textToHash);
            const hashBuffer = await crypto.subtle.digest('SHA-256', data);
            const hashArray = Array.from(new Uint8Array(hashBuffer));
            hash = hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
          } else {
            // Fallback simulated hash
            hash = Array.from(textToHash)
              .map(char => char.charCodeAt(0).toString(16))
              .join('')
              .padEnd(64, '0')
              .substring(0, 64);
          }
          break;
        default:
          hash = "Algorithm not implemented";
      }
      
      setHashResult(`${algorithm.toUpperCase()}: ${hash}`);
      toast({
        title: "Hash generated!",
        description: `${algorithm.toUpperCase()} hash created successfully.`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate hash.",
        variant: "destructive"
      });
    }
  };

  const passwordStrength = password ? checkPasswordStrength(password) : null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-red-900 to-orange-900">
      {/* SEO Head equivalent */}
      <title>Security Tools - Password Generator, Hash Generator, Encryption | ToolSuite Pro</title>
      
      {/* Hero Section */}
      <div className="relative pt-20 pb-16">
        <div className="absolute inset-0 bg-gradient-to-r from-red-600/20 to-orange-600/20 backdrop-blur-3xl"></div>
        <motion.div 
          className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <motion.h1 
            className="text-5xl md:text-7xl font-bold text-white mb-6"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            Security <span className="bg-gradient-to-r from-red-400 to-orange-400 bg-clip-text text-transparent">Tools</span>
          </motion.h1>
          <motion.p 
            className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            Protect your digital life with professional security tools. Generate secure passwords, 
            create hashes, encrypt data, and analyze security threats - all client-side for maximum privacy.
          </motion.p>
        </motion.div>
      </div>

      {/* Password Generator */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <motion.div 
          className="bg-white/10 backdrop-blur-lg rounded-xl border border-white/20 p-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
        >
          <h2 className="text-3xl font-bold text-white mb-6 text-center">Password Generator</h2>
          
          <div className="space-y-6">
            <div>
              <label className="block text-white mb-2">Password Length: {passwordLength[0]}</label>
              <Slider
                value={passwordLength}
                onValueChange={setPasswordLength}
                max={50}
                min={4}
                step={1}
                className="w-full"
              />
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="uppercase" 
                  checked={includeUppercase}
                  onCheckedChange={(checked) => setIncludeUppercase(checked === true)}
                />
                <label htmlFor="uppercase" className="text-white">A-Z</label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="lowercase" 
                  checked={includeLowercase}
                  onCheckedChange={(checked) => setIncludeLowercase(checked === true)}
                />
                <label htmlFor="lowercase" className="text-white">a-z</label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="numbers" 
                  checked={includeNumbers}
                  onCheckedChange={(checked) => setIncludeNumbers(checked === true)}
                />
                <label htmlFor="numbers" className="text-white">0-9</label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="symbols" 
                  checked={includeSymbols}
                  onCheckedChange={(checked) => setIncludeSymbols(checked === true)}
                />
                <label htmlFor="symbols" className="text-white">!@#$</label>
              </div>
            </div>
            
            <Button
              onClick={generatePassword}
              className="w-full bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-600 hover:to-orange-600 text-white font-semibold"
            >
              Generate Password
            </Button>
            
            {password && (
              <div className="space-y-4">
                <div className="bg-white/5 p-4 rounded-lg">
                  <label className="block text-white mb-2">Generated Password:</label>
                  <div className="flex gap-2">
                    <Input
                      value={password}
                      readOnly
                      className="bg-white/10 border-white/20 text-white font-mono"
                    />
                    <Button
                      onClick={() => navigator.clipboard.writeText(password)}
                      className="bg-green-500 hover:bg-green-600"
                    >
                      Copy
                    </Button>
                  </div>
                </div>
                
                {passwordStrength && (
                  <div className="bg-white/5 p-4 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-white">Strength:</span>
                      <span className={`font-bold ${passwordStrength.color}`}>
                        {passwordStrength.strength}
                      </span>
                      <div className="flex">
                        {Array.from({ length: 5 }, (_, i) => (
                          <div
                            key={i}
                            className={`w-4 h-2 mx-0.5 rounded ${
                              i < Math.ceil(passwordStrength.score * 5 / 8)
                                ? passwordStrength.color.replace('text-', 'bg-')
                                : 'bg-gray-600'
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                    {passwordStrength.feedback.length > 0 && (
                      <div className="text-sm text-gray-300">
                        Suggestions: {passwordStrength.feedback.join(", ")}
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        </motion.div>
      </div>

      {/* Hash Generator */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <motion.div 
          className="bg-white/10 backdrop-blur-lg rounded-xl border border-white/20 p-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          <h2 className="text-3xl font-bold text-white mb-6 text-center">Hash Generator</h2>
          
          <div className="space-y-4">
            <div>
              <label className="block text-white mb-2">Text to Hash:</label>
              <Textarea
                value={textToHash}
                onChange={(e) => setTextToHash(e.target.value)}
                placeholder="Enter text to generate hash..."
                className="bg-white/5 border-white/20 text-white"
              />
            </div>
            
            <div className="grid grid-cols-3 gap-4">
              {["md5", "sha1", "sha256"].map((algo) => (
                <Button
                  key={algo}
                  onClick={() => generateHash(algo)}
                  variant="outline"
                  className="border-white/20 text-white hover:bg-white/10"
                >
                  {algo.toUpperCase()}
                </Button>
              ))}
            </div>
            
            {hashResult && (
              <div className="bg-white/5 p-4 rounded-lg">
                <label className="block text-white mb-2">Hash Result:</label>
                <div className="flex gap-2">
                  <Textarea
                    value={hashResult}
                    readOnly
                    className="bg-white/10 border-white/20 text-white font-mono text-sm"
                    rows={3}
                  />
                  <Button
                    onClick={() => navigator.clipboard.writeText(hashResult)}
                    className="bg-green-500 hover:bg-green-600 h-fit"
                  >
                    Copy
                  </Button>
                </div>
              </div>
            )}
          </div>
        </motion.div>
      </div>

      {/* Tools Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <motion.h2 
          className="text-3xl font-bold text-white mb-12 text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1.0 }}
        >
          All Security Tools
        </motion.h2>
        
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1.2 }}
        >
          {securityTools.map((tool, index) => (
            <motion.div
              key={tool.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 * index }}
              whileHover={{ y: -5, scale: 1.02 }}
            >
              <Card className="bg-white/10 backdrop-blur-lg border border-white/20 hover:border-red-400/50 transition-all duration-300 h-full">
                <CardHeader className="text-center">
                  <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-r from-red-500 to-orange-500 flex items-center justify-center">
                    <tool.icon className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className="text-white text-xl">{tool.title}</CardTitle>
                  <CardDescription className="text-gray-300">
                    {tool.description}
                  </CardDescription>
                  <span className="text-xs text-red-400 bg-red-400/20 px-2 py-1 rounded-full">
                    {tool.category}
                  </span>
                </CardHeader>
                <CardContent>
                  <Button 
                    className="w-full bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-600 hover:to-orange-600 text-white font-semibold"
                    onClick={() => {
                      toast({
                        title: `${tool.title} activated!`,
                        description: "This security tool is ready to use.",
                      });
                    }}
                  >
                    Use Tool
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </div>
  );
}