import { useState } from "react";
import { motion } from "framer-motion";
import { 
  Image as ImageIcon, 
  Wand2, 
  Expand, 
  RotateCcw, 
  Combine, 
  Crop,
  Sparkles,
  Loader2
} from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import ToolCard from "@/components/ui/tool-card";
import UploadZone from "@/components/ui/upload-zone";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { pageTransition, staggerContainer } from "@/lib/animations";

export default function ImageTools() {
  const { toast } = useToast();
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);

  const processMutation = useMutation({
    mutationFn: async (data: { files: File[], operation: string, params?: any }) => {
      const formData = new FormData();
      data.files.forEach(file => formData.append('files', file));
      formData.append('toolType', 'image');
      formData.append('operation', data.operation);
      if (data.params) {
        formData.append('params', JSON.stringify(data.params));
      }
      
      return apiRequest('POST', '/api/upload-multiple', formData);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Image processing started successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to process image. Please try again.",
        variant: "destructive",
      });
    },
  });

  return (
    <motion.div {...pageTransition}>
      <section className="py-20">
        <div className="container mx-auto px-6">
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="w-20 h-20 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center mx-auto mb-6 animate-float">
              <ImageIcon className="text-3xl text-white" />
            </div>
            <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              Image Editor
            </h1>
            <p className="text-xl text-slate-300 max-w-2xl mx-auto">
              Advanced image processing with AI-powered enhancement and professional editing tools
            </p>
          </motion.div>

          <motion.div 
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
            variants={staggerContainer}
            initial="initial"
            animate="animate"
          >
            {/* Background Remover */}
            <ToolCard
              icon={<Wand2 className="text-2xl text-white" />}
              title="Remove Background"
              description="AI-powered background removal with pixel-perfect precision."
              gradient="bg-gradient-to-r from-purple-500 to-violet-500"
              delay={0.1}
            >
              <UploadZone
                onFilesSelected={setSelectedFiles}
                accept={{ 'image/*': ['.jpg', '.jpeg', '.png', '.webp'] }}
                multiple={false}
                icon={<Wand2 className="w-8 h-8" />}
                title="Upload image to process"
              />
              
              <div className="mb-4">
                <Label className="block text-sm font-medium text-slate-300 mb-2">Edge Smoothing</Label>
                <Slider defaultValue={[5]} max={10} step={1} className="w-full" />
              </div>
              
              <Button 
                onClick={() => processMutation.mutate({ files: selectedFiles, operation: 'remove-background' })}
                disabled={processMutation.isPending || selectedFiles.length !== 1}
                className="w-full py-3 bg-gradient-to-r from-purple-500 to-violet-500 rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
              >
                {processMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Wand2 className="mr-2 h-4 w-4" />
                )}
                Remove Background
              </Button>
            </ToolCard>

            {/* Image Resizer */}
            <ToolCard
              icon={<Expand className="text-2xl text-white" />}
              title="Resize Images"
              description="Resize images while maintaining quality with smart scaling."
              gradient="bg-gradient-to-r from-blue-500 to-cyan-500"
              delay={0.2}
            >
              <UploadZone
                onFilesSelected={setSelectedFiles}
                accept={{ 'image/*': ['.jpg', '.jpeg', '.png', '.webp'] }}
                multiple={true}
                icon={<Expand className="w-8 h-8" />}
                title="Upload images to resize"
              />
              
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <Label className="block text-sm font-medium text-slate-300 mb-2">Width (px)</Label>
                  <Input 
                    type="number" 
                    className="w-full bg-slate-800 border-slate-600 text-white" 
                    placeholder="800" 
                  />
                </div>
                <div>
                  <Label className="block text-sm font-medium text-slate-300 mb-2">Height (px)</Label>
                  <Input 
                    type="number" 
                    className="w-full bg-slate-800 border-slate-600 text-white" 
                    placeholder="600" 
                  />
                </div>
              </div>
              
              <Button 
                onClick={() => processMutation.mutate({ files: selectedFiles, operation: 'resize' })}
                disabled={processMutation.isPending || selectedFiles.length === 0}
                className="w-full py-3 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
              >
                {processMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Expand className="mr-2 h-4 w-4" />
                )}
                Resize Images
              </Button>
            </ToolCard>

            {/* Format Converter */}
            <ToolCard
              icon={<RotateCcw className="text-2xl text-white" />}
              title="Format Converter"
              description="Convert between JPEG, PNG, WebP, and other formats."
              gradient="bg-gradient-to-r from-green-500 to-teal-500"
              delay={0.3}
            >
              <UploadZone
                onFilesSelected={setSelectedFiles}
                accept={{ 'image/*': ['.jpg', '.jpeg', '.png', '.webp'] }}
                multiple={true}
                icon={<RotateCcw className="w-8 h-8" />}
                title="Upload images to convert"
              />
              
              <div className="mb-4">
                <Label className="block text-sm font-medium text-slate-300 mb-2">Output Format</Label>
                <Select defaultValue="jpeg">
                  <SelectTrigger className="w-full bg-slate-800 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="jpeg">JPEG</SelectItem>
                    <SelectItem value="png">PNG</SelectItem>
                    <SelectItem value="webp">WebP</SelectItem>
                    <SelectItem value="avif">AVIF</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <Button 
                onClick={() => processMutation.mutate({ files: selectedFiles, operation: 'convert' })}
                disabled={processMutation.isPending || selectedFiles.length === 0}
                className="w-full py-3 bg-gradient-to-r from-green-500 to-teal-500 rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
              >
                {processMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <RotateCcw className="mr-2 h-4 w-4" />
                )}
                Convert Images
              </Button>
            </ToolCard>

            {/* Image Compressor */}
            <ToolCard
              icon={<Combine className="text-2xl text-white" />}
              title="Combine Images"
              description="Reduce file size while preserving visual quality."
              gradient="bg-gradient-to-r from-orange-500 to-red-500"
              delay={0.4}
            >
              <UploadZone
                onFilesSelected={setSelectedFiles}
                accept={{ 'image/*': ['.jpg', '.jpeg', '.png', '.webp'] }}
                multiple={true}
                icon={<Combine className="w-8 h-8" />}
                title="Upload images to compress"
              />
              
              <div className="mb-4">
                <Label className="block text-sm font-medium text-slate-300 mb-2">Quality Level (%)</Label>
                <Slider defaultValue={[80]} max={100} min={10} step={1} className="w-full" />
                <div className="flex justify-between text-xs text-slate-400 mt-1">
                  <span>Smallest</span>
                  <span>Best Quality</span>
                </div>
              </div>
              
              <Button 
                onClick={() => processMutation.mutate({ files: selectedFiles, operation: 'compress' })}
                disabled={processMutation.isPending || selectedFiles.length === 0}
                className="w-full py-3 bg-gradient-to-r from-orange-500 to-red-500 rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
              >
                {processMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Combine className="mr-2 h-4 w-4" />
                )}
                Combine Images
              </Button>
            </ToolCard>

            {/* Image Cropper */}
            <ToolCard
              icon={<Crop className="text-2xl text-white" />}
              title="Smart Crop"
              description="Intelligent cropping with preset aspect ratios and custom dimensions."
              gradient="bg-gradient-to-r from-pink-500 to-purple-500"
              delay={0.5}
            >
              <UploadZone
                onFilesSelected={setSelectedFiles}
                accept={{ 'image/*': ['.jpg', '.jpeg', '.png', '.webp'] }}
                multiple={false}
                icon={<Crop className="w-8 h-8" />}
                title="Upload image to crop"
              />
              
              <div className="mb-4">
                <Label className="block text-sm font-medium text-slate-300 mb-2">Aspect Ratio</Label>
                <Select defaultValue="custom">
                  <SelectTrigger className="w-full bg-slate-800 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="custom">Custom</SelectItem>
                    <SelectItem value="1:1">1:1 (Square)</SelectItem>
                    <SelectItem value="4:3">4:3</SelectItem>
                    <SelectItem value="16:9">16:9</SelectItem>
                    <SelectItem value="9:16">9:16 (Story)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <Button 
                onClick={() => processMutation.mutate({ files: selectedFiles, operation: 'crop' })}
                disabled={processMutation.isPending || selectedFiles.length !== 1}
                className="w-full py-3 bg-gradient-to-r from-pink-500 to-purple-500 rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
              >
                {processMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Crop className="mr-2 h-4 w-4" />
                )}
                Crop Image
              </Button>
            </ToolCard>

            {/* Image Enhancer */}
            <ToolCard
              icon={<Sparkles className="text-2xl text-white" />}
              title="AI Enhance"
              description="AI-powered image enhancement for better clarity and colors."
              gradient="bg-gradient-to-r from-indigo-500 to-blue-500"
              delay={0.6}
            >
              <UploadZone
                onFilesSelected={setSelectedFiles}
                accept={{ 'image/*': ['.jpg', '.jpeg', '.png', '.webp'] }}
                multiple={false}
                icon={<Sparkles className="w-8 h-8" />}
                title="Upload image to enhance"
              />
              
              <div className="mb-4">
                <Label className="block text-sm font-medium text-slate-300 mb-2">Enhancement Type</Label>
                <Select defaultValue="auto">
                  <SelectTrigger className="w-full bg-slate-800 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="auto">Auto Enhance</SelectItem>
                    <SelectItem value="sharpen">Sharpen</SelectItem>
                    <SelectItem value="denoise">Denoise</SelectItem>
                    <SelectItem value="color">Color Boost</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <Button 
                onClick={() => processMutation.mutate({ files: selectedFiles, operation: 'enhance' })}
                disabled={processMutation.isPending || selectedFiles.length !== 1}
                className="w-full py-3 bg-gradient-to-r from-indigo-500 to-blue-500 rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
              >
                {processMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Sparkles className="mr-2 h-4 w-4" />
                )}
                Enhance Image
              </Button>
            </ToolCard>
          </motion.div>
        </div>
      </section>
    </motion.div>
  );
}
