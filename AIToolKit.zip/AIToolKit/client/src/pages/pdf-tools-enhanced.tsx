import { motion } from "framer-motion";
import { 
  FileText, Download, Upload, Merge, Scissors, Shield, Eye, 
  Image, Lock, Unlock, RotateCw, Crop, FileImage, FileCheck,
  Combine, Edit3, Zap, Search, FileX, FilePlus, Archive,
  ArrowRight, Copy, Clock, Star, TrendingUp
} from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import UniversalToolInterface from "@/components/universal-tool-interface";
import AdSlot from "@/components/ui/ad-slot";
import { useState } from "react";

export default function PDFToolsEnhanced() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("popular");
  const [toolInterfaceOpen, setToolInterfaceOpen] = useState(false);
  const [selectedTool, setSelectedTool] = useState<any>(null);

  const pdfTools = [
    {
      id: "merge",
      icon: Merge,
      title: "Merge PDFs",
      description: "Combine multiple PDF files into one document",
      category: "Combine",
      popular: true,
      searchVolume: 125000,
      features: ["Unlimited files", "Preserve bookmarks", "Custom page order"]
    },
    {
      id: "split",
      icon: Scissors,
      title: "Split PDF",
      description: "Split a PDF into separate pages or ranges",
      category: "Separate", 
      popular: true,
      searchVolume: 98000,
      features: ["Split by page range", "Extract specific pages", "Bulk processing"]
    },
    {
      id: "compress",
      icon: Archive,
      title: "Compress PDF",
      description: "Reduce PDF file size while maintaining quality",
      category: "Optimize",
      popular: true,
      searchVolume: 87000,
      features: ["Smart compression", "Quality presets", "Size reduction"]
    },
    {
      id: "pdf-to-word",
      icon: FileText,
      title: "PDF to Word",
      description: "Convert PDF documents to editable Word files",
      category: "Convert",
      popular: true,
      searchVolume: 156000,
      features: ["OCR support", "Layout preservation", "Table detection"]
    },
    {
      id: "word-to-pdf",
      icon: FileText,
      title: "Word to PDF",
      description: "Convert Word documents to PDF format",
      category: "Convert",
      popular: true,
      searchVolume: 134000,
      features: ["Font embedding", "Hyperlink preservation", "Password protection"]
    },
    {
      id: "jpg-to-pdf",
      icon: FileImage,
      title: "JPG to PDF",
      description: "Convert JPG images to PDF documents",
      category: "Convert",
      popular: true,
      searchVolume: 67000,
      features: ["Multiple images", "Custom page size", "Image optimization"]
    },
    {
      id: "pdf-to-jpg",
      icon: Image,
      title: "PDF to JPG",
      description: "Convert PDF pages to JPG images",
      category: "Convert",
      popular: true,
      searchVolume: 72000,
      features: ["High resolution", "Custom DPI", "Batch conversion"]
    },
    {
      id: "protect",
      icon: Shield,
      title: "Protect PDF",
      description: "Add password protection to your PDF files",
      category: "Security",
      popular: false,
      searchVolume: 45000,
      features: ["User/owner passwords", "Permission control", "Encryption levels"]
    },
    {
      id: "unlock",
      icon: Unlock,
      title: "Unlock PDF",
      description: "Remove password protection from PDF files",
      category: "Security",
      popular: false,
      searchVolume: 38000,
      features: ["Password removal", "Permission unlock", "Secure processing"]
    },
    {
      id: "ocr",
      icon: Eye,
      title: "OCR Text Extract",
      description: "Extract text from scanned PDF documents",
      category: "Extract",
      popular: false,
      searchVolume: 52000,
      features: ["Multi-language", "Searchable PDF", "Text formatting"]
    },
    {
      id: "rotate",
      icon: RotateCw,
      title: "Rotate PDF",
      description: "Rotate PDF pages to correct orientation",
      category: "Edit",
      popular: false,
      searchVolume: 28000,
      features: ["90° increments", "Selective pages", "Auto-detect"]
    },
    {
      id: "watermark",
      icon: Edit3,
      title: "Add Watermark",
      description: "Add text or image watermarks to PDF pages",
      category: "Edit",
      popular: false,
      searchVolume: 34000,
      features: ["Text/image watermarks", "Transparency control", "Position options"]
    },
    {
      id: "sign",
      icon: FileCheck,
      title: "Sign PDF",
      description: "Add digital signatures to PDF documents",
      category: "Security",
      popular: false,
      searchVolume: 41000,
      features: ["Digital signatures", "Certificate support", "Timestamp"]
    }
  ];

  const popularTools = pdfTools.filter(tool => tool.popular).sort((a, b) => b.searchVolume - a.searchVolume);
  const allTools = pdfTools.sort((a, b) => b.searchVolume - a.searchVolume);
  const categories = Array.from(new Set(pdfTools.map(tool => tool.category)));

  const openToolInterface = (tool: any) => {
    const toolConfig = {
      id: tool.id,
      name: tool.title,
      category: 'pdf' as const,
      icon: <tool.icon className="w-5 h-5" />,
      acceptedFiles: ['pdf'],
      description: tool.description,
      features: tool.features || ['Professional processing', 'High quality output', 'Secure processing']
    };
    setSelectedTool(toolConfig);
    setToolInterfaceOpen(true);
  };

  const handleProcessComplete = (result: any) => {
    toast({
      title: "Processing complete!",
      description: `${result.tool} completed successfully with ${result.files} files.`,
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-red-900 to-pink-900">
      {/* SEO Head */}
      <title>PDF Tools - Free PDF Merger, Splitter, Converter Online | ToolSuite Pro</title>
      
      {/* Hero Section */}
      <div className="relative pt-20 pb-16">
        <div className="absolute inset-0 bg-gradient-to-r from-red-600/20 to-pink-600/20 backdrop-blur-3xl"></div>
        <motion.div 
          className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <motion.div
            className="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-r from-red-500 to-pink-500 flex items-center justify-center"
            animate={{ 
              rotateY: [0, 360],
              scale: [1, 1.1, 1]
            }}
            transition={{ 
              rotateY: { duration: 6, repeat: Infinity, ease: "linear" },
              scale: { duration: 2, repeat: Infinity, ease: "easeInOut" }
            }}
          >
            <FileText className="w-10 h-10 text-white" />
          </motion.div>
          
          <motion.h1 
            className="text-5xl md:text-7xl font-bold text-white mb-6"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            PDF <span className="bg-gradient-to-r from-red-400 to-pink-400 bg-clip-text text-transparent">Tools</span>
          </motion.h1>
          
          <motion.p 
            className="text-xl text-gray-300 mb-8 max-w-4xl mx-auto"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            Comprehensive PDF processing tools. Merge, split, convert, compress, protect, 
            and edit your PDF documents with professional-grade features and security.
          </motion.p>
          
          <motion.div
            className="flex flex-wrap justify-center gap-4 mb-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
          >
            <div className="bg-red-500/20 text-red-300 border border-red-500/30 rounded-full px-4 py-2 text-sm">
              <Star className="w-4 h-4 mr-1 inline" />
              Professional Grade
            </div>
            <div className="bg-pink-500/20 text-pink-300 border border-pink-500/30 rounded-full px-4 py-2 text-sm">
              <TrendingUp className="w-4 h-4 mr-1 inline" />
              10M+ Documents Processed
            </div>
            <div className="bg-red-500/20 text-red-300 border border-red-500/30 rounded-full px-4 py-2 text-sm">
              <Shield className="w-4 h-4 mr-1 inline" />
              Secure Processing
            </div>
          </motion.div>
        </motion.div>
      </div>

      {/* Tools Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <div className="w-full">
          <div className="grid grid-cols-3 mb-8 bg-white/10 backdrop-blur-lg rounded-lg p-1">
            <Button 
              onClick={() => setActiveTab("popular")}
              className={`${activeTab === "popular" ? "bg-red-500" : "bg-transparent"} text-white hover:bg-red-500/50`}
            >
              Most Popular
            </Button>
            <Button 
              onClick={() => setActiveTab("all")}
              className={`${activeTab === "all" ? "bg-red-500" : "bg-transparent"} text-white hover:bg-red-500/50`}
            >
              All Tools
            </Button>
            <Button 
              onClick={() => setActiveTab("categories")}
              className={`${activeTab === "categories" ? "bg-red-500" : "bg-transparent"} text-white hover:bg-red-500/50`}
            >
              By Category
            </Button>
          </div>

          {activeTab === "popular" && (
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              {popularTools.map((tool, index) => (
                <motion.div
                  key={tool.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.1 * index }}
                  whileHover={{ y: -5, scale: 1.02 }}
                >
                  <Card className="bg-white/10 backdrop-blur-lg border border-white/20 hover:border-red-400/50 transition-all duration-300 h-full">
                    <CardHeader className="text-center">
                      <div className="relative">
                        <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-r from-red-500 to-pink-500 flex items-center justify-center">
                          <tool.icon className="w-8 h-8 text-white" />
                        </div>
                        <div className="absolute -top-2 -right-2 bg-yellow-500 text-black text-xs rounded-full px-2 py-1">
                          <TrendingUp className="w-3 h-3 mr-1 inline" />
                          HOT
                        </div>
                      </div>
                      <CardTitle className="text-white text-xl">{tool.title}</CardTitle>
                      <CardDescription className="text-gray-300">
                        {tool.description}
                      </CardDescription>
                      <div className="flex justify-between items-center mt-2">
                        <span className="text-xs text-red-400 bg-red-400/20 px-2 py-1 rounded-full">
                          {tool.category}
                        </span>
                        <span className="text-xs text-gray-400">
                          {(tool.searchVolume / 1000).toFixed(0)}k/month
                        </span>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="mb-4">
                        <p className="text-xs text-gray-400 mb-2">Features:</p>
                        <div className="flex flex-wrap gap-1">
                          {tool.features.slice(0, 3).map((feature, idx) => (
                            <span key={idx} className="text-xs bg-gray-600/50 text-gray-300 px-2 py-1 rounded">
                              {feature}
                            </span>
                          ))}
                        </div>
                      </div>
                      <Button 
                        onClick={() => openToolInterface(tool)}
                        className="w-full bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-600 hover:to-pink-600 text-white font-semibold"
                      >
                        Use Tool
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          )}

          {activeTab === "all" && (
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              {allTools.map((tool, index) => (
                <Card key={tool.id} className="bg-white/10 backdrop-blur-lg border border-white/20 hover:border-red-400/50 transition-all duration-300">
                  <CardHeader className="text-center pb-4">
                    <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-gradient-to-r from-red-500 to-pink-500 flex items-center justify-center">
                      <tool.icon className="w-6 h-6 text-white" />
                    </div>
                    <CardTitle className="text-white text-lg">{tool.title}</CardTitle>
                    <span className="text-xs text-red-400 bg-red-400/20 px-2 py-1 rounded-full">
                      {tool.category}
                    </span>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <Button 
                      onClick={() => openToolInterface(tool)}
                      className="w-full bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-600 hover:to-pink-600 text-white font-semibold text-sm"
                    >
                      Use Now
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </motion.div>
          )}

          {activeTab === "categories" && (
            <div className="space-y-8">
              {categories.map((category, categoryIndex) => (
                <motion.div
                  key={category}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.1 * categoryIndex }}
                >
                  <h3 className="text-2xl font-bold text-white mb-4">{category} Tools</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {allTools.filter(tool => tool.category === category).map((tool) => (
                      <Card key={tool.id} className="bg-white/10 backdrop-blur-lg border border-white/20 hover:border-red-400/50 transition-all duration-300">
                        <CardContent className="p-4">
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 rounded-full bg-gradient-to-r from-red-500 to-pink-500 flex items-center justify-center">
                              <tool.icon className="w-5 h-5 text-white" />
                            </div>
                            <div className="flex-1">
                              <h4 className="text-white font-semibold">{tool.title}</h4>
                              <p className="text-gray-400 text-sm">{tool.description}</p>
                            </div>
                            <Button 
                              onClick={() => openToolInterface(tool)}
                              size="sm"
                              className="bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-600 hover:to-pink-600"
                            >
                              Use
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>

        {/* Stats Section */}
        <motion.div
          className="mt-16 bg-white/5 backdrop-blur-lg rounded-xl border border-white/10 p-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1.0 }}
        >
          <h3 className="text-2xl font-bold text-white mb-6 text-center">Professional PDF Processing</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-red-400 mb-2">100%</div>
              <div className="text-white">Secure</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-pink-400 mb-2">13+</div>
              <div className="text-white">PDF Tools</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-red-400 mb-2">OCR</div>
              <div className="text-white">Text Recognition</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-pink-400 mb-2">Unlimited</div>
              <div className="text-white">File Size</div>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Universal Tool Interface */}
      <UniversalToolInterface
        isOpen={toolInterfaceOpen}
        onClose={() => setToolInterfaceOpen(false)}
        tool={selectedTool}
      />
    </div>
  );
}