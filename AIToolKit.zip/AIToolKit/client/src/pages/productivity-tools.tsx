import { motion } from "framer-motion";
import { Calculator, Calendar, Clock, Target, Zap, BarChart3, FileSpreadsheet, CheckSquare, Timer, BookOpen } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

export default function ProductivityTools() {
  const { toast } = useToast();
  const [calculation, setCalculation] = useState("");
  const [result, setResult] = useState("");

  const productivityTools = [
    {
      id: "calculator",
      icon: Calculator,
      title: "Advanced Calculator",
      description: "Scientific calculator with history and advanced functions",
      category: "Math"
    },
    {
      id: "date-calculator",
      icon: Calendar,
      title: "Date Calculator",
      description: "Calculate date differences, add/subtract days, business days",
      category: "Time"
    },
    {
      id: "pomodoro-timer",
      icon: Timer,
      title: "Pomodoro Timer",
      description: "Boost productivity with focused work sessions",
      category: "Focus"
    },
    {
      id: "time-zones",
      icon: Clock,
      title: "Time Zone Converter",
      description: "Convert time across different time zones worldwide",
      category: "Time"
    },
    {
      id: "goal-tracker",
      icon: Target,
      title: "Goal Tracker",
      description: "Set and track your personal and professional goals",
      category: "Planning"
    },
    {
      id: "habit-tracker",
      icon: CheckSquare,
      title: "Habit Tracker",
      description: "Build and maintain positive daily habits",
      category: "Planning"
    },
    {
      id: "expense-tracker",
      icon: BarChart3,
      title: "Expense Tracker",
      description: "Track expenses and analyze spending patterns",
      category: "Finance"
    },
    {
      id: "budget-calculator",
      icon: FileSpreadsheet,
      title: "Budget Calculator",
      description: "Plan your monthly budget and savings goals",
      category: "Finance"
    },
    {
      id: "password-generator",
      icon: Zap,
      title: "Password Generator",
      description: "Generate secure passwords with custom requirements",
      category: "Security"
    },
    {
      id: "notes-organizer",
      icon: BookOpen,
      title: "Notes Organizer",
      description: "Organize your thoughts with smart note-taking",
      category: "Organization"
    }
  ];

  const handleCalculation = () => {
    try {
      // Simple calculator - in production, use a proper math parser
      const mathResult = eval(calculation.replace(/[^0-9+\-*/().\s]/g, ''));
      setResult(mathResult.toString());
      toast({
        title: "Calculation completed!",
        description: `Result: ${mathResult}`,
      });
    } catch (error) {
      setResult("Error");
      toast({
        title: "Invalid expression",
        description: "Please enter a valid mathematical expression.",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-green-900 to-blue-900">
      {/* SEO Head equivalent */}
      <title>Productivity Tools - Calculator, Timer, Goal Tracker, Budget Planner | ToolSuite Pro</title>
      
      {/* Hero Section */}
      <div className="relative pt-20 pb-16">
        <div className="absolute inset-0 bg-gradient-to-r from-green-600/20 to-blue-600/20 backdrop-blur-3xl"></div>
        <motion.div 
          className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <motion.h1 
            className="text-5xl md:text-7xl font-bold text-white mb-6"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            Productivity <span className="bg-gradient-to-r from-green-400 to-blue-400 bg-clip-text text-transparent">Tools</span>
          </motion.h1>
          <motion.p 
            className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            Boost your productivity with our comprehensive suite of tools. 
            Calculate, plan, track, and organize your work and life efficiently.
          </motion.p>
        </motion.div>
      </div>

      {/* Featured Calculator */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <motion.div 
          className="bg-white/10 backdrop-blur-lg rounded-xl border border-white/20 p-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
        >
          <h2 className="text-3xl font-bold text-white mb-6 text-center">Quick Calculator</h2>
          <div className="max-w-md mx-auto space-y-4">
            <Input
              value={calculation}
              onChange={(e) => setCalculation(e.target.value)}
              placeholder="Enter calculation (e.g., 2 + 2 * 3)"
              className="text-center text-xl bg-white/5 border-white/20 text-white"
              onKeyPress={(e) => e.key === 'Enter' && handleCalculation()}
            />
            <div className="text-center text-2xl font-bold text-green-400 min-h-[2rem]">
              {result && `= ${result}`}
            </div>
            <div className="grid grid-cols-4 gap-2">
              {['7', '8', '9', '/', '4', '5', '6', '*', '1', '2', '3', '-', '0', '.', '=', '+'].map((btn) => (
                <Button
                  key={btn}
                  onClick={() => {
                    if (btn === '=') {
                      handleCalculation();
                    } else {
                      setCalculation(prev => prev + btn);
                    }
                  }}
                  className="h-12 bg-white/10 hover:bg-white/20 border-white/20 text-white"
                >
                  {btn}
                </Button>
              ))}
            </div>
            <div className="flex gap-2">
              <Button 
                onClick={() => setCalculation("")}
                className="flex-1 bg-red-500/20 hover:bg-red-500/30 text-red-400"
              >
                Clear
              </Button>
              <Button 
                onClick={() => setCalculation(prev => prev.slice(0, -1))}
                className="flex-1 bg-yellow-500/20 hover:bg-yellow-500/30 text-yellow-400"
              >
                Backspace
              </Button>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Tools Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <motion.h2 
          className="text-3xl font-bold text-white mb-12 text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          All Productivity Tools
        </motion.h2>
        
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1.0 }}
        >
          {productivityTools.map((tool, index) => (
            <motion.div
              key={tool.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 * index }}
              whileHover={{ y: -5, scale: 1.02 }}
            >
              <Card className="bg-white/10 backdrop-blur-lg border border-white/20 hover:border-green-400/50 transition-all duration-300 h-full">
                <CardHeader className="text-center">
                  <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-r from-green-500 to-blue-500 flex items-center justify-center">
                    <tool.icon className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className="text-white text-xl">{tool.title}</CardTitle>
                  <CardDescription className="text-gray-300">
                    {tool.description}
                  </CardDescription>
                  <span className="text-xs text-green-400 bg-green-400/20 px-2 py-1 rounded-full">
                    {tool.category}
                  </span>
                </CardHeader>
                <CardContent>
                  <Button 
                    className="w-full bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600 text-white font-semibold"
                    onClick={() => {
                      toast({
                        title: `${tool.title} activated!`,
                        description: "This tool is ready to use.",
                      });
                    }}
                  >
                    Use Tool
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </div>
  );
}