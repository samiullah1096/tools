import { useState } from "react";
import { motion } from "framer-motion";
import { 
  FileText, 
  Merge, 
  Scissors, 
  Combine, 
  File, 
  Lock, 
  Search,
  Download,
  Loader2
} from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import ToolCard from "@/components/ui/tool-card";
import UploadZone from "@/components/ui/upload-zone";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { pageTransition, staggerContainer } from "@/lib/animations";

export default function PDFTools() {
  const { toast } = useToast();
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);

  const uploadMutation = useMutation({
    mutationFn: async (data: { files: File[], operation: string, params?: any }) => {
      const formData = new FormData();
      data.files.forEach(file => formData.append('files', file));
      formData.append('toolType', 'pdf');
      formData.append('operation', data.operation);
      if (data.params) {
        formData.append('params', JSON.stringify(data.params));
      }
      
      return apiRequest('POST', '/api/upload-multiple', formData);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "PDF processing started successfully!",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to process PDF. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleMergePDFs = () => {
    if (selectedFiles.length < 2) {
      toast({
        title: "Error",
        description: "Please select at least 2 PDF files to merge.",
        variant: "destructive",
      });
      return;
    }
    uploadMutation.mutate({ files: selectedFiles, operation: 'merge' });
  };

  const handleSplitPDF = () => {
    if (selectedFiles.length !== 1) {
      toast({
        title: "Error",
        description: "Please select exactly one PDF file to split.",
        variant: "destructive",
      });
      return;
    }
    uploadMutation.mutate({ files: selectedFiles, operation: 'split' });
  };

  const handleCompressPDF = (compressionLevel: string) => {
    if (selectedFiles.length !== 1) {
      toast({
        title: "Error",
        description: "Please select exactly one PDF file to compress.",
        variant: "destructive",
      });
      return;
    }
    uploadMutation.mutate({ 
      files: selectedFiles, 
      operation: 'compress', 
      params: { compressionLevel } 
    });
  };

  return (
    <motion.div {...pageTransition}>
      <section className="py-20">
        <div className="container mx-auto px-6">
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="w-20 h-20 bg-gradient-to-r from-red-500 to-pink-500 rounded-2xl flex items-center justify-center mx-auto mb-6 animate-float">
              <FileText className="text-3xl text-white" />
            </div>
            <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-red-400 to-pink-400 bg-clip-text text-transparent">
              PDF Tools
            </h1>
            <p className="text-xl text-slate-300 max-w-2xl mx-auto">
              Professional PDF processing with AI-powered optimization and advanced features
            </p>
          </motion.div>

          <motion.div 
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
            variants={staggerContainer}
            initial="initial"
            animate="animate"
          >
            {/* PDF Merger */}
            <ToolCard
              icon={<Merge className="text-2xl text-white" />}
              title="Merge PDFs"
              description="Combine multiple PDF files into one document with intelligent page ordering."
              gradient="bg-gradient-to-r from-red-500 to-orange-500"
              delay={0.1}
            >
              <UploadZone
                onFilesSelected={setSelectedFiles}
                accept={{ 'application/pdf': ['.pdf'] }}
                multiple={true}
                maxFiles={10}
                icon={<Merge className="w-8 h-8" />}
                title="Drop PDF files here"
                description="Select multiple PDFs to merge"
              />
              
              <Button 
                onClick={handleMergePDFs}
                disabled={uploadMutation.isPending || selectedFiles.length < 2}
                className="w-full mt-4 py-3 bg-gradient-to-r from-red-500 to-orange-500 rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
              >
                {uploadMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Merge className="mr-2 h-4 w-4" />
                )}
                Merge PDFs
              </Button>
            </ToolCard>

            {/* PDF Splitter */}
            <ToolCard
              icon={<Scissors className="text-2xl text-white" />}
              title="Split PDF"
              description="Extract pages or split PDFs into multiple documents with precision."
              gradient="bg-gradient-to-r from-pink-500 to-purple-500"
              delay={0.2}
            >
              <UploadZone
                onFilesSelected={setSelectedFiles}
                accept={{ 'application/pdf': ['.pdf'] }}
                multiple={false}
                icon={<FileText className="w-8 h-8" />}
                title="Upload PDF to split"
              />
              
              <Button 
                onClick={handleSplitPDF}
                disabled={uploadMutation.isPending || selectedFiles.length !== 1}
                className="w-full mt-4 py-3 bg-gradient-to-r from-pink-500 to-purple-500 rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
              >
                {uploadMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Scissors className="mr-2 h-4 w-4" />
                )}
                Split PDF
              </Button>
            </ToolCard>

            {/* PDF Compressor */}
            <ToolCard
              icon={<Combine className="text-2xl text-white" />}
              title="Combine PDF"
              description="Reduce file size with smart compression while maintaining quality."
              gradient="bg-gradient-to-r from-blue-500 to-cyan-500"
              delay={0.3}
            >
              <UploadZone
                onFilesSelected={setSelectedFiles}
                accept={{ 'application/pdf': ['.pdf'] }}
                multiple={false}
                icon={<Combine className="w-8 h-8" />}
                title="Upload PDF to compress"
              />
              
              <div className="mb-4">
                <Label className="block text-sm font-medium text-slate-300 mb-2">Compression Level</Label>
                <Select defaultValue="balanced">
                  <SelectTrigger className="w-full bg-slate-800 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="high">High Quality</SelectItem>
                    <SelectItem value="balanced">Balanced</SelectItem>
                    <SelectItem value="maximum">Maximum Compression</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <Button 
                onClick={() => handleCompressPDF('balanced')}
                disabled={uploadMutation.isPending || selectedFiles.length !== 1}
                className="w-full py-3 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
              >
                {uploadMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Combine className="mr-2 h-4 w-4" />
                )}
                Combine PDF
              </Button>
            </ToolCard>

            {/* PDF to Word */}
            <ToolCard
              icon={<File className="text-2xl text-white" />}
              title="PDF to Word"
              description="Convert PDF to editable Word documents with OCR technology."
              gradient="bg-gradient-to-r from-indigo-500 to-purple-500"
              delay={0.4}
            >
              <UploadZone
                onFilesSelected={setSelectedFiles}
                accept={{ 'application/pdf': ['.pdf'] }}
                multiple={false}
                icon={<File className="w-8 h-8" />}
                title="Upload PDF to convert"
              />
              
              <Button 
                disabled={uploadMutation.isPending || selectedFiles.length !== 1}
                className="w-full mt-4 py-3 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
              >
                {uploadMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <File className="mr-2 h-4 w-4" />
                )}
                Convert to Word
              </Button>
            </ToolCard>

            {/* PDF Password Protect */}
            <ToolCard
              icon={<Lock className="text-2xl text-white" />}
              title="Protect PDF"
              description="Add password protection and set permissions for your PDFs."
              gradient="bg-gradient-to-r from-green-500 to-teal-500"
              delay={0.5}
            >
              <UploadZone
                onFilesSelected={setSelectedFiles}
                accept={{ 'application/pdf': ['.pdf'] }}
                multiple={false}
                icon={<Lock className="w-8 h-8" />}
                title="Upload PDF to protect"
              />
              
              <div className="mb-4">
                <Label className="block text-sm font-medium text-slate-300 mb-2">Password</Label>
                <Input 
                  type="password" 
                  className="w-full bg-slate-800 border-slate-600 text-white" 
                  placeholder="Enter password" 
                />
              </div>
              
              <Button 
                disabled={uploadMutation.isPending || selectedFiles.length !== 1}
                className="w-full py-3 bg-gradient-to-r from-green-500 to-teal-500 rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
              >
                {uploadMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Lock className="mr-2 h-4 w-4" />
                )}
                Protect PDF
              </Button>
            </ToolCard>

            {/* OCR Text Extraction */}
            <ToolCard
              icon={<Search className="text-2xl text-white" />}
              title="OCR Extract"
              description="Extract text from scanned PDFs using advanced OCR technology."
              gradient="bg-gradient-to-r from-yellow-500 to-orange-500"
              delay={0.6}
            >
              <UploadZone
                onFilesSelected={setSelectedFiles}
                accept={{ 'application/pdf': ['.pdf'] }}
                multiple={false}
                icon={<Search className="w-8 h-8" />}
                title="Upload scanned PDF"
              />
              
              <div className="mb-4">
                <Label className="block text-sm font-medium text-slate-300 mb-2">Language</Label>
                <Select defaultValue="english">
                  <SelectTrigger className="w-full bg-slate-800 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="english">English</SelectItem>
                    <SelectItem value="spanish">Spanish</SelectItem>
                    <SelectItem value="french">French</SelectItem>
                    <SelectItem value="german">German</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <Button 
                disabled={uploadMutation.isPending || selectedFiles.length !== 1}
                className="w-full py-3 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
              >
                {uploadMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Search className="mr-2 h-4 w-4" />
                )}
                Extract Text
              </Button>
            </ToolCard>
          </motion.div>
        </div>
      </section>
    </motion.div>
  );
}
