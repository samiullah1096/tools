import { useState } from "react";
import { motion } from "framer-motion";
import { 
  Bot, 
  PenTool, 
  Eye, 
  Languages, 
  FileText, 
  MessageSquare,
  Code,
  Loader2,
  Send
} from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import ToolCard from "@/components/ui/tool-card";
import UploadZone from "@/components/ui/upload-zone";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { pageTransition, staggerContainer } from "@/lib/animations";

export default function AITools() {
  const { toast } = useToast();
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [textPrompt, setTextPrompt] = useState("");
  const [chatMessage, setChatMessage] = useState("");
  const [chatHistory, setChatHistory] = useState<{role: string, content: string}[]>([]);
  const [generatedContent, setGeneratedContent] = useState("");
  const [analysisResult, setAnalysisResult] = useState<any>(null);

  const textGenerationMutation = useMutation({
    mutationFn: async (data: { prompt: string, contentType: string }) => {
      const response = await apiRequest('POST', '/api/ai/generate-text', data);
      return response.json();
    },
    onSuccess: (data) => {
      setGeneratedContent(data.generatedText);
      toast({
        title: "Success",
        description: "AI content generated successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to generate content. Please try again.",
        variant: "destructive",
      });
    },
  });

  const imageAnalysisMutation = useMutation({
    mutationFn: async (data: { files: File[], analysisType: string }) => {
      const formData = new FormData();
      data.files.forEach(file => formData.append('files', file));
      formData.append('toolType', 'ai');
      formData.append('analysisType', data.analysisType);
      
      const response = await apiRequest('POST', '/api/ai/analyze-image', formData);
      return response.json();
    },
    onSuccess: (data) => {
      setAnalysisResult(data.analysis);
      toast({
        title: "Success",
        description: "Image analysis completed successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to analyze image. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleChatMessage = () => {
    if (!chatMessage.trim()) return;
    
    const newMessage = { role: "user", content: chatMessage };
    setChatHistory(prev => [...prev, newMessage]);
    
    // Simulate AI response
    setTimeout(() => {
      const aiResponse = { 
        role: "assistant", 
        content: `I understand you're asking about "${chatMessage}". This is a simulated AI response that would provide helpful information based on your query.`
      };
      setChatHistory(prev => [...prev, aiResponse]);
    }, 1000);
    
    setChatMessage("");
  };

  return (
    <motion.div {...pageTransition}>
      <section className="py-20">
        <div className="container mx-auto px-6">
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-2xl flex items-center justify-center mx-auto mb-6 animate-float">
              <Bot className="text-3xl text-white" />
            </div>
            <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
              AI Tools
            </h1>
            <p className="text-xl text-slate-300 max-w-2xl mx-auto">
              Harness the power of artificial intelligence for content generation and intelligent processing
            </p>
          </motion.div>

          <motion.div 
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
            variants={staggerContainer}
            initial="initial"
            animate="animate"
          >
            {/* Text Generator */}
            <ToolCard
              icon={<PenTool className="text-2xl text-white" />}
              title="Text Generator"
              description="Generate high-quality content using advanced AI language models."
              gradient="bg-gradient-to-r from-blue-500 to-indigo-500"
              delay={0.1}
            >
              <div className="mb-4">
                <Label className="block text-sm font-medium text-slate-300 mb-2">Content Type</Label>
                <Select defaultValue="article">
                  <SelectTrigger className="w-full bg-slate-800 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="article">Article</SelectItem>
                    <SelectItem value="blog">Blog Post</SelectItem>
                    <SelectItem value="email">Email</SelectItem>
                    <SelectItem value="social">Social Media</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="mb-4">
                <Label className="block text-sm font-medium text-slate-300 mb-2">Topic/Prompt</Label>
                <Textarea 
                  className="w-full bg-slate-800 border-slate-600 text-white resize-none" 
                  rows={3} 
                  placeholder="Describe what you want to generate..."
                  value={textPrompt}
                  onChange={(e) => setTextPrompt(e.target.value)}
                />
              </div>

              {generatedContent && (
                <div className="mb-4 p-3 bg-slate-800/50 rounded-lg">
                  <Label className="block text-sm font-medium text-slate-300 mb-2">Generated Content</Label>
                  <p className="text-sm text-slate-200">{generatedContent}</p>
                </div>
              )}
              
              <Button 
                onClick={() => textGenerationMutation.mutate({ prompt: textPrompt, contentType: 'article' })}
                disabled={textGenerationMutation.isPending || !textPrompt.trim()}
                className="w-full py-3 bg-gradient-to-r from-blue-500 to-indigo-500 rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
              >
                {textGenerationMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <PenTool className="mr-2 h-4 w-4" />
                )}
                Generate Content
              </Button>
            </ToolCard>

            {/* Image Analyzer */}
            <ToolCard
              icon={<Eye className="text-2xl text-white" />}
              title="Image Analyzer"
              description="Analyze images to extract objects, text, and generate descriptions."
              gradient="bg-gradient-to-r from-cyan-500 to-teal-500"
              delay={0.2}
            >
              <UploadZone
                onFilesSelected={setSelectedFiles}
                accept={{ 'image/*': ['.jpg', '.jpeg', '.png', '.webp'] }}
                multiple={false}
                icon={<Eye className="w-8 h-8" />}
                title="Upload image to analyze"
              />
              
              <div className="mb-4">
                <Label className="block text-sm font-medium text-slate-300 mb-2">Analysis Type</Label>
                <Select defaultValue="objects">
                  <SelectTrigger className="w-full bg-slate-800 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="objects">Object Detection</SelectItem>
                    <SelectItem value="text">Text Recognition</SelectItem>
                    <SelectItem value="description">Image Description</SelectItem>
                    <SelectItem value="colors">Color Analysis</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {analysisResult && (
                <div className="mb-4 p-3 bg-slate-800/50 rounded-lg">
                  <Label className="block text-sm font-medium text-slate-300 mb-2">Analysis Results</Label>
                  <div className="text-sm text-slate-200 space-y-1">
                    {analysisResult.objects && (
                      <p><strong>Objects:</strong> {analysisResult.objects.join(', ')}</p>
                    )}
                    {analysisResult.text && (
                      <p><strong>Text:</strong> {analysisResult.text}</p>
                    )}
                    {analysisResult.description && (
                      <p><strong>Description:</strong> {analysisResult.description}</p>
                    )}
                  </div>
                </div>
              )}
              
              <Button 
                onClick={() => imageAnalysisMutation.mutate({ files: selectedFiles, analysisType: 'objects' })}
                disabled={imageAnalysisMutation.isPending || selectedFiles.length !== 1}
                className="w-full py-3 bg-gradient-to-r from-cyan-500 to-teal-500 rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
              >
                {imageAnalysisMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Eye className="mr-2 h-4 w-4" />
                )}
                Analyze Image
              </Button>
            </ToolCard>

            {/* Language Translator */}
            <ToolCard
              icon={<Languages className="text-2xl text-white" />}
              title="Smart Translator"
              description="AI-powered translation with context awareness and tone preservation."
              gradient="bg-gradient-to-r from-green-500 to-emerald-500"
              delay={0.3}
            >
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <Label className="block text-sm font-medium text-slate-300 mb-2">From</Label>
                  <Select defaultValue="english">
                    <SelectTrigger className="w-full bg-slate-800 border-slate-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="english">English</SelectItem>
                      <SelectItem value="spanish">Spanish</SelectItem>
                      <SelectItem value="french">French</SelectItem>
                      <SelectItem value="german">German</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label className="block text-sm font-medium text-slate-300 mb-2">To</Label>
                  <Select defaultValue="spanish">
                    <SelectTrigger className="w-full bg-slate-800 border-slate-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="spanish">Spanish</SelectItem>
                      <SelectItem value="english">English</SelectItem>
                      <SelectItem value="french">French</SelectItem>
                      <SelectItem value="german">German</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="mb-4">
                <Label className="block text-sm font-medium text-slate-300 mb-2">Text to Translate</Label>
                <Textarea 
                  className="w-full bg-slate-800 border-slate-600 text-white resize-none" 
                  rows={3} 
                  placeholder="Enter text to translate..." 
                />
              </div>
              
              <Button 
                className="w-full py-3 bg-gradient-to-r from-green-500 to-emerald-500 rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
              >
                <Languages className="mr-2 h-4 w-4" />
                Translate Text
              </Button>
            </ToolCard>

            {/* Summary Generator */}
            <ToolCard
              icon={<FileText className="text-2xl text-white" />}
              title="Text Summarizer"
              description="Generate concise summaries from long documents and articles."
              gradient="bg-gradient-to-r from-purple-500 to-violet-500"
              delay={0.4}
            >
              <div className="mb-4">
                <Label className="block text-sm font-medium text-slate-300 mb-2">Input Text</Label>
                <Textarea 
                  className="w-full bg-slate-800 border-slate-600 text-white resize-none" 
                  rows={4} 
                  placeholder="Paste long text to summarize..." 
                />
              </div>
              
              <div className="mb-4">
                <Label className="block text-sm font-medium text-slate-300 mb-2">Summary Length</Label>
                <Select defaultValue="medium">
                  <SelectTrigger className="w-full bg-slate-800 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="short">Short</SelectItem>
                    <SelectItem value="medium">Medium</SelectItem>
                    <SelectItem value="detailed">Detailed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <Button 
                className="w-full py-3 bg-gradient-to-r from-purple-500 to-violet-500 rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
              >
                <FileText className="mr-2 h-4 w-4" />
                Generate Summary
              </Button>
            </ToolCard>

            {/* Chatbot Assistant */}
            <ToolCard
              icon={<MessageSquare className="text-2xl text-white" />}
              title="AI Assistant"
              description="Interactive AI assistant for questions, brainstorming, and problem-solving."
              gradient="bg-gradient-to-r from-pink-500 to-rose-500"
              delay={0.5}
            >
              <div className="mb-4">
                <div className="h-32 bg-slate-800 border border-slate-600 rounded-lg p-3 overflow-y-auto">
                  {chatHistory.length === 0 ? (
                    <div className="text-sm text-slate-400">AI Assistant ready to help...</div>
                  ) : (
                    <div className="space-y-2">
                      {chatHistory.map((msg, index) => (
                        <div key={index} className={`text-sm ${msg.role === 'user' ? 'text-blue-300' : 'text-slate-300'}`}>
                          <strong>{msg.role === 'user' ? 'You' : 'AI'}:</strong> {msg.content}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
              
              <div className="mb-4 flex gap-2">
                <Input 
                  type="text" 
                  className="flex-1 bg-slate-800 border-slate-600 text-white" 
                  placeholder="Ask me anything..."
                  value={chatMessage}
                  onChange={(e) => setChatMessage(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleChatMessage()}
                />
                <Button 
                  onClick={handleChatMessage}
                  disabled={!chatMessage.trim()}
                  className="px-4 bg-gradient-to-r from-pink-500 to-rose-500 rounded-lg"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </div>
              
              <Button 
                onClick={handleChatMessage}
                disabled={!chatMessage.trim()}
                className="w-full py-3 bg-gradient-to-r from-pink-500 to-rose-500 rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
              >
                <MessageSquare className="mr-2 h-4 w-4" />
                Send Message
              </Button>
            </ToolCard>

            {/* Code Generator */}
            <ToolCard
              icon={<Code className="text-2xl text-white" />}
              title="Code Generator"
              description="Generate code snippets and functions in multiple programming languages."
              gradient="bg-gradient-to-r from-orange-500 to-amber-500"
              delay={0.6}
            >
              <div className="mb-4">
                <Label className="block text-sm font-medium text-slate-300 mb-2">Programming Language</Label>
                <Select defaultValue="javascript">
                  <SelectTrigger className="w-full bg-slate-800 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="javascript">JavaScript</SelectItem>
                    <SelectItem value="python">Python</SelectItem>
                    <SelectItem value="html">HTML/CSS</SelectItem>
                    <SelectItem value="react">React</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div className="mb-4">
                <Label className="block text-sm font-medium text-slate-300 mb-2">Code Description</Label>
                <Textarea 
                  className="w-full bg-slate-800 border-slate-600 text-white resize-none" 
                  rows={3} 
                  placeholder="Describe the function or code you need..." 
                />
              </div>
              
              <Button 
                className="w-full py-3 bg-gradient-to-r from-orange-500 to-amber-500 rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
              >
                <Code className="mr-2 h-4 w-4" />
                Generate Code
              </Button>
            </ToolCard>
          </motion.div>
        </div>
      </section>
    </motion.div>
  );
}
