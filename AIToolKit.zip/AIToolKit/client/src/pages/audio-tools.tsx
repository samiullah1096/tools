import { useState } from "react";
import { motion } from "framer-motion";
import { 
  Headphones, 
  RotateCcw, 
  FileVolume, 
  Scissors, 
  ChevronsUp, 
  Layers, 
  AudioLines,
  Loader2
} from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import ToolCard from "@/components/ui/tool-card";
import UploadZone from "@/components/ui/upload-zone";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { pageTransition, staggerContainer } from "@/lib/animations";

export default function AudioTools() {
  const { toast } = useToast();
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);

  const processMutation = useMutation({
    mutationFn: async (data: { files: File[], operation: string, params?: any }) => {
      const formData = new FormData();
      data.files.forEach(file => formData.append('files', file));
      formData.append('toolType', 'audio');
      formData.append('operation', data.operation);
      if (data.params) {
        formData.append('params', JSON.stringify(data.params));
      }
      
      return apiRequest('POST', '/api/upload-multiple', formData);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Audio processing started successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to process audio. Please try again.",
        variant: "destructive",
      });
    },
  });

  return (
    <motion.div {...pageTransition}>
      <section className="py-20">
        <div className="container mx-auto px-6">
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <div className="w-20 h-20 bg-gradient-to-r from-green-500 to-teal-500 rounded-2xl flex items-center justify-center mx-auto mb-6 animate-float">
              <Headphones className="text-3xl text-white" />
            </div>
            <h1 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-green-400 to-teal-400 bg-clip-text text-transparent">
              Audio Studio
            </h1>
            <p className="text-xl text-slate-300 max-w-2xl mx-auto">
              Professional audio processing with AI-powered enhancement and format conversion
            </p>
          </motion.div>

          <motion.div 
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
            variants={staggerContainer}
            initial="initial"
            animate="animate"
          >
            {/* Audio Converter */}
            <ToolCard
              icon={<RotateCcw className="text-2xl text-white" />}
              title="Format Converter"
              description="Convert between MP3, WAV, FLAC, AAC and more formats."
              gradient="bg-gradient-to-r from-green-500 to-emerald-500"
              delay={0.1}
            >
              <UploadZone
                onFilesSelected={setSelectedFiles}
                accept={{ 'audio/*': ['.mp3', '.wav', '.flac', '.aac', '.ogg'] }}
                multiple={true}
                icon={<Headphones className="w-8 h-8" />}
                title="Drop audio files here"
              />
              
              <div className="mb-4">
                <Label className="block text-sm font-medium text-slate-300 mb-2">Output Format</Label>
                <Select defaultValue="mp3">
                  <SelectTrigger className="w-full bg-slate-800 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="mp3">MP3</SelectItem>
                    <SelectItem value="wav">WAV</SelectItem>
                    <SelectItem value="flac">FLAC</SelectItem>
                    <SelectItem value="aac">AAC</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <Button 
                onClick={() => processMutation.mutate({ files: selectedFiles, operation: 'convert', params: { format: 'mp3' } })}
                disabled={processMutation.isPending || selectedFiles.length === 0}
                className="w-full py-3 bg-gradient-to-r from-green-500 to-emerald-500 rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
              >
                {processMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <RotateCcw className="mr-2 h-4 w-4" />
                )}
                Convert Audio
              </Button>
            </ToolCard>

            {/* Noise Reduction */}
            <ToolCard
              icon={<FileVolume className="text-2xl text-white" />}
              title="Noise Reduction"
              description="Remove background noise and enhance audio clarity with AI."
              gradient="bg-gradient-to-r from-blue-500 to-cyan-500"
              delay={0.2}
            >
              <UploadZone
                onFilesSelected={setSelectedFiles}
                accept={{ 'audio/*': ['.mp3', '.wav', '.flac', '.aac'] }}
                multiple={false}
                icon={<FileVolume className="w-8 h-8" />}
                title="Upload noisy audio"
              />
              
              <div className="mb-4">
                <Label className="block text-sm font-medium text-slate-300 mb-2">Reduction Level</Label>
                <Slider defaultValue={[50]} max={100} step={1} className="w-full" />
                <div className="flex justify-between text-xs text-slate-400 mt-1">
                  <span>Light</span>
                  <span>Strong</span>
                </div>
              </div>
              
              <Button 
                onClick={() => processMutation.mutate({ files: selectedFiles, operation: 'denoise' })}
                disabled={processMutation.isPending || selectedFiles.length !== 1}
                className="w-full py-3 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
              >
                {processMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <FileVolume className="mr-2 h-4 w-4" />
                )}
                Clean Audio
              </Button>
            </ToolCard>

            {/* Audio Trimmer */}
            <ToolCard
              icon={<Scissors className="text-2xl text-white" />}
              title="Audio Trimmer"
              description="Trim and cut audio files with precision timing controls."
              gradient="bg-gradient-to-r from-purple-500 to-pink-500"
              delay={0.3}
            >
              <UploadZone
                onFilesSelected={setSelectedFiles}
                accept={{ 'audio/*': ['.mp3', '.wav', '.flac', '.aac'] }}
                multiple={false}
                icon={<Scissors className="w-8 h-8" />}
                title="Upload audio to trim"
              />
              
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <Label className="block text-sm font-medium text-slate-300 mb-2">Start Time</Label>
                  <Input 
                    type="text" 
                    className="w-full bg-slate-800 border-slate-600 text-white" 
                    placeholder="00:00" 
                  />
                </div>
                <div>
                  <Label className="block text-sm font-medium text-slate-300 mb-2">End Time</Label>
                  <Input 
                    type="text" 
                    className="w-full bg-slate-800 border-slate-600 text-white" 
                    placeholder="01:30" 
                  />
                </div>
              </div>
              
              <Button 
                onClick={() => processMutation.mutate({ files: selectedFiles, operation: 'trim' })}
                disabled={processMutation.isPending || selectedFiles.length !== 1}
                className="w-full py-3 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
              >
                {processMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Scissors className="mr-2 h-4 w-4" />
                )}
                Trim Audio
              </Button>
            </ToolCard>

            {/* Volume Adjuster */}
            <ToolCard
              icon={<ChevronsUp className="text-2xl text-white" />}
              title="Volume Control"
              description="Adjust volume levels and normalize audio amplitude."
              gradient="bg-gradient-to-r from-orange-500 to-red-500"
              delay={0.4}
            >
              <UploadZone
                onFilesSelected={setSelectedFiles}
                accept={{ 'audio/*': ['.mp3', '.wav', '.flac', '.aac'] }}
                multiple={false}
                icon={<ChevronsUp className="w-8 h-8" />}
                title="Upload audio file"
              />
              
              <div className="mb-4">
                <Label className="block text-sm font-medium text-slate-300 mb-2">Volume Level (%)</Label>
                <Slider defaultValue={[100]} max={200} step={1} className="w-full" />
                <div className="flex justify-between text-xs text-slate-400 mt-1">
                  <span>0%</span>
                  <span>200%</span>
                </div>
              </div>
              
              <Button 
                onClick={() => processMutation.mutate({ files: selectedFiles, operation: 'volume' })}
                disabled={processMutation.isPending || selectedFiles.length !== 1}
                className="w-full py-3 bg-gradient-to-r from-orange-500 to-red-500 rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
              >
                {processMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <ChevronsUp className="mr-2 h-4 w-4" />
                )}
                Adjust Volume
              </Button>
            </ToolCard>

            {/* Audio Merger */}
            <ToolCard
              icon={<Layers className="text-2xl text-white" />}
              title="Audio Merger"
              description="Combine multiple audio files into one seamless track."
              gradient="bg-gradient-to-r from-indigo-500 to-purple-500"
              delay={0.5}
            >
              <UploadZone
                onFilesSelected={setSelectedFiles}
                accept={{ 'audio/*': ['.mp3', '.wav', '.flac', '.aac'] }}
                multiple={true}
                icon={<Layers className="w-8 h-8" />}
                title="Select multiple audio files"
              />
              
              <div className="mb-4">
                <Label className="block text-sm font-medium text-slate-300 mb-2">Crossfade (seconds)</Label>
                <Input 
                  type="number" 
                  className="w-full bg-slate-800 border-slate-600 text-white" 
                  placeholder="2" 
                />
              </div>
              
              <Button 
                onClick={() => processMutation.mutate({ files: selectedFiles, operation: 'merge' })}
                disabled={processMutation.isPending || selectedFiles.length < 2}
                className="w-full py-3 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
              >
                {processMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Layers className="mr-2 h-4 w-4" />
                )}
                Merge Audio
              </Button>
            </ToolCard>

            {/* Audio AudioLines */}
            <ToolCard
              icon={<AudioLines className="text-2xl text-white" />}
              title="AudioLines"
              description="Fine-tune audio frequencies with professional EQ controls."
              gradient="bg-gradient-to-r from-teal-500 to-green-500"
              delay={0.6}
            >
              <UploadZone
                onFilesSelected={setSelectedFiles}
                accept={{ 'audio/*': ['.mp3', '.wav', '.flac', '.aac'] }}
                multiple={false}
                icon={<AudioLines className="w-8 h-8" />}
                title="Upload audio to equalize"
              />
              
              <div className="mb-4">
                <Label className="block text-sm font-medium text-slate-300 mb-2">EQ Preset</Label>
                <Select defaultValue="custom">
                  <SelectTrigger className="w-full bg-slate-800 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="custom">Custom</SelectItem>
                    <SelectItem value="bass">Bass Boost</SelectItem>
                    <SelectItem value="vocal">Vocal Enhance</SelectItem>
                    <SelectItem value="treble">Treble Boost</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <Button 
                onClick={() => processMutation.mutate({ files: selectedFiles, operation: 'eq' })}
                disabled={processMutation.isPending || selectedFiles.length !== 1}
                className="w-full py-3 bg-gradient-to-r from-teal-500 to-green-500 rounded-lg font-semibold hover:shadow-lg transition-all duration-300"
              >
                {processMutation.isPending ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <AudioLines className="mr-2 h-4 w-4" />
                )}
                Apply EQ
              </Button>
            </ToolCard>
          </motion.div>
        </div>
      </section>
    </motion.div>
  );
}
