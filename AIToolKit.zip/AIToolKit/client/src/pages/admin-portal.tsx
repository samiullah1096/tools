import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';
import { Plus, Edit, Trash2, Eye, Settings, BarChart3, Users, DollarSign, LogIn, LogOut } from 'lucide-react';

interface Ad {
  id: string;
  slotId: string;
  title: string;
  description?: string;
  provider: 'google' | 'custom' | 'html';
  code?: string;
  imageUrl?: string;
  clickUrl?: string;
  htmlContent?: string;
  active: boolean;
  createdAt: string;
}

export default function AdminPortal() {
  const { toast } = useToast();
  const { isAuthenticated, login, logout, token } = useAuth();
  const [ads, setAds] = useState<Ad[]>([]);
  const [selectedAd, setSelectedAd] = useState<Ad | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [loginForm, setLoginForm] = useState({ username: '', password: '' });
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  
  // Form state
  const [formData, setFormData] = useState({
    slotId: '',
    title: '',
    description: '',
    provider: 'custom' as 'google' | 'custom' | 'html',
    code: '',
    imageUrl: '',
    clickUrl: '',
    htmlContent: '',
    active: true
  });

  const adSlots = [
    { id: 'navbar-banner', name: 'Navigation Banner', position: 'header' },
    { id: 'hero-sidebar', name: 'Hero Sidebar', position: 'sidebar' },
    { id: 'tools-top', name: 'Tools Section Top', position: 'content' },
    { id: 'tools-bottom', name: 'Tools Section Bottom', position: 'content' },
    { id: 'modal-header', name: 'Tool Interface Header', position: 'modal' },
    { id: 'modal-sidebar', name: 'Tool Interface Sidebar', position: 'modal' },
    { id: 'footer-banner', name: 'Footer Banner', position: 'footer' }
  ];

  useEffect(() => {
    fetchAds();
  }, []);

  const fetchAds = async () => {
    if (!token) return;
    
    try {
      const response = await fetch('/api/admin/ads', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (response.ok) {
        const data = await response.json();
        setAds(data);
      }
    } catch (error) {
      console.error('Failed to fetch ads:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;
    
    try {
      const url = isEditing ? `/api/admin/ads/${selectedAd?.id}` : '/api/admin/ads';
      const method = isEditing ? 'PUT' : 'POST';
      
      const response = await fetch(url, {
        method,
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify(formData)
      });

      if (response.ok) {
        toast({
          title: isEditing ? 'Ad updated!' : 'Ad created!',
          description: `Ad for ${formData.slotId} has been ${isEditing ? 'updated' : 'created'} successfully.`
        });
        
        fetchAds();
        resetForm();
      } else {
        throw new Error('Failed to save ad');
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to save ad. Please try again.',
        variant: 'destructive'
      });
    }
  };

  const handleDelete = async (adId: string) => {
    if (!confirm('Are you sure you want to delete this ad?') || !token) return;
    
    try {
      const response = await fetch(`/api/admin/ads/${adId}`, { 
        method: 'DELETE',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (response.ok) {
        toast({ title: 'Ad deleted successfully' });
        fetchAds();
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to delete ad',
        variant: 'destructive'
      });
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoggingIn(true);
    
    const success = await login(loginForm.username, loginForm.password);
    if (success) {
      toast({ title: 'Login successful!' });
    } else {
      toast({ 
        title: 'Login failed', 
        description: 'Invalid credentials',
        variant: 'destructive' 
      });
    }
    setIsLoggingIn(false);
  };

  // Show login form if not authenticated
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-indigo-900 flex items-center justify-center p-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="w-full max-w-md"
        >
          <Card className="bg-white/10 border-white/20">
            <CardHeader>
              <CardTitle className="text-white text-center text-2xl">Admin Login</CardTitle>
              <CardDescription className="text-gray-300 text-center">
                Access the ToolSuite Pro Admin Portal
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <Label htmlFor="username" className="text-white">Username</Label>
                  <Input
                    id="username"
                    type="text"
                    value={loginForm.username}
                    onChange={(e) => setLoginForm({...loginForm, username: e.target.value})}
                    className="bg-white/10 border-white/20 text-white"
                    placeholder="Enter username"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="password" className="text-white">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    value={loginForm.password}
                    onChange={(e) => setLoginForm({...loginForm, password: e.target.value})}
                    className="bg-white/10 border-white/20 text-white"
                    placeholder="Enter password"
                    required
                  />
                </div>
                <Button 
                  type="submit" 
                  className="w-full bg-purple-600 hover:bg-purple-700"
                  disabled={isLoggingIn}
                >
                  <LogIn className="w-4 h-4 mr-2" />
                  {isLoggingIn ? 'Logging in...' : 'Login'}
                </Button>
              </form>
              <div className="mt-6 p-4 bg-yellow-900/20 rounded-lg border border-yellow-500/20">
                <p className="text-yellow-300 text-sm text-center">
                  <strong>Default Credentials:</strong><br />
                  Username: admin<br />
                  Password: admin123
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    );
  }

  const handleEdit = (ad: Ad) => {
    setSelectedAd(ad);
    setFormData({
      slotId: ad.slotId,
      title: ad.title,
      description: ad.description || '',
      provider: ad.provider,
      code: ad.code || '',
      imageUrl: ad.imageUrl || '',
      clickUrl: ad.clickUrl || '',
      htmlContent: ad.htmlContent || '',
      active: ad.active
    });
    setIsEditing(true);
  };

  const resetForm = () => {
    setFormData({
      slotId: '',
      title: '',
      description: '',
      provider: 'custom',
      code: '',
      imageUrl: '',
      clickUrl: '',
      htmlContent: '',
      active: true
    });
    setSelectedAd(null);
    setIsEditing(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-indigo-900 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          className="mb-8 flex justify-between items-start"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">Admin Portal</h1>
            <p className="text-gray-300">Manage advertisement slots across ToolSuite Pro</p>
          </div>
          <Button
            onClick={logout}
            variant="outline"
            className="border-white/20 text-white hover:bg-white/10"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </motion.div>

        {/* Navigation */}
        <div className="flex space-x-4 mb-8">
          {['dashboard', 'ads', 'analytics'].map((tab) => (
            <Button
              key={tab}
              onClick={() => setActiveTab(tab)}
              variant={activeTab === tab ? 'default' : 'outline'}
              className={`capitalize ${
                activeTab === tab 
                  ? 'bg-purple-600 hover:bg-purple-700' 
                  : 'bg-white/10 hover:bg-white/20 text-white border-white/20'
              }`}
            >
              {tab === 'dashboard' && <BarChart3 className="w-4 h-4 mr-2" />}
              {tab === 'ads' && <Settings className="w-4 h-4 mr-2" />}
              {tab === 'analytics' && <DollarSign className="w-4 h-4 mr-2" />}
              {tab}
            </Button>
          ))}
        </div>

        {/* Dashboard Tab */}
        {activeTab === 'dashboard' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card className="bg-white/10 border-white/20">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-300 text-sm">Total Ads</p>
                    <p className="text-3xl font-bold text-white">{ads.length}</p>
                  </div>
                  <Settings className="w-8 h-8 text-purple-400" />
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-white/10 border-white/20">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-300 text-sm">Active Ads</p>
                    <p className="text-3xl font-bold text-green-400">{ads.filter(ad => ad.active).length}</p>
                  </div>
                  <Eye className="w-8 h-8 text-green-400" />
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-white/10 border-white/20">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-300 text-sm">Ad Slots</p>
                    <p className="text-3xl font-bold text-blue-400">{adSlots.length}</p>
                  </div>
                  <BarChart3 className="w-8 h-8 text-blue-400" />
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-white/10 border-white/20">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-gray-300 text-sm">Revenue</p>
                    <p className="text-3xl font-bold text-yellow-400">$0</p>
                  </div>
                  <DollarSign className="w-8 h-8 text-yellow-400" />
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Ads Management Tab */}
        {activeTab === 'ads' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Ad Form */}
            <div className="lg:col-span-1">
              <Card className="bg-white/10 border-white/20">
                <CardHeader>
                  <CardTitle className="text-white">
                    {isEditing ? 'Edit Ad' : 'Create New Ad'}
                  </CardTitle>
                  <CardDescription className="text-gray-300">
                    Configure advertisement for display slots
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                      <Label htmlFor="slotId" className="text-white">Ad Slot</Label>
                      <Select 
                        value={formData.slotId} 
                        onValueChange={(value) => setFormData({...formData, slotId: value})}
                      >
                        <SelectTrigger className="bg-white/10 border-white/20 text-white">
                          <SelectValue placeholder="Select ad slot" />
                        </SelectTrigger>
                        <SelectContent>
                          {adSlots.map((slot) => (
                            <SelectItem key={slot.id} value={slot.id}>
                              {slot.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="title" className="text-white">Title</Label>
                      <Input
                        id="title"
                        value={formData.title}
                        onChange={(e) => setFormData({...formData, title: e.target.value})}
                        className="bg-white/10 border-white/20 text-white"
                        placeholder="Ad title"
                        required
                      />
                    </div>

                    <div>
                      <Label htmlFor="provider" className="text-white">Provider Type</Label>
                      <Select 
                        value={formData.provider} 
                        onValueChange={(value: 'google' | 'custom' | 'html') => setFormData({...formData, provider: value})}
                      >
                        <SelectTrigger className="bg-white/10 border-white/20 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="custom">Custom Image/Link</SelectItem>
                          <SelectItem value="google">Google AdSense</SelectItem>
                          <SelectItem value="html">Custom HTML</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {formData.provider === 'custom' && (
                      <>
                        <div>
                          <Label htmlFor="imageUrl" className="text-white">Image URL</Label>
                          <Input
                            id="imageUrl"
                            value={formData.imageUrl}
                            onChange={(e) => setFormData({...formData, imageUrl: e.target.value})}
                            className="bg-white/10 border-white/20 text-white"
                            placeholder="https://example.com/image.jpg"
                          />
                        </div>
                        <div>
                          <Label htmlFor="clickUrl" className="text-white">Click URL</Label>
                          <Input
                            id="clickUrl"
                            value={formData.clickUrl}
                            onChange={(e) => setFormData({...formData, clickUrl: e.target.value})}
                            className="bg-white/10 border-white/20 text-white"
                            placeholder="https://example.com"
                          />
                        </div>
                        <div>
                          <Label htmlFor="description" className="text-white">Description</Label>
                          <Textarea
                            id="description"
                            value={formData.description}
                            onChange={(e) => setFormData({...formData, description: e.target.value})}
                            className="bg-white/10 border-white/20 text-white"
                            placeholder="Ad description"
                          />
                        </div>
                      </>
                    )}

                    {formData.provider === 'google' && (
                      <div>
                        <Label htmlFor="code" className="text-white">AdSense Code</Label>
                        <Textarea
                          id="code"
                          value={formData.code}
                          onChange={(e) => setFormData({...formData, code: e.target.value})}
                          className="bg-white/10 border-white/20 text-white"
                          placeholder="Paste your AdSense code here"
                          rows={4}
                        />
                      </div>
                    )}

                    {formData.provider === 'html' && (
                      <div>
                        <Label htmlFor="htmlContent" className="text-white">HTML Content</Label>
                        <Textarea
                          id="htmlContent"
                          value={formData.htmlContent}
                          onChange={(e) => setFormData({...formData, htmlContent: e.target.value})}
                          className="bg-white/10 border-white/20 text-white"
                          placeholder="Custom HTML content"
                          rows={4}
                        />
                      </div>
                    )}

                    <div className="flex space-x-4">
                      <Button 
                        type="submit" 
                        className="flex-1 bg-purple-600 hover:bg-purple-700"
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        {isEditing ? 'Update Ad' : 'Create Ad'}
                      </Button>
                      {isEditing && (
                        <Button 
                          type="button" 
                          variant="outline"
                          onClick={resetForm}
                          className="border-white/20 text-white hover:bg-white/10"
                        >
                          Cancel
                        </Button>
                      )}
                    </div>
                  </form>
                </CardContent>
              </Card>
            </div>

            {/* Ads List */}
            <div className="lg:col-span-2">
              <Card className="bg-white/10 border-white/20">
                <CardHeader>
                  <CardTitle className="text-white">Active Advertisements</CardTitle>
                  <CardDescription className="text-gray-300">
                    Manage your advertisement placements
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {ads.map((ad) => (
                      <motion.div
                        key={ad.id}
                        className="p-4 bg-white/5 rounded-lg border border-white/10"
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <h3 className="text-white font-medium">{ad.title}</h3>
                            <p className="text-gray-400 text-sm">
                              Slot: {adSlots.find(s => s.id === ad.slotId)?.name || ad.slotId}
                            </p>
                            <p className="text-gray-400 text-sm">Provider: {ad.provider}</p>
                            <div className="flex items-center mt-2">
                              <div className={`w-2 h-2 rounded-full mr-2 ${ad.active ? 'bg-green-400' : 'bg-red-400'}`} />
                              <span className="text-gray-400 text-sm">{ad.active ? 'Active' : 'Inactive'}</span>
                            </div>
                          </div>
                          <div className="flex space-x-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleEdit(ad)}
                              className="border-white/20 text-white hover:bg-white/10"
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleDelete(ad.id)}
                              className="border-red-400/20 text-red-400 hover:bg-red-400/10"
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                    {ads.length === 0 && (
                      <div className="text-center py-8">
                        <p className="text-gray-400">No advertisements created yet</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )}

        {/* Analytics Tab */}
        {activeTab === 'analytics' && (
          <Card className="bg-white/10 border-white/20">
            <CardHeader>
              <CardTitle className="text-white">Analytics Dashboard</CardTitle>
              <CardDescription className="text-gray-300">
                Track ad performance and revenue
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <BarChart3 className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-white mb-2">Analytics Coming Soon</h3>
                <p className="text-gray-400">
                  Comprehensive analytics and revenue tracking will be available here
                </p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}