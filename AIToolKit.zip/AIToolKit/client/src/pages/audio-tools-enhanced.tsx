import { motion } from "framer-motion";
import { 
  Music, Volume2, Scissors, Merge, Download, Upload, 
  BarChart3, Headphones, Mic, Settings, Play, Pause,
  SkipForward, SkipBack, VolumeX, Volume1,
  FileAudio, Zap, Clock, Star, TrendingUp, Shield
} from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { useToast } from "@/hooks/use-toast";
import UploadZone from "@/components/ui/upload-zone";
import { useState, useRef } from "react";

export default function AudioToolsEnhanced() {
  const { toast } = useToast();
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [processing, setProcessing] = useState(false);
  const [activeTab, setActiveTab] = useState("popular");
  const [currentAudio, setCurrentAudio] = useState<HTMLAudioElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState([50]);
  const [playbackSpeed, setPlaybackSpeed] = useState([1]);
  const audioRef = useRef<HTMLAudioElement>(null);

  const audioTools = [
    {
      id: "mp3-converter",
      icon: FileAudio,
      title: "Audio Converter",
      description: "Convert between MP3, WAV, FLAC, AAC, OGG, and M4A",
      category: "Convert",
      popular: true,
      searchVolume: 245000,
      formats: ["MP3", "WAV", "FLAC", "AAC", "OGG", "M4A", "WMA"]
    },
    {
      id: "audio-trimmer",
      icon: Scissors,
      title: "Audio Trimmer",
      description: "Cut and trim audio files to exact specifications",
      category: "Edit",
      popular: true,
      searchVolume: 189000,
      formats: ["Precise trimming", "Fade in/out", "Split audio"]
    },
    {
      id: "audio-merger",
      icon: Merge,
      title: "Audio Merger",
      description: "Combine multiple audio files into one track",
      category: "Combine",
      popular: true,
      searchVolume: 156000,
      formats: ["Multiple formats", "Crossfade", "Custom gaps"]
    },
    {
      id: "volume-normalizer",
      icon: Volume2,
      title: "Volume Normalizer",
      description: "Normalize audio volume across multiple files",
      category: "Enhance",
      popular: true,
      searchVolume: 134000,
      formats: ["Peak normalization", "RMS normalization", "LUFS standard"]
    },
    {
      id: "noise-reduction",
      icon: BarChart3,
      title: "Noise Reduction",
      description: "Remove background noise and enhance audio quality",
      category: "Enhance",
      popular: true,
      searchVolume: 98000,
      formats: ["AI-powered", "Spectral analysis", "Voice enhancement"]
    },
    {
      id: "audio-compressor",
      icon: Download,
      title: "Audio Compressor",
      description: "Reduce audio file size without quality loss",
      category: "Optimize",
      popular: false,
      searchVolume: 87000,
      formats: ["Bitrate control", "Quality presets", "Batch processing"]
    },
    {
      id: "equalizer",
      icon: Settings,
      title: "Audio Equalizer",
      description: "Adjust frequency response and audio characteristics",
      category: "Enhance",
      popular: false,
      searchVolume: 76000,
      formats: ["10-band EQ", "Presets", "Custom curves"]
    },
    {
      id: "speed-changer",
      icon: Zap,
      title: "Speed Changer",
      description: "Change audio speed and pitch independently",
      category: "Edit",
      popular: false,
      searchVolume: 65000,
      formats: ["Pitch preservation", "Time stretching", "Tempo adjustment"]
    },
    {
      id: "audio-splitter",
      icon: Scissors,
      title: "Audio Splitter",
      description: "Split audio into multiple segments automatically",
      category: "Edit",
      popular: false,
      searchVolume: 54000,
      formats: ["Silence detection", "Equal parts", "Custom markers"]
    },
    {
      id: "voice-isolator",
      icon: Mic,
      title: "Voice Isolator",
      description: "Extract or remove vocals from audio tracks",
      category: "Enhance",
      popular: false,
      searchVolume: 43000,
      formats: ["Vocal removal", "Vocal isolation", "Karaoke maker"]
    }
  ];

  const popularTools = audioTools.filter(tool => tool.popular).sort((a, b) => b.searchVolume - a.searchVolume);
  const allTools = audioTools.sort((a, b) => b.searchVolume - a.searchVolume);
  const categories = [...new Set(audioTools.map(tool => tool.category))];

  const handleFileUpload = (files: File[]) => {
    setUploadedFiles(files);
    toast({
      title: "Audio files uploaded successfully!",
      description: `${files.length} file(s) ready for processing.`,
    });

    // Load first audio file for preview
    if (files[0] && files[0].type.startsWith('audio/')) {
      const url = URL.createObjectURL(files[0]);
      const audio = new Audio(url);
      setCurrentAudio(audio);
    }
  };

  const processAudio = async (toolId: string) => {
    if (uploadedFiles.length === 0) {
      toast({
        title: "No files selected",
        description: "Please upload audio files first.",
        variant: "destructive"
      });
      return;
    }

    setProcessing(true);
    
    // Simulate processing based on tool
    let processingTime = 2000;
    let resultMessage = "Audio processed successfully!";
    
    switch (toolId) {
      case "mp3-converter":
        processingTime = 3000;
        resultMessage = "Audio converted to MP3 format!";
        break;
      case "audio-trimmer":
        processingTime = 1500;
        resultMessage = "Audio trimmed successfully!";
        break;
      case "audio-merger":
        processingTime = 4000;
        resultMessage = "Audio files merged into one track!";
        break;
      case "noise-reduction":
        processingTime = 5000;
        resultMessage = "Background noise removed successfully!";
        break;
      default:
        resultMessage = `${audioTools.find(t => t.id === toolId)?.title} processing completed!`;
    }

    await new Promise(resolve => setTimeout(resolve, processingTime));
    
    toast({
      title: "Processing complete!",
      description: resultMessage,
    });
    
    setProcessing(false);
  };

  const togglePlayback = () => {
    if (currentAudio) {
      if (isPlaying) {
        currentAudio.pause();
      } else {
        currentAudio.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleVolumeChange = (value: number[]) => {
    setVolume(value);
    if (currentAudio) {
      currentAudio.volume = value[0] / 100;
    }
  };

  const handleSpeedChange = (value: number[]) => {
    setPlaybackSpeed(value);
    if (currentAudio) {
      currentAudio.playbackRate = value[0];
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-indigo-900">
      {/* SEO Head */}
      <title>Audio Tools - Free Audio Converter, Editor, Trimmer Online | ToolSuite Pro</title>
      
      {/* Hero Section */}
      <div className="relative pt-20 pb-16">
        <div className="absolute inset-0 bg-gradient-to-r from-purple-600/20 to-indigo-600/20 backdrop-blur-3xl"></div>
        <motion.div 
          className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <motion.div
            className="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-r from-purple-500 to-indigo-500 flex items-center justify-center"
            animate={{ 
              scale: [1, 1.1, 1],
              rotate: [0, 5, -5, 0] 
            }}
            transition={{ 
              duration: 4, 
              repeat: Infinity, 
              ease: "easeInOut" 
            }}
          >
            <Music className="w-10 h-10 text-white" />
          </motion.div>
          
          <motion.h1 
            className="text-5xl md:text-7xl font-bold text-white mb-6"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            Audio <span className="bg-gradient-to-r from-purple-400 to-indigo-400 bg-clip-text text-transparent">Tools</span>
          </motion.h1>
          
          <motion.p 
            className="text-xl text-gray-300 mb-8 max-w-4xl mx-auto"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            Professional audio editing and conversion tools. Convert formats, trim tracks, 
            remove noise, merge files, and enhance audio quality with studio-grade processing.
          </motion.p>
          
          <motion.div
            className="flex flex-wrap justify-center gap-4 mb-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
          >
            <div className="bg-purple-500/20 text-purple-300 border border-purple-500/30 rounded-full px-4 py-2 text-sm">
              <Star className="w-4 h-4 mr-1 inline" />
              Studio Quality
            </div>
            <div className="bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 rounded-full px-4 py-2 text-sm">
              <TrendingUp className="w-4 h-4 mr-1 inline" />
              1M+ Tracks Processed
            </div>
            <div className="bg-purple-500/20 text-purple-300 border border-purple-500/30 rounded-full px-4 py-2 text-sm">
              <Shield className="w-4 h-4 mr-1 inline" />
              Privacy Protected
            </div>
          </motion.div>
        </motion.div>
      </div>

      {/* Upload and Preview Section */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <motion.div 
          className="bg-white/10 backdrop-blur-lg rounded-xl border border-white/20 p-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          <h2 className="text-3xl font-bold text-white mb-6 text-center">Upload Your Audio Files</h2>
          <UploadZone
            onFilesUploaded={handleFileUpload}
            accept="audio/*,.mp3,.wav,.flac,.aac,.ogg,.m4a,.wma"
            maxFiles={10}
            maxSize={100 * 1024 * 1024}
          />
          
          {uploadedFiles.length > 0 && (
            <motion.div
              className="mt-6 space-y-4"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              transition={{ duration: 0.3 }}
            >
              <h3 className="text-white font-semibold">Uploaded Files:</h3>
              <div className="space-y-2">
                {uploadedFiles.map((file, index) => (
                  <div key={index} className="flex items-center justify-between bg-white/10 p-3 rounded">
                    <div className="flex items-center space-x-3">
                      <Music className="w-5 h-5 text-purple-400" />
                      <span className="text-white">{file.name}</span>
                    </div>
                    <span className="text-gray-400 text-sm">{(file.size / 1024 / 1024).toFixed(2)} MB</span>
                  </div>
                ))}
              </div>

              {/* Audio Preview Controls */}
              {currentAudio && (
                <div className="bg-white/5 p-4 rounded-lg">
                  <h4 className="text-white font-semibold mb-4">Audio Preview</h4>
                  <div className="flex items-center space-x-4 mb-4">
                    <Button
                      onClick={togglePlayback}
                      className="bg-purple-500 hover:bg-purple-600"
                    >
                      {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                    </Button>
                    <div className="flex-1">
                      <div className="flex items-center space-x-2">
                        <VolumeX className="w-4 h-4 text-white" />
                        <Slider
                          value={volume}
                          onValueChange={handleVolumeChange}
                          max={100}
                          step={1}
                          className="flex-1"
                        />
                        <Volume2 className="w-4 h-4 text-white" />
                        <span className="text-white text-sm w-8">{volume[0]}%</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <span className="text-white text-sm">Speed:</span>
                    <Slider
                      value={playbackSpeed}
                      onValueChange={handleSpeedChange}
                      min={0.5}
                      max={2}
                      step={0.1}
                      className="flex-1"
                    />
                    <span className="text-white text-sm w-8">{playbackSpeed[0]}x</span>
                  </div>
                </div>
              )}
            </motion.div>
          )}
        </motion.div>
      </div>

      {/* Tools Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <div className="w-full">
          <div className="grid grid-cols-3 mb-8 bg-white/10 backdrop-blur-lg rounded-lg p-1">
            <Button 
              onClick={() => setActiveTab("popular")}
              className={`${activeTab === "popular" ? "bg-purple-500" : "bg-transparent"} text-white hover:bg-purple-500/50`}
            >
              Most Popular
            </Button>
            <Button 
              onClick={() => setActiveTab("all")}
              className={`${activeTab === "all" ? "bg-purple-500" : "bg-transparent"} text-white hover:bg-purple-500/50`}
            >
              All Tools
            </Button>
            <Button 
              onClick={() => setActiveTab("categories")}
              className={`${activeTab === "categories" ? "bg-purple-500" : "bg-transparent"} text-white hover:bg-purple-500/50`}
            >
              By Category
            </Button>
          </div>

          {activeTab === "popular" && (
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              {popularTools.map((tool, index) => (
                <motion.div
                  key={tool.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.1 * index }}
                  whileHover={{ y: -5, scale: 1.02 }}
                >
                  <Card className="bg-white/10 backdrop-blur-lg border border-white/20 hover:border-purple-400/50 transition-all duration-300 h-full">
                    <CardHeader className="text-center">
                      <div className="relative">
                        <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-r from-purple-500 to-indigo-500 flex items-center justify-center">
                          <tool.icon className="w-8 h-8 text-white" />
                        </div>
                        <div className="absolute -top-2 -right-2 bg-yellow-500 text-black text-xs rounded-full px-2 py-1">
                          <TrendingUp className="w-3 h-3 mr-1 inline" />
                          HOT
                        </div>
                      </div>
                      <CardTitle className="text-white text-xl">{tool.title}</CardTitle>
                      <CardDescription className="text-gray-300">
                        {tool.description}
                      </CardDescription>
                      <div className="flex justify-between items-center mt-2">
                        <span className="text-xs text-purple-400 bg-purple-400/20 px-2 py-1 rounded-full">
                          {tool.category}
                        </span>
                        <span className="text-xs text-gray-400">
                          {(tool.searchVolume / 1000).toFixed(0)}k/month
                        </span>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="mb-4">
                        <p className="text-xs text-gray-400 mb-2">Features:</p>
                        <div className="flex flex-wrap gap-1">
                          {tool.formats.slice(0, 3).map((format, idx) => (
                            <span key={idx} className="text-xs bg-gray-600/50 text-gray-300 px-2 py-1 rounded">
                              {format}
                            </span>
                          ))}
                        </div>
                      </div>
                      <Button 
                        onClick={() => processAudio(tool.id)}
                        disabled={processing || uploadedFiles.length === 0}
                        className="w-full bg-gradient-to-r from-purple-500 to-indigo-500 hover:from-purple-600 hover:to-indigo-600 text-white font-semibold"
                      >
                        {processing ? (
                          <>
                            <Clock className="w-4 h-4 mr-2 animate-spin" />
                            Processing...
                          </>
                        ) : (
                          "Use Tool"
                        )}
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          )}

          {activeTab === "all" && (
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              {allTools.map((tool, index) => (
                <Card key={tool.id} className="bg-white/10 backdrop-blur-lg border border-white/20 hover:border-purple-400/50 transition-all duration-300">
                  <CardHeader className="text-center pb-4">
                    <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-gradient-to-r from-purple-500 to-indigo-500 flex items-center justify-center">
                      <tool.icon className="w-6 h-6 text-white" />
                    </div>
                    <CardTitle className="text-white text-lg">{tool.title}</CardTitle>
                    <span className="text-xs text-purple-400 bg-purple-400/20 px-2 py-1 rounded-full">
                      {tool.category}
                    </span>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <Button 
                      onClick={() => processAudio(tool.id)}
                      disabled={processing || uploadedFiles.length === 0}
                      className="w-full bg-gradient-to-r from-purple-500 to-indigo-500 hover:from-purple-600 hover:to-indigo-600 text-white font-semibold text-sm"
                    >
                      Use Now
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </motion.div>
          )}

          {activeTab === "categories" && (
            <div className="space-y-8">
              {categories.map((category, categoryIndex) => (
                <motion.div
                  key={category}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.1 * categoryIndex }}
                >
                  <h3 className="text-2xl font-bold text-white mb-4">{category} Tools</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {allTools.filter(tool => tool.category === category).map((tool) => (
                      <Card key={tool.id} className="bg-white/10 backdrop-blur-lg border border-white/20 hover:border-purple-400/50 transition-all duration-300">
                        <CardContent className="p-4">
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 rounded-full bg-gradient-to-r from-purple-500 to-indigo-500 flex items-center justify-center">
                              <tool.icon className="w-5 h-5 text-white" />
                            </div>
                            <div className="flex-1">
                              <h4 className="text-white font-semibold">{tool.title}</h4>
                              <p className="text-gray-400 text-sm">{tool.description}</p>
                            </div>
                            <Button 
                              onClick={() => processAudio(tool.id)}
                              disabled={processing || uploadedFiles.length === 0}
                              size="sm"
                              className="bg-gradient-to-r from-purple-500 to-indigo-500 hover:from-purple-600 hover:to-indigo-600"
                            >
                              Use
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>

        {/* Stats Section */}
        <motion.div
          className="mt-16 bg-white/5 backdrop-blur-lg rounded-xl border border-white/10 p-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1.0 }}
        >
          <h3 className="text-2xl font-bold text-white mb-6 text-center">Professional Audio Processing</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-400 mb-2">24-bit</div>
              <div className="text-white">Audio Quality</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-indigo-400 mb-2">10+</div>
              <div className="text-white">Audio Formats</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-400 mb-2">AI</div>
              <div className="text-white">Noise Reduction</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-indigo-400 mb-2">Instant</div>
              <div className="text-white">Processing</div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}