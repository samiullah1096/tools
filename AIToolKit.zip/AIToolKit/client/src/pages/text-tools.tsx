import { motion } from "framer-motion";
import { Type, FileText, Edit3, Zap, Hash, AlignLeft, Code, Search, Clipboard, BookOpen } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

export default function TextTools() {
  const { toast } = useToast();
  const [text, setText] = useState("");
  const [result, setResult] = useState("");

  const textTools = [
    {
      id: "word-counter",
      icon: Hash,
      title: "Word Counter",
      description: "Count words, characters, paragraphs, and reading time",
      category: "Analysis"
    },
    {
      id: "text-case-converter",
      icon: Type,
      title: "Case Converter",
      description: "Convert text to uppercase, lowercase, title case, and more",
      category: "Formatting"
    },
    {
      id: "remove-duplicates",
      icon: FileText,
      title: "Remove Duplicates",
      description: "Remove duplicate lines from your text instantly",
      category: "Cleanup"
    },
    {
      id: "text-replacer",
      icon: Edit3,
      title: "Find & Replace",
      description: "Find and replace text with advanced options",
      category: "Editing"
    },
    {
      id: "text-formatter",
      icon: AlignLeft,
      title: "Text Formatter",
      description: "Format and beautify your text with proper spacing",
      category: "Formatting"
    },
    {
      id: "html-encoder",
      icon: Code,
      title: "HTML Encoder/Decoder",
      description: "Encode or decode HTML entities and special characters",
      category: "Developer"
    },
    {
      id: "url-encoder",
      icon: Zap,
      title: "URL Encoder/Decoder",
      description: "Encode or decode URLs for safe web transmission",
      category: "Developer"
    },
    {
      id: "base64-encoder",
      icon: Search,
      title: "Base64 Encoder/Decoder",
      description: "Encode or decode Base64 strings",
      category: "Developer"
    },
    {
      id: "text-to-slug",
      icon: Clipboard,
      title: "Text to Slug",
      description: "Convert text to URL-friendly slugs",
      category: "Developer"
    },
    {
      id: "lorem-generator",
      icon: BookOpen,
      title: "Lorem Ipsum Generator",
      description: "Generate placeholder text for design mockups",
      category: "Content"
    }
  ];

  const processText = (toolId: string) => {
    let processed = "";
    
    switch (toolId) {
      case "word-counter":
        const words = text.trim() ? text.trim().split(/\s+/).length : 0;
        const characters = text.length;
        const charactersNoSpaces = text.replace(/\s/g, '').length;
        const paragraphs = text.trim() ? text.split(/\n\s*\n/).length : 0;
        const readingTime = Math.ceil(words / 200);
        
        processed = `Words: ${words}\nCharacters: ${characters}\nCharacters (no spaces): ${charactersNoSpaces}\nParagraphs: ${paragraphs}\nReading time: ${readingTime} minute(s)`;
        break;
        
      case "text-case-converter":
        processed = `Uppercase: ${text.toUpperCase()}\n\nLowercase: ${text.toLowerCase()}\n\nTitle Case: ${text.replace(/\w\S*/g, (txt) => txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase())}\n\nSentence case: ${text.charAt(0).toUpperCase() + text.slice(1).toLowerCase()}`;
        break;
        
      case "remove-duplicates":
        const lines = text.split('\n');
        const uniqueLines = Array.from(new Set(lines));
        processed = uniqueLines.join('\n');
        break;
        
      case "html-encoder":
        processed = text
          .replace(/&/g, '&amp;')
          .replace(/</g, '&lt;')
          .replace(/>/g, '&gt;')
          .replace(/"/g, '&quot;')
          .replace(/'/g, '&#39;');
        break;
        
      case "url-encoder":
        processed = encodeURIComponent(text);
        break;
        
      case "base64-encoder":
        try {
          processed = btoa(text);
        } catch (error) {
          processed = "Error: Invalid characters for Base64 encoding";
        }
        break;
        
      case "text-to-slug":
        processed = text
          .toLowerCase()
          .trim()
          .replace(/[^\w\s-]/g, '')
          .replace(/[\s_-]+/g, '-')
          .replace(/^-+|-+$/g, '');
        break;
        
      case "lorem-generator":
        const loremText = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.";
        const paragraphCount = parseInt(text) || 3;
        processed = Array(paragraphCount).fill(loremText).join('\n\n');
        break;
        
      default:
        processed = "Tool not implemented yet";
    }
    
    setResult(processed);
    toast({
      title: "Text processed successfully!",
      description: "Your text has been processed and is ready to copy.",
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-indigo-900">
      {/* SEO Head equivalent */}
      <title>Free Text Tools - Word Counter, Case Converter, Text Formatter | ToolSuite Pro</title>
      
      {/* Hero Section */}
      <div className="relative pt-20 pb-16">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20 backdrop-blur-3xl"></div>
        <motion.div 
          className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <motion.h1 
            className="text-5xl md:text-7xl font-bold text-white mb-6"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            Text <span className="bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent">Tools</span>
          </motion.h1>
          <motion.p 
            className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            Professional text processing tools for writers, developers, and content creators. 
            Count words, format text, encode data, and more - all free and instant.
          </motion.p>
        </motion.div>
      </div>

      {/* Tools Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
        >
          {textTools.map((tool, index) => (
            <motion.div
              key={tool.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 * index }}
              whileHover={{ y: -5 }}
            >
              <Card className="bg-white/10 backdrop-blur-lg border border-white/20 hover:border-purple-400/50 transition-all duration-300 h-full">
                <CardHeader className="text-center">
                  <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-r from-cyan-500 to-purple-500 flex items-center justify-center">
                    <tool.icon className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className="text-white text-xl">{tool.title}</CardTitle>
                  <CardDescription className="text-gray-300">
                    {tool.description}
                  </CardDescription>
                  <span className="text-xs text-cyan-400 bg-cyan-400/20 px-2 py-1 rounded-full">
                    {tool.category}
                  </span>
                </CardHeader>
                <CardContent>
                  <Button 
                    onClick={() => {
                      const element = document.getElementById('text-processor');
                      element?.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="w-full bg-gradient-to-r from-cyan-500 to-purple-500 hover:from-cyan-600 hover:to-purple-600 text-white font-semibold py-2 px-4 rounded-lg transition-all duration-300"
                  >
                    Use Tool
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* Text Processor */}
        <motion.div
          id="text-processor"
          className="bg-white/10 backdrop-blur-lg rounded-xl border border-white/20 p-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          <h2 className="text-2xl font-bold text-white mb-6">Text Processor</h2>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <label className="block text-white mb-2">Input Text:</label>
              <Textarea
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Enter or paste your text here..."
                className="min-h-[200px] bg-white/5 border-white/20 text-white"
              />
            </div>
            
            <div>
              <label className="block text-white mb-2">Result:</label>
              <Textarea
                value={result}
                readOnly
                placeholder="Processed text will appear here..."
                className="min-h-[200px] bg-white/5 border-white/20 text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mt-6">
            {textTools.slice(0, 10).map((tool) => (
              <Button
                key={tool.id}
                onClick={() => processText(tool.id)}
                variant="outline"
                className="border-white/20 text-white hover:bg-white/10"
              >
                {tool.title.split(' ')[0]}
              </Button>
            ))}
          </div>

          <Button
            onClick={() => navigator.clipboard.writeText(result)}
            className="mt-4 bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600"
            disabled={!result}
          >
            Copy Result
          </Button>
        </motion.div>
      </div>
    </div>
  );
}