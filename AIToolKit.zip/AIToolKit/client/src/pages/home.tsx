import { motion } from "framer-motion";
import { Link } from "wouter";
import { 
  Rocket, 
  Play, 
  FileText, 
  Headphones, 
  Image, 
  Bot, 
  Video, 
  Shield,
  Check
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { pageTransition, staggerContainer, staggerItem, floatingElement } from "@/lib/animations";
import AdSlot from "@/components/ui/ad-slot";

const features = [
  {
    icon: <FileText className="text-2xl text-white" />,
    title: "PDF Mastery",
    description: "Merge, split, compress, and convert PDFs with advanced AI-powered optimization.",
    gradient: "bg-gradient-to-r from-red-500 to-pink-500",
    features: ["Smart compression", "OCR text extraction", "Password protection"],
    link: "/pdf-tools"
  },
  {
    icon: <Headphones className="text-2xl text-white" />,
    title: "Audio Studio",
    description: "Professional audio editing with AI noise reduction and format conversion.",
    gradient: "bg-gradient-to-r from-green-500 to-teal-500",
    features: ["Format conversion", "Noise reduction", "Audio enhancement"],
    link: "/audio-tools"
  },
  {
    icon: <Image className="text-2xl text-white" />,
    title: "Image Editor",
    description: "Advanced image processing with AI-powered background removal and enhancement.",
    gradient: "bg-gradient-to-r from-purple-500 to-pink-500",
    features: ["Background removal", "Smart cropping", "Batch processing"],
    link: "/image-tools"
  },
  {
    icon: <Bot className="text-2xl text-white" />,
    title: "AI Powered",
    description: "Harness artificial intelligence for content generation and intelligent processing.",
    gradient: "bg-gradient-to-r from-blue-500 to-cyan-500",
    features: ["Text generation", "Content analysis", "Smart suggestions"],
    link: "/ai-tools"
  },
  {
    icon: <Video className="text-2xl text-white" />,
    title: "Video Suite",
    description: "Professional video editing with compression, conversion, and enhancement tools.",
    gradient: "bg-gradient-to-r from-orange-500 to-red-500",
    features: ["Format conversion", "Smart compression", "Quality enhancement"],
    link: "/video-tools"
  },
  {
    icon: <Shield className="text-2xl text-white" />,
    title: "Secure & Private",
    description: "End-to-end encryption ensures your files remain private and secure throughout processing.",
    gradient: "bg-gradient-to-r from-indigo-500 to-purple-500",
    features: ["Local processing", "Zero data retention", "End-to-end encryption"],
    link: "/"
  },
];

export default function Home() {
  return (
    <motion.div {...pageTransition}>
      {/* Hero Section */}
      <section className="min-h-screen flex items-center justify-center relative overflow-hidden">
        <div className="container mx-auto px-6 text-center">
          <motion.div 
            className="max-w-4xl mx-auto"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <motion.h1 
              className="text-5xl md:text-7xl font-bold mb-6 leading-tight"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <span className="bg-gradient-to-r from-white via-indigo-200 to-violet-200 bg-clip-text text-transparent">
                The Ultimate
              </span>
              <br />
              <span className="animated-gradient bg-clip-text text-transparent">
                Digital Toolkit
              </span>
            </motion.h1>
            
            <motion.p 
              className="text-xl md:text-2xl text-slate-300 mb-8"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
            >
              Transform your workflow with AI-powered PDF, Audio, Image, and Video processing tools
            </motion.p>
            
            <motion.div 
              className="flex flex-col sm:flex-row gap-4 justify-center items-center"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
            >
              <Button className="px-8 py-4 bg-gradient-to-r from-indigo-500 to-violet-500 rounded-full text-lg font-semibold hover:shadow-2xl hover:scale-105 transition-all duration-300 animate-glow">
                <Rocket className="mr-2 h-5 w-5" />
                Start Creating
              </Button>
              <Button 
                variant="outline" 
                className="px-8 py-4 glass-light rounded-full text-lg font-semibold hover:bg-white/20 transition-all duration-300"
              >
                <Play className="mr-2 h-5 w-5" />
                Watch Demo
              </Button>
            </motion.div>
          </motion.div>
        </div>
        
        {/* Floating Elements */}
        <motion.div 
          className="absolute top-20 left-10 w-20 h-20 bg-indigo-500/20 rounded-full"
          {...floatingElement}
        />
        <motion.div 
          className="absolute bottom-32 right-10 w-16 h-16 bg-violet-500/20 rounded-full"
          animate={{
            y: [0, -20, 0],
            transition: { duration: 4, repeat: Infinity, ease: "easeInOut" }
          }}
        />
        <motion.div 
          className="absolute top-1/2 right-20 w-12 h-12 bg-cyan-500/20 rounded-full"
          animate={{
            y: [-10, 10, -10],
            transition: { duration: 5, repeat: Infinity, ease: "easeInOut", delay: -2 }
          }}
        />
      </section>

      {/* Features Section */}
      <section className="py-20 relative">
        <div className="container mx-auto px-6">
          <motion.div 
            className="text-center mb-16"
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-4 text-gradient">
              Powerful Tools, Seamless Experience
            </h2>
            <p className="text-xl text-slate-300 max-w-2xl mx-auto">
              Everything you need to handle digital content with precision and speed
            </p>
          </motion.div>
          
          <motion.div 
            className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
            variants={staggerContainer}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
          >
            {features.map((feature, index) => (
              <motion.div
                key={index}
                variants={staggerItem}
                className="feature-card glass-morphism rounded-2xl p-8 group"
                whileHover={{ 
                  y: -8,
                  transition: { type: "spring", stiffness: 300, damping: 10 }
                }}
              >
                <Link href={feature.link}>
                  <div className={`w-16 h-16 ${feature.gradient} rounded-xl flex items-center justify-center mb-6 animate-float group-hover:scale-110 transition-transform duration-300`}>
                    {feature.icon}
                  </div>
                  <h3 className="text-2xl font-bold mb-4 group-hover:text-indigo-400 transition-colors">
                    {feature.title}
                  </h3>
                  <p className="text-slate-300 mb-6">{feature.description}</p>
                  <ul className="space-y-2 text-sm text-slate-400">
                    {feature.features.map((item, i) => (
                      <li key={i} className="flex items-center">
                        <Check className="text-green-400 mr-2 h-4 w-4" />
                        {item}
                      </li>
                    ))}
                  </ul>
                </Link>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 relative">
        <div className="container mx-auto px-6 text-center">
          <motion.div 
            className="max-w-3xl mx-auto glass-morphism rounded-3xl p-12"
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl md:text-5xl font-bold mb-6 text-gradient">
              Ready to Transform Your Workflow?
            </h2>
            <p className="text-xl text-slate-300 mb-8">
              Join thousands of professionals who trust ToolSuite Pro for their digital content needs
            </p>
            <Button className="px-10 py-4 bg-gradient-to-r from-indigo-500 to-violet-500 rounded-full text-lg font-semibold hover:shadow-2xl hover:scale-105 transition-all duration-300 animate-glow">
              <Rocket className="mr-2 h-5 w-5" />
              Get Started Free
            </Button>
          </motion.div>
          
          {/* CTA Section Ad Slot */}
          <motion.div 
            className="mt-12 flex justify-center"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <AdSlot slotId="footer-banner" position="footer" size="banner" />
          </motion.div>
        </div>
      </section>
    </motion.div>
  );
}
