import { motion } from "framer-motion";
import { 
  Image, Crop, Move, Palette, Wand2, Download, Upload,
  Scissors, RotateCw, Layers, Zap, Eye, Maximize,
  Minimize, Copy, Star, TrendingUp, Shield, Sparkles,
  Camera, Filter, Sun, Moon, FileImage
} from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { useToast } from "@/hooks/use-toast";
import UploadZone from "@/components/ui/upload-zone";
import { useState, useRef } from "react";

export default function ImageToolsEnhanced() {
  const { toast } = useToast();
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [processing, setProcessing] = useState(false);
  const [activeTab, setActiveTab] = useState("popular");
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [brightness, setBrightness] = useState([100]);
  const [contrast, setContrast] = useState([100]);
  const [saturation, setSaturation] = useState([100]);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const imageTools = [
    {
      id: "background-remover",
      icon: Layers,
      title: "Background Remover",
      description: "Remove background from images with AI precision",
      category: "AI Enhancement",
      popular: true,
      searchVolume: 892000,
      features: ["AI-powered", "Instant processing", "High precision"]
    },
    {
      id: "image-resizer",
      icon: Move,
      title: "Image Resizer",
      description: "Resize images while maintaining quality",
      category: "Resize",
      popular: true,
      searchVolume: 567000,
      features: ["Maintain aspect ratio", "Bulk resize", "Custom dimensions"]
    },
    {
      id: "jpg-png-converter",
      icon: FileImage,
      title: "Image Converter",
      description: "Convert between JPG, PNG, WEBP, GIF, and more",
      category: "Convert",
      popular: true,
      searchVolume: 445000,
      features: ["15+ formats", "Quality control", "Batch conversion"]
    },
    {
      id: "image-compressor",
      icon: Minimize,
      title: "Image Compressor",
      description: "Reduce image file size without quality loss",
      category: "Optimize",
      popular: true,
      searchVolume: 389000,
      features: ["Smart compression", "Quality preview", "Size reduction"]
    },
    {
      id: "photo-enhancer",
      icon: Sparkles,
      title: "AI Photo Enhancer",
      description: "Enhance image quality with AI upscaling",
      category: "AI Enhancement",
      popular: true,
      searchVolume: 334000,
      features: ["2x/4x upscaling", "Detail enhancement", "Noise reduction"]
    },
    {
      id: "image-cropper",
      icon: Crop,
      title: "Image Cropper",
      description: "Crop images with precision and custom ratios",
      category: "Edit",
      popular: false,
      searchVolume: 298000,
      features: ["Custom ratios", "Smart crop", "Freeform selection"]
    },
    {
      id: "watermark-remover",
      icon: Eye,
      title: "Watermark Remover",
      description: "Remove watermarks and unwanted objects",
      category: "AI Enhancement",
      popular: false,
      searchVolume: 267000,
      features: ["AI object removal", "Inpainting", "Content-aware fill"]
    },
    {
      id: "color-palette",
      icon: Palette,
      title: "Color Palette Generator",
      description: "Extract color palettes from images",
      category: "Design",
      popular: false,
      searchVolume: 234000,
      features: ["Dominant colors", "Hex codes", "Color harmony"]
    },
    {
      id: "image-filters",
      icon: Filter,
      title: "Photo Filters",
      description: "Apply professional filters and effects",
      category: "Edit",
      popular: false,
      searchVolume: 187000,
      features: ["20+ filters", "Vintage effects", "Custom adjustments"]
    },
    {
      id: "cartoon-generator",
      icon: Wand2,
      title: "Cartoon Generator",
      description: "Convert photos to cartoon style with AI",
      category: "AI Enhancement",
      popular: false,
      searchVolume: 156000,
      features: ["Multiple styles", "High quality", "Instant preview"]
    },
    {
      id: "image-rotate",
      icon: RotateCw,
      title: "Image Rotator",
      description: "Rotate and flip images in any direction",
      category: "Edit",
      popular: false,
      searchVolume: 123000,
      features: ["Any angle", "Batch rotate", "Auto-straighten"]
    },
    {
      id: "meme-generator",
      icon: Camera,
      title: "Meme Generator",
      description: "Create memes with text and templates",
      category: "Fun",
      popular: false,
      searchVolume: 98000,
      features: ["Popular templates", "Custom text", "Social sharing"]
    }
  ];

  const popularTools = imageTools.filter(tool => tool.popular).sort((a, b) => b.searchVolume - a.searchVolume);
  const allTools = imageTools.sort((a, b) => b.searchVolume - a.searchVolume);
  const categories = [...new Set(imageTools.map(tool => tool.category))];

  const handleFileUpload = (files: File[]) => {
    setUploadedFiles(files);
    toast({
      title: "Images uploaded successfully!",
      description: `${files.length} image(s) ready for processing.`,
    });

    // Load first image for preview
    if (files[0] && files[0].type.startsWith('image/')) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setPreviewImage(e.target?.result as string);
      };
      reader.readAsDataURL(files[0]);
    }
  };

  const processImage = async (toolId: string) => {
    if (uploadedFiles.length === 0) {
      toast({
        title: "No files selected",
        description: "Please upload images first.",
        variant: "destructive"
      });
      return;
    }

    setProcessing(true);
    
    let processingTime = 2000;
    let resultMessage = "Image processed successfully!";
    
    switch (toolId) {
      case "background-remover":
        processingTime = 4000;
        resultMessage = "Background removed with AI precision!";
        break;
      case "image-resizer":
        processingTime = 1000;
        resultMessage = "Image resized successfully!";
        break;
      case "photo-enhancer":
        processingTime = 6000;
        resultMessage = "Image enhanced with AI upscaling!";
        break;
      case "jpg-png-converter":
        processingTime = 1500;
        resultMessage = "Image format converted successfully!";
        break;
      default:
        resultMessage = `${imageTools.find(t => t.id === toolId)?.title} processing completed!`;
    }

    await new Promise(resolve => setTimeout(resolve, processingTime));
    
    toast({
      title: "Processing complete!",
      description: resultMessage,
    });
    
    setProcessing(false);
  };

  const applyFilter = (filterType: string) => {
    if (!previewImage || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    img.onload = () => {
      canvas.width = img.width;
      canvas.height = img.height;
      
      // Apply brightness, contrast, saturation
      ctx.filter = `brightness(${brightness[0]}%) contrast(${contrast[0]}%) saturate(${saturation[0]}%)`;
      
      ctx.drawImage(img, 0, 0);
      
      // Convert back to preview
      const dataURL = canvas.toDataURL();
      setPreviewImage(dataURL);
    };
    img.src = previewImage;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-pink-900 to-purple-900">
      {/* SEO Head */}
      <title>Image Tools - Free Image Editor, Background Remover, Converter | ToolSuite Pro</title>
      
      {/* Hero Section */}
      <div className="relative pt-20 pb-16">
        <div className="absolute inset-0 bg-gradient-to-r from-pink-600/20 to-purple-600/20 backdrop-blur-3xl"></div>
        <motion.div 
          className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <motion.div
            className="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-r from-pink-500 to-purple-500 flex items-center justify-center"
            animate={{ 
              boxShadow: [
                "0 0 20px rgba(236, 72, 153, 0.3)",
                "0 0 40px rgba(236, 72, 153, 0.6)",
                "0 0 20px rgba(236, 72, 153, 0.3)"
              ]
            }}
            transition={{ 
              duration: 3, 
              repeat: Infinity, 
              ease: "easeInOut" 
            }}
          >
            <Image className="w-10 h-10 text-white" />
          </motion.div>
          
          <motion.h1 
            className="text-5xl md:text-7xl font-bold text-white mb-6"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            Image <span className="bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">Tools</span>
          </motion.h1>
          
          <motion.p 
            className="text-xl text-gray-300 mb-8 max-w-4xl mx-auto"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            Professional image editing powered by AI. Remove backgrounds, enhance photos, 
            convert formats, resize images, and apply stunning effects with one click.
          </motion.p>
          
          <motion.div
            className="flex flex-wrap justify-center gap-4 mb-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
          >
            <div className="bg-pink-500/20 text-pink-300 border border-pink-500/30 rounded-full px-4 py-2 text-sm">
              <Sparkles className="w-4 h-4 mr-1 inline" />
              AI-Powered
            </div>
            <div className="bg-purple-500/20 text-purple-300 border border-purple-500/30 rounded-full px-4 py-2 text-sm">
              <TrendingUp className="w-4 h-4 mr-1 inline" />
              5M+ Images Processed
            </div>
            <div className="bg-pink-500/20 text-pink-300 border border-pink-500/30 rounded-full px-4 py-2 text-sm">
              <Shield className="w-4 h-4 mr-1 inline" />
              Privacy First
            </div>
          </motion.div>
        </motion.div>
      </div>

      {/* Upload and Preview Section */}
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <motion.div 
          className="bg-white/10 backdrop-blur-lg rounded-xl border border-white/20 p-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          <h2 className="text-3xl font-bold text-white mb-6 text-center">Upload Your Images</h2>
          <UploadZone
            onFilesUploaded={handleFileUpload}
            accept="image/*,.jpg,.jpeg,.png,.gif,.webp,.bmp,.svg"
            maxFiles={10}
            maxSize={50 * 1024 * 1024}
          />
          
          {uploadedFiles.length > 0 && (
            <motion.div
              className="mt-6 space-y-4"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              transition={{ duration: 0.3 }}
            >
              <h3 className="text-white font-semibold">Uploaded Images:</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {uploadedFiles.map((file, index) => (
                  <div key={index} className="bg-white/10 p-3 rounded-lg">
                    <div className="aspect-square bg-gray-700 rounded mb-2 flex items-center justify-center">
                      <Image className="w-8 h-8 text-gray-400" />
                    </div>
                    <p className="text-white text-sm truncate">{file.name}</p>
                    <p className="text-gray-400 text-xs">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
                  </div>
                ))}
              </div>

              {/* Image Preview and Editor */}
              {previewImage && (
                <div className="bg-white/5 p-4 rounded-lg">
                  <h4 className="text-white font-semibold mb-4">Image Preview & Quick Edit</h4>
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div className="aspect-video bg-gray-800 rounded-lg flex items-center justify-center overflow-hidden">
                        <img 
                          src={previewImage} 
                          alt="Preview" 
                          className="max-w-full max-h-full object-contain"
                        />
                      </div>
                      <canvas ref={canvasRef} className="hidden" />
                    </div>
                    
                    <div className="space-y-4">
                      <div>
                        <label className="text-white text-sm mb-2 block">Brightness: {brightness[0]}%</label>
                        <Slider
                          value={brightness}
                          onValueChange={setBrightness}
                          min={0}
                          max={200}
                          step={1}
                          className="w-full"
                        />
                      </div>
                      
                      <div>
                        <label className="text-white text-sm mb-2 block">Contrast: {contrast[0]}%</label>
                        <Slider
                          value={contrast}
                          onValueChange={setContrast}
                          min={0}
                          max={200}
                          step={1}
                          className="w-full"
                        />
                      </div>
                      
                      <div>
                        <label className="text-white text-sm mb-2 block">Saturation: {saturation[0]}%</label>
                        <Slider
                          value={saturation}
                          onValueChange={setSaturation}
                          min={0}
                          max={200}
                          step={1}
                          className="w-full"
                        />
                      </div>
                      
                      <Button
                        onClick={() => applyFilter('custom')}
                        className="w-full bg-pink-500 hover:bg-pink-600"
                      >
                        Apply Adjustments
                      </Button>
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          )}
        </motion.div>
      </div>

      {/* Tools Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <div className="w-full">
          <div className="grid grid-cols-3 mb-8 bg-white/10 backdrop-blur-lg rounded-lg p-1">
            <Button 
              onClick={() => setActiveTab("popular")}
              className={`${activeTab === "popular" ? "bg-pink-500" : "bg-transparent"} text-white hover:bg-pink-500/50`}
            >
              Most Popular
            </Button>
            <Button 
              onClick={() => setActiveTab("all")}
              className={`${activeTab === "all" ? "bg-pink-500" : "bg-transparent"} text-white hover:bg-pink-500/50`}
            >
              All Tools
            </Button>
            <Button 
              onClick={() => setActiveTab("categories")}
              className={`${activeTab === "categories" ? "bg-pink-500" : "bg-transparent"} text-white hover:bg-pink-500/50`}
            >
              By Category
            </Button>
          </div>

          {activeTab === "popular" && (
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              {popularTools.map((tool, index) => (
                <motion.div
                  key={tool.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.1 * index }}
                  whileHover={{ y: -5, scale: 1.02 }}
                >
                  <Card className="bg-white/10 backdrop-blur-lg border border-white/20 hover:border-pink-400/50 transition-all duration-300 h-full">
                    <CardHeader className="text-center">
                      <div className="relative">
                        <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-r from-pink-500 to-purple-500 flex items-center justify-center">
                          <tool.icon className="w-8 h-8 text-white" />
                        </div>
                        <div className="absolute -top-2 -right-2 bg-yellow-500 text-black text-xs rounded-full px-2 py-1">
                          <Star className="w-3 h-3 mr-1 inline" />
                          TOP
                        </div>
                      </div>
                      <CardTitle className="text-white text-xl">{tool.title}</CardTitle>
                      <CardDescription className="text-gray-300">
                        {tool.description}
                      </CardDescription>
                      <div className="flex justify-between items-center mt-2">
                        <span className="text-xs text-pink-400 bg-pink-400/20 px-2 py-1 rounded-full">
                          {tool.category}
                        </span>
                        <span className="text-xs text-gray-400">
                          {(tool.searchVolume / 1000).toFixed(0)}k/month
                        </span>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="mb-4">
                        <p className="text-xs text-gray-400 mb-2">Key Features:</p>
                        <div className="flex flex-wrap gap-1">
                          {tool.features.map((feature, idx) => (
                            <span key={idx} className="text-xs bg-gray-600/50 text-gray-300 px-2 py-1 rounded">
                              {feature}
                            </span>
                          ))}
                        </div>
                      </div>
                      <Button 
                        onClick={() => processImage(tool.id)}
                        disabled={processing || uploadedFiles.length === 0}
                        className="w-full bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600 text-white font-semibold"
                      >
                        {processing ? "Processing..." : "Use Tool"}
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </motion.div>
          )}

          {activeTab === "all" && (
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              {allTools.map((tool, index) => (
                <Card key={tool.id} className="bg-white/10 backdrop-blur-lg border border-white/20 hover:border-pink-400/50 transition-all duration-300">
                  <CardHeader className="text-center pb-4">
                    <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-gradient-to-r from-pink-500 to-purple-500 flex items-center justify-center">
                      <tool.icon className="w-6 h-6 text-white" />
                    </div>
                    <CardTitle className="text-white text-lg">{tool.title}</CardTitle>
                    <span className="text-xs text-pink-400 bg-pink-400/20 px-2 py-1 rounded-full">
                      {tool.category}
                    </span>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <Button 
                      onClick={() => processImage(tool.id)}
                      disabled={processing || uploadedFiles.length === 0}
                      className="w-full bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600 text-white font-semibold text-sm"
                    >
                      Use Now
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </motion.div>
          )}

          {activeTab === "categories" && (
            <div className="space-y-8">
              {categories.map((category, categoryIndex) => (
                <motion.div
                  key={category}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.1 * categoryIndex }}
                >
                  <h3 className="text-2xl font-bold text-white mb-4">{category} Tools</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {allTools.filter(tool => tool.category === category).map((tool) => (
                      <Card key={tool.id} className="bg-white/10 backdrop-blur-lg border border-white/20 hover:border-pink-400/50 transition-all duration-300">
                        <CardContent className="p-4">
                          <div className="flex items-center space-x-3">
                            <div className="w-10 h-10 rounded-full bg-gradient-to-r from-pink-500 to-purple-500 flex items-center justify-center">
                              <tool.icon className="w-5 h-5 text-white" />
                            </div>
                            <div className="flex-1">
                              <h4 className="text-white font-semibold">{tool.title}</h4>
                              <p className="text-gray-400 text-sm">{tool.description}</p>
                            </div>
                            <Button 
                              onClick={() => processImage(tool.id)}
                              disabled={processing || uploadedFiles.length === 0}
                              size="sm"
                              className="bg-gradient-to-r from-pink-500 to-purple-500 hover:from-pink-600 hover:to-purple-600"
                            >
                              Use
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </motion.div>
              ))}
            </div>
          )}
        </div>

        {/* Stats Section */}
        <motion.div
          className="mt-16 bg-white/5 backdrop-blur-lg rounded-xl border border-white/10 p-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1.0 }}
        >
          <h3 className="text-2xl font-bold text-white mb-6 text-center">Advanced Image Processing</h3>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-pink-400 mb-2">AI</div>
              <div className="text-white">Powered</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-400 mb-2">15+</div>
              <div className="text-white">Image Formats</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-pink-400 mb-2">4K</div>
              <div className="text-white">Resolution Support</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-400 mb-2">1-Click</div>
              <div className="text-white">Processing</div>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}