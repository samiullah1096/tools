import { motion } from "framer-motion";
import { Code, Database, Globe, Shield, Zap, FileCode, Terminal, GitBranch, Bug, Package } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

export default function DeveloperTools() {
  const { toast } = useToast();
  const [code, setCode] = useState("");
  const [result, setResult] = useState("");

  const developerTools = [
    {
      id: "json-formatter",
      icon: Code,
      title: "JSON Formatter",
      description: "Format, validate, and minify JSON data",
      category: "Data"
    },
    {
      id: "base64-encoder",
      icon: Database,
      title: "Base64 Encoder/Decoder",
      description: "Encode and decode Base64 strings",
      category: "Encoding"
    },
    {
      id: "url-encoder",
      icon: Globe,
      title: "URL Encoder/Decoder",
      description: "Encode and decode URLs for safe transmission",
      category: "Web"
    },
    {
      id: "hash-generator",
      icon: Shield,
      title: "Hash Generator",
      description: "Generate MD5, SHA1, SHA256, and other hashes",
      category: "Security"
    },
    {
      id: "regex-tester",
      icon: Zap,
      title: "Regex Tester",
      description: "Test and debug regular expressions",
      category: "Testing"
    },
    {
      id: "html-encoder",
      icon: FileCode,
      title: "HTML Encoder/Decoder",
      description: "Encode and decode HTML entities",
      category: "Web"
    },
    {
      id: "jwt-decoder",
      icon: Terminal,
      title: "JWT Decoder",
      description: "Decode and validate JSON Web Tokens",
      category: "Security"
    },
    {
      id: "color-picker",
      icon: GitBranch,
      title: "Color Picker",
      description: "Pick colors and convert between formats",
      category: "Design"
    },
    {
      id: "lorem-generator",
      icon: Bug,
      title: "Lorem Ipsum Generator",
      description: "Generate placeholder text for testing",
      category: "Content"
    },
    {
      id: "uuid-generator",
      icon: Package,
      title: "UUID Generator",
      description: "Generate unique identifiers (UUID/GUID)",
      category: "Utility"
    }
  ];

  const processCode = (toolId: string) => {
    let processed = "";
    
    switch (toolId) {
      case "json-formatter":
        try {
          const parsed = JSON.parse(code);
          processed = JSON.stringify(parsed, null, 2);
        } catch (error) {
          processed = "Invalid JSON format";
        }
        break;
        
      case "base64-encoder":
        try {
          processed = btoa(code);
        } catch (error) {
          processed = "Error encoding to Base64";
        }
        break;
        
      case "base64-decoder":
        try {
          processed = atob(code);
        } catch (error) {
          processed = "Invalid Base64 string";
        }
        break;
        
      case "url-encoder":
        processed = encodeURIComponent(code);
        break;
        
      case "url-decoder":
        try {
          processed = decodeURIComponent(code);
        } catch (error) {
          processed = "Invalid URL encoding";
        }
        break;
        
      case "html-encoder":
        processed = code
          .replace(/&/g, '&amp;')
          .replace(/</g, '&lt;')
          .replace(/>/g, '&gt;')
          .replace(/"/g, '&quot;')
          .replace(/'/g, '&#39;');
        break;
        
      case "html-decoder":
        processed = code
          .replace(/&amp;/g, '&')
          .replace(/&lt;/g, '<')
          .replace(/&gt;/g, '>')
          .replace(/&quot;/g, '"')
          .replace(/&#39;/g, "'");
        break;
        
      case "uuid-generator":
        processed = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
          const r = Math.random() * 16 | 0;
          const v = c == 'x' ? r : (r & 0x3 | 0x8);
          return v.toString(16);
        });
        break;
        
      case "lorem-generator":
        const loremText = "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.";
        const paragraphs = parseInt(code) || 3;
        processed = Array(paragraphs).fill(loremText).join('\n\n');
        break;
        
      default:
        processed = "Tool processing not implemented yet";
    }
    
    setResult(processed);
    toast({
      title: "Code processed successfully!",
      description: "Your code has been processed and is ready to copy.",
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-indigo-900 to-purple-900">
      {/* SEO Head equivalent */}
      <title>Developer Tools - JSON Formatter, Base64 Encoder, Regex Tester | ToolSuite Pro</title>
      
      {/* Hero Section */}
      <div className="relative pt-20 pb-16">
        <div className="absolute inset-0 bg-gradient-to-r from-indigo-600/20 to-purple-600/20 backdrop-blur-3xl"></div>
        <motion.div 
          className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <motion.h1 
            className="text-5xl md:text-7xl font-bold text-white mb-6"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            Developer <span className="bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent">Tools</span>
          </motion.h1>
          <motion.p 
            className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            Essential tools for developers. Format JSON, encode/decode data, test regex, 
            generate UUIDs, and more. All tools work offline and keep your data secure.
          </motion.p>
        </motion.div>
      </div>

      {/* Code Processor */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <motion.div 
          className="bg-white/10 backdrop-blur-lg rounded-xl border border-white/20 p-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
        >
          <h2 className="text-3xl font-bold text-white mb-6 text-center">Code Processor</h2>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <label className="block text-white mb-2">Input:</label>
              <Textarea
                value={code}
                onChange={(e) => setCode(e.target.value)}
                placeholder="Enter your code, JSON, URL, or text here..."
                className="min-h-[300px] bg-white/5 border-white/20 text-white font-mono"
              />
            </div>
            
            <div>
              <label className="block text-white mb-2">Output:</label>
              <Textarea
                value={result}
                readOnly
                placeholder="Processed result will appear here..."
                className="min-h-[300px] bg-white/5 border-white/20 text-white font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mt-6">
            {[
              { id: "json-formatter", label: "Format JSON" },
              { id: "base64-encoder", label: "Encode B64" },
              { id: "base64-decoder", label: "Decode B64" },
              { id: "url-encoder", label: "Encode URL" },
              { id: "url-decoder", label: "Decode URL" },
              { id: "html-encoder", label: "Encode HTML" },
              { id: "html-decoder", label: "Decode HTML" },
              { id: "uuid-generator", label: "Gen UUID" },
              { id: "lorem-generator", label: "Lorem" }
            ].map((tool) => (
              <Button
                key={tool.id}
                onClick={() => processCode(tool.id)}
                variant="outline"
                className="border-white/20 text-white hover:bg-white/10"
              >
                {tool.label}
              </Button>
            ))}
          </div>

          <div className="flex gap-4 mt-4">
            <Button
              onClick={() => navigator.clipboard.writeText(result)}
              className="bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600"
              disabled={!result}
            >
              Copy Result
            </Button>
            <Button
              onClick={() => {
                setCode("");
                setResult("");
              }}
              variant="outline"
              className="border-white/20 text-white hover:bg-white/10"
            >
              Clear All
            </Button>
          </div>
        </motion.div>
      </div>

      {/* Tools Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <motion.h2 
          className="text-3xl font-bold text-white mb-12 text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          All Developer Tools
        </motion.h2>
        
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1.0 }}
        >
          {developerTools.map((tool, index) => (
            <motion.div
              key={tool.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 * index }}
              whileHover={{ y: -5, scale: 1.02 }}
            >
              <Card className="bg-white/10 backdrop-blur-lg border border-white/20 hover:border-indigo-400/50 transition-all duration-300 h-full">
                <CardHeader className="text-center">
                  <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-r from-indigo-500 to-purple-500 flex items-center justify-center">
                    <tool.icon className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className="text-white text-xl">{tool.title}</CardTitle>
                  <CardDescription className="text-gray-300">
                    {tool.description}
                  </CardDescription>
                  <span className="text-xs text-indigo-400 bg-indigo-400/20 px-2 py-1 rounded-full">
                    {tool.category}
                  </span>
                </CardHeader>
                <CardContent>
                  <Button 
                    onClick={() => {
                      const element = document.querySelector('#code-processor');
                      element?.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="w-full bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600 text-white font-semibold"
                  >
                    Use Tool
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </div>
  );
}