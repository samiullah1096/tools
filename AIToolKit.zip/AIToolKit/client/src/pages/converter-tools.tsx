import { motion } from "framer-motion";
import { RefreshCw, FileImage, FileText, Music, Video, Code, Database, Palette, Zap, Download } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import UploadZone from "@/components/ui/upload-zone";

export default function ConverterTools() {
  const { toast } = useToast();

  const converterTools = [
    {
      id: "image-converter",
      icon: FileImage,
      title: "Image Converter",
      description: "Convert between JPG, PNG, WEBP, GIF, SVG, and more",
      formats: ["JPG", "PNG", "WEBP", "GIF", "SVG", "BMP", "TIFF"],
      category: "Image"
    },
    {
      id: "document-converter",
      icon: FileText,
      title: "Document Converter", 
      description: "Convert PDF, Word, Excel, PowerPoint, and text files",
      formats: ["PDF", "DOCX", "XLSX", "PPTX", "TXT", "RTF", "ODT"],
      category: "Document"
    },
    {
      id: "audio-converter",
      icon: Music,
      title: "Audio Converter",
      description: "Convert between MP3, WAV, FLAC, AAC, OGG, and more",
      formats: ["MP3", "WAV", "FLAC", "AAC", "OGG", "M4A", "WMA"],
      category: "Audio"
    },
    {
      id: "video-converter",
      icon: Video,
      title: "Video Converter",
      description: "Convert MP4, AVI, MOV, MKV, and other video formats",
      formats: ["MP4", "AVI", "MOV", "MKV", "WMV", "FLV", "WEBM"],
      category: "Video"
    },
    {
      id: "code-converter",
      icon: Code,
      title: "Code Converter",
      description: "Convert between programming languages and formats",
      formats: ["JSON", "XML", "YAML", "CSV", "SQL", "HTML", "CSS"],
      category: "Developer"
    },
    {
      id: "color-converter",
      icon: Palette,
      title: "Color Converter",
      description: "Convert between HEX, RGB, HSL, CMYK color formats",
      formats: ["HEX", "RGB", "HSL", "CMYK", "HSV", "LAB"],
      category: "Design"
    },
    {
      id: "unit-converter",
      icon: Zap,
      title: "Unit Converter",
      description: "Convert length, weight, temperature, currency, and more",
      formats: ["Length", "Weight", "Temperature", "Currency", "Time", "Data"],
      category: "Utility"
    },
    {
      id: "qr-generator",
      icon: Database,
      title: "QR Code Generator",
      description: "Generate QR codes for text, URLs, WiFi, and contacts",
      formats: ["Text", "URL", "WiFi", "Contact", "Email", "SMS"],
      category: "Generator"
    }
  ];

  const handleFileUpload = (files: File[]) => {
    toast({
      title: "Files uploaded successfully!",
      description: `${files.length} file(s) ready for conversion.`,
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900">
      {/* SEO Head equivalent */}
      <title>Free File Converter - Convert Images, Documents, Audio, Video Online | ToolSuite Pro</title>
      
      {/* Hero Section */}
      <div className="relative pt-20 pb-16">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20 backdrop-blur-3xl"></div>
        <motion.div 
          className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <motion.h1 
            className="text-5xl md:text-7xl font-bold text-white mb-6"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            File <span className="bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">Converter</span>
          </motion.h1>
          <motion.p 
            className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            Convert any file format instantly. Support for 300+ formats including images, documents, 
            audio, video, and more. Fast, secure, and completely free.
          </motion.p>
        </motion.div>
      </div>

      {/* Quick Convert Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <motion.div 
          className="bg-white/10 backdrop-blur-lg rounded-xl border border-white/20 p-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
        >
          <h2 className="text-3xl font-bold text-white mb-6 text-center">Quick Convert</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <UploadZone
              onFilesUploaded={handleFileUpload}
              accept="*/*"
              maxFiles={10}
              maxSize={100 * 1024 * 1024} // 100MB
            />
            <div className="space-y-4">
              <h3 className="text-xl font-semibold text-white">Conversion Options</h3>
              <div className="grid grid-cols-2 gap-2">
                {["JPG to PNG", "PDF to Word", "MP4 to MP3", "PNG to WEBP", "Excel to PDF", "WAV to MP3"].map((conversion) => (
                  <Button 
                    key={conversion}
                    variant="outline" 
                    className="border-white/20 text-white hover:bg-white/10 text-sm"
                  >
                    {conversion}
                  </Button>
                ))}
              </div>
              <Button className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white font-semibold">
                <RefreshCw className="w-4 h-4 mr-2" />
                Convert Files
              </Button>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Converter Tools Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-20">
        <motion.h2 
          className="text-3xl font-bold text-white mb-12 text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          All Converter Tools
        </motion.h2>
        
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1.0 }}
        >
          {converterTools.map((tool, index) => (
            <motion.div
              key={tool.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 * index }}
              whileHover={{ y: -5, scale: 1.02 }}
            >
              <Card className="bg-white/10 backdrop-blur-lg border border-white/20 hover:border-blue-400/50 transition-all duration-300 h-full">
                <CardHeader className="text-center">
                  <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-r from-blue-500 to-cyan-500 flex items-center justify-center">
                    <tool.icon className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className="text-white text-lg">{tool.title}</CardTitle>
                  <CardDescription className="text-gray-300 text-sm">
                    {tool.description}
                  </CardDescription>
                  <span className="text-xs text-blue-400 bg-blue-400/20 px-2 py-1 rounded-full">
                    {tool.category}
                  </span>
                </CardHeader>
                <CardContent>
                  <div className="mb-4">
                    <p className="text-xs text-gray-400 mb-2">Supported formats:</p>
                    <div className="flex flex-wrap gap-1">
                      {tool.formats.slice(0, 4).map((format) => (
                        <span key={format} className="text-xs bg-gray-600/50 text-gray-300 px-2 py-1 rounded">
                          {format}
                        </span>
                      ))}
                      {tool.formats.length > 4 && (
                        <span className="text-xs text-blue-400">+{tool.formats.length - 4} more</span>
                      )}
                    </div>
                  </div>
                  <Button 
                    className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white font-semibold"
                    onClick={() => {
                      const element = document.querySelector('#quick-convert');
                      element?.scrollIntoView({ behavior: 'smooth' });
                    }}
                  >
                    Convert Now
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>

        {/* Popular Conversions */}
        <motion.div 
          className="mt-16 bg-white/5 backdrop-blur-lg rounded-xl border border-white/10 p-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1.2 }}
        >
          <h3 className="text-2xl font-bold text-white mb-6 text-center">Popular Conversions</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {[
              "PDF to Word", "JPG to PNG", "MP4 to MP3", "PNG to JPG",
              "Word to PDF", "Excel to PDF", "MOV to MP4", "WAV to MP3",
              "HEIC to JPG", "WEBP to PNG", "AVI to MP4", "FLAC to MP3"
            ].map((conversion) => (
              <Button 
                key={conversion}
                variant="ghost" 
                className="text-white hover:bg-white/10 text-sm h-auto py-3"
              >
                {conversion}
              </Button>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}