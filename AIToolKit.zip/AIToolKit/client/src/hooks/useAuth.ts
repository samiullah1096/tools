import { useState, useEffect } from 'react';

interface AuthState {
  isAuthenticated: boolean;
  token: string | null;
  admin: {
    id: string;
    username: string;
    email: string;
    role: string;
  } | null;
}

export function useAuth() {
  const [authState, setAuthState] = useState<AuthState>({
    isAuthenticated: false,
    token: null,
    admin: null
  });

  useEffect(() => {
    const token = localStorage.getItem('adminToken');
    if (token) {
      setAuthState(prev => ({ ...prev, isAuthenticated: true, token }));
    }
  }, []);

  const login = async (username: string, password: string): Promise<boolean> => {
    try {
      const response = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });

      if (response.ok) {
        const data = await response.json();
        localStorage.setItem('adminToken', data.token);
        setAuthState({
          isAuthenticated: true,
          token: data.token,
          admin: data.admin
        });
        return true;
      }
      return false;
    } catch {
      return false;
    }
  };

  const logout = () => {
    localStorage.removeItem('adminToken');
    setAuthState({
      isAuthenticated: false,
      token: null,
      admin: null
    });
  };

  return {
    ...authState,
    login,
    logout
  };
}