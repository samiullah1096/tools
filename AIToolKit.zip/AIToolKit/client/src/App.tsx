import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import PDFTools from "@/pages/pdf-tools-enhanced";
import AudioTools from "@/pages/audio-tools-enhanced";
import ImageTools from "@/pages/image-tools-enhanced";
import TextTools from "@/pages/text-tools";
import ConverterTools from "@/pages/converter-tools";
import ProductivityTools from "@/pages/productivity-tools";
import AdminPortal from "@/pages/admin-portal";
import Navbar from "@/components/ui/navbar";
import AnimatedBackground from "@/components/ui/animated-background";
import Footer from "@/components/ui/footer";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/pdf-tools" component={PDFTools} />
      <Route path="/audio-tools" component={AudioTools} />
      <Route path="/image-tools" component={ImageTools} />
      <Route path="/text-tools" component={TextTools} />
      <Route path="/converter-tools" component={ConverterTools} />
      <Route path="/productivity-tools" component={ProductivityTools} />
      <Route path="/admin" component={AdminPortal} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 text-white overflow-x-hidden">
          <AnimatedBackground />
          <Navbar />
          <main className="relative z-10 pt-20">
            <Router />
          </main>
          <Footer />
          <Toaster />
        </div>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
