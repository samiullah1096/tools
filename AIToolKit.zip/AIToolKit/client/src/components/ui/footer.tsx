import { motion } from "framer-motion";
import { Link } from "wouter";
import { Box, Twitter, Facebook, Linkedin } from "lucide-react";
import { Button } from "./button";
import { Input } from "./input";

export default function Footer() {
  return (
    <footer className="relative z-10 py-20 border-t border-white/10">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-6">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-indigo-500 to-violet-500 flex items-center justify-center">
                <Box className="text-white text-xl" />
              </div>
              <span className="text-xl font-bold text-gradient">ToolSuite Pro</span>
            </div>
            <p className="text-slate-400 mb-6">The ultimate digital toolkit for professionals and creators.</p>
            <div className="flex space-x-4">
              <motion.a 
                href="#" 
                className="w-10 h-10 bg-slate-800 rounded-lg flex items-center justify-center hover:bg-indigo-500 transition-colors"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
              >
                <Twitter className="w-4 h-4" />
              </motion.a>
              <motion.a 
                href="#" 
                className="w-10 h-10 bg-slate-800 rounded-lg flex items-center justify-center hover:bg-indigo-500 transition-colors"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
              >
                <Facebook className="w-4 h-4" />
              </motion.a>
              <motion.a 
                href="#" 
                className="w-10 h-10 bg-slate-800 rounded-lg flex items-center justify-center hover:bg-indigo-500 transition-colors"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
              >
                <Linkedin className="w-4 h-4" />
              </motion.a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-6">Tools</h3>
            <ul className="space-y-3 text-slate-400">
              <li><Link href="/pdf-tools" className="hover:text-white transition-colors">PDF Tools</Link></li>
              <li><Link href="/audio-tools" className="hover:text-white transition-colors">Audio Tools</Link></li>
              <li><Link href="/image-tools" className="hover:text-white transition-colors">Image Tools</Link></li>
              <li><Link href="/ai-tools" className="hover:text-white transition-colors">AI Tools</Link></li>
              <li><Link href="/video-tools" className="hover:text-white transition-colors">Video Tools</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-6">Company</h3>
            <ul className="space-y-3 text-slate-400">
              <li><a href="#" className="hover:text-white transition-colors">About Us</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Terms of Service</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Contact</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-6">Newsletter</h3>
            <p className="text-slate-400 mb-4">Stay updated with our latest features and tools.</p>
            <div className="flex">
              <Input 
                type="email" 
                className="flex-1 bg-slate-800 border-slate-600 rounded-l-lg text-white" 
                placeholder="Enter email" 
              />
              <Button className="px-6 py-2 bg-gradient-to-r from-indigo-500 to-violet-500 rounded-r-lg font-medium hover:shadow-lg transition-all duration-300 rounded-l-none">
                Subscribe
              </Button>
            </div>
          </div>
        </div>
        
        <div className="border-t border-white/10 mt-12 pt-8 text-center text-slate-400">
          <p>&copy; 2024 ToolSuite Pro. All rights reserved. Built with excellence and innovation.</p>
        </div>
      </div>
    </footer>
  );
}
