import { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, FileText } from 'lucide-react';
import { motion } from 'framer-motion';

interface UploadZoneProps {
  onFilesUploaded: (files: File[]) => void;
  accept?: string;
  maxFiles?: number;
  maxSize?: number;
  className?: string;
}

export default function UploadZone({
  onFilesUploaded,
  accept = "*/*",
  maxFiles = 5,
  maxSize = 50 * 1024 * 1024, // 50MB default
  className = ""
}: UploadZoneProps) {
  const onDrop = useCallback((acceptedFiles: File[]) => {
    onFilesUploaded(acceptedFiles);
  }, [onFilesUploaded]);

  const {
    getRootProps,
    getInputProps,
    isDragActive
  } = useDropzone({
    onDrop,
    accept: accept === "*/*" ? undefined : {
      'application/pdf': ['.pdf'],
      'image/*': ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp', '.svg'],
      'audio/*': ['.mp3', '.wav', '.flac', '.aac', '.ogg', '.m4a', '.wma'],
      'text/*': ['.txt', '.csv', '.json', '.xml', '.html', '.css', '.js', '.ts'],
      'video/*': ['.mp4', '.avi', '.mov', '.wmv', '.flv', '.webm', '.mkv']
    },
    maxFiles,
    maxSize
  });

  return (
    <div className={`w-full ${className}`}>
      <div
        {...getRootProps()}
        className={`
          relative border-2 border-dashed rounded-xl p-8 text-center cursor-pointer
          transition-all duration-300 min-h-[200px] flex flex-col items-center justify-center
          ${isDragActive 
            ? 'border-blue-400 bg-blue-400/10 scale-105' 
            : 'border-gray-400 bg-gray-400/5 hover:border-blue-400 hover:bg-blue-400/5'
          }
        `}
      >
        <input {...getInputProps()} />
        
        <motion.div
          className="w-16 h-16 mx-auto mb-4 rounded-full bg-blue-500/20 flex items-center justify-center"
          animate={{ 
            rotate: isDragActive ? 360 : 0,
            scale: isDragActive ? 1.2 : 1 
          }}
          transition={{ duration: 0.3 }}
        >
          <Upload className="w-8 h-8 text-blue-400" />
        </motion.div>

        <div className="space-y-2">
          <h3 className="text-xl font-semibold text-white">
            {isDragActive ? 'Drop files here' : 'Upload your files'}
          </h3>
          <p className="text-gray-300">
            Drag & drop files here, or click to select
          </p>
          <p className="text-sm text-gray-400">
            Max {maxFiles} files, up to {Math.round(maxSize / 1024 / 1024)}MB each
          </p>
        </div>

        {/* Animated background effect */}
        {isDragActive && (
          <motion.div
            className="absolute inset-0 rounded-xl bg-gradient-to-r from-blue-400/20 to-purple-400/20"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          />
        )}
      </div>
    </div>
  );
}