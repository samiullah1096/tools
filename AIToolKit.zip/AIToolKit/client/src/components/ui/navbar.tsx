import { useState } from "react";
import { Link, useLocation } from "wouter";
import { motion } from "framer-motion";
import { Box, Menu, X } from "lucide-react";
import { Button } from "./button";
import AdSlot from "./ad-slot";

const navItems = [
  { path: "/", label: "Home" },
  { path: "/pdf-tools", label: "PDF Tools" },
  { path: "/audio-tools", label: "Audio Tools" },
  { path: "/image-tools", label: "Image Tools" },
  { path: "/text-tools", label: "Text Tools" },
  { path: "/converter-tools", label: "Converter" },
  { path: "/productivity-tools", label: "Productivity" },
];

export default function Navbar() {
  const [location] = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="fixed top-0 w-full z-50 glass-morphism border-b border-white/10">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <Link href="/">
            <motion.div 
              className="flex items-center space-x-2 cursor-pointer"
              whileHover={{ scale: 1.05 }}
              transition={{ type: "spring", stiffness: 400, damping: 10 }}
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-indigo-500 to-violet-500 flex items-center justify-center animate-glow">
                <Box className="text-white text-xl" />
              </div>
              <span className="text-2xl font-bold text-gradient">ToolSuite Pro</span>
            </motion.div>
          </Link>
          
          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <Link key={item.path} href={item.path}>
                <motion.div
                  className={`nav-item text-sm font-medium cursor-pointer ${
                    location === item.path ? "text-indigo-400" : "hover:text-indigo-400"
                  }`}
                  whileHover={{ y: -2 }}
                  transition={{ type: "spring", stiffness: 300, damping: 10 }}
                >
                  {item.label}
                </motion.div>
              </Link>
            ))}
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="hidden lg:block">
              <AdSlot slotId="navbar-banner" position="header" size="small" />
            </div>
            <Button className="hidden md:block px-6 py-2 bg-gradient-to-r from-indigo-500 to-violet-500 rounded-full text-sm font-medium hover:shadow-lg hover:scale-105 transition-all duration-300 animate-glow">
              Get Started
            </Button>
            <button 
              className="md:hidden text-white"
              onClick={() => setIsOpen(!isOpen)}
            >
              {isOpen ? <X className="text-xl" /> : <Menu className="text-xl" />}
            </button>
          </div>
        </div>

        {/* Mobile menu */}
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="md:hidden mt-4 pb-4 border-t border-white/10"
          >
            <div className="flex flex-col space-y-4 pt-4">
              {navItems.map((item) => (
                <Link key={item.path} href={item.path}>
                  <div
                    className={`text-sm font-medium cursor-pointer ${
                      location === item.path ? "text-indigo-400" : "hover:text-indigo-400"
                    }`}
                    onClick={() => setIsOpen(false)}
                  >
                    {item.label}
                  </div>
                </Link>
              ))}
              <Button className="w-full mt-4 px-6 py-2 bg-gradient-to-r from-indigo-500 to-violet-500 rounded-full text-sm font-medium">
                Get Started
              </Button>
            </div>
          </motion.div>
        )}
      </div>
    </nav>
  );
}
