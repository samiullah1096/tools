import { motion } from "framer-motion";
import { ReactNode } from "react";

interface ToolCardProps {
  icon: ReactNode;
  title: string;
  description: string;
  gradient: string;
  children: ReactNode;
  delay?: number;
}

export default function ToolCard({ 
  icon, 
  title, 
  description, 
  gradient, 
  children, 
  delay = 0 
}: ToolCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay, ease: "easeOut" }}
      className="tool-card glass-morphism rounded-2xl p-8 hover:shadow-2xl"
    >
      <div className={`w-16 h-16 ${gradient} rounded-xl flex items-center justify-center mb-6 animate-float`}>
        {icon}
      </div>
      <h3 className="text-2xl font-bold mb-4">{title}</h3>
      <p className="text-slate-300 mb-6">{description}</p>
      {children}
    </motion.div>
  );
}
