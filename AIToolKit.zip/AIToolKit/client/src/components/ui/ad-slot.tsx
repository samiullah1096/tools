import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Card } from '@/components/ui/card';

interface AdSlotProps {
  slotId: string;
  position: 'header' | 'sidebar' | 'content' | 'footer' | 'modal';
  size: 'small' | 'medium' | 'large' | 'banner' | 'skyscraper' | 'square';
  className?: string;
}

export default function AdSlot({ slotId, position, size, className = "" }: AdSlotProps) {
  const [adData, setAdData] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Fetch ad data for this slot from backend
    const fetchAd = async () => {
      try {
        const response = await fetch(`/api/ads/${slotId}`);
        if (response.ok) {
          const ad = await response.json();
          setAdData(ad);
        }
      } catch (error) {
        console.log('No ad data for slot:', slotId);
      }
      setIsLoading(false);
    };

    fetchAd();
  }, [slotId]);

  const getSizeClasses = () => {
    switch (size) {
      case 'small':
        return 'w-[300px] h-[150px]';
      case 'medium':
        return 'w-[300px] h-[250px]';
      case 'large':
        return 'w-[336px] h-[280px]';
      case 'banner':
        return 'w-full h-[90px] max-w-[728px]';
      case 'skyscraper':
        return 'w-[160px] h-[600px]';
      case 'square':
        return 'w-[250px] h-[250px]';
      default:
        return 'w-[300px] h-[250px]';
    }
  };

  if (isLoading) {
    return (
      <motion.div 
        className={`${getSizeClasses()} ${className} bg-gray-800/30 border border-gray-600/30 rounded-lg flex items-center justify-center`}
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.5 }}
      >
        <div className="text-gray-500 text-sm">Loading Ad...</div>
      </motion.div>
    );
  }

  if (!adData) {
    return (
      <motion.div 
        className={`${getSizeClasses()} ${className} bg-gray-800/20 border border-gray-600/20 rounded-lg flex items-center justify-center`}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
      >
        <div className="text-gray-600 text-xs text-center p-2">Advertisement Space</div>
      </motion.div>
    );
  }

  const renderAd = () => {
    switch (adData.provider) {
      case 'google':
        return (
          <div
            className="w-full h-full"
            dangerouslySetInnerHTML={{ __html: adData.code }}
          />
        );
      case 'custom':
        return (
          <motion.a
            href={adData.clickUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="block w-full h-full rounded-lg overflow-hidden"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            {adData.imageUrl ? (
              <img
                src={adData.imageUrl}
                alt={adData.title || "Advertisement"}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center text-white p-4">
                <div className="text-center">
                  <h3 className="font-bold text-lg mb-2">{adData.title}</h3>
                  <p className="text-sm opacity-90">{adData.description}</p>
                </div>
              </div>
            )}
          </motion.a>
        );
      case 'html':
        return (
          <div
            className="w-full h-full"
            dangerouslySetInnerHTML={{ __html: adData.htmlContent }}
          />
        );
      default:
        return (
          <div className="w-full h-full bg-gradient-to-br from-gray-700 to-gray-800 flex items-center justify-center text-white p-4">
            <div className="text-center">
              <h3 className="font-bold text-lg mb-2">{adData.title || "Your Ad Here"}</h3>
              <p className="text-sm opacity-90">{adData.description || "Promote your business"}</p>
            </div>
          </div>
        );
    }
  };

  return (
    <motion.div
      className={`${getSizeClasses()} ${className} relative`}
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="w-full h-full overflow-hidden bg-white/5 border-white/10">
        {renderAd()}
        {/* Ad Label */}
        <div className="absolute top-1 right-1 bg-black/50 text-white text-xs px-2 py-1 rounded">
          Ad
        </div>
      </Card>
    </motion.div>
  );
}