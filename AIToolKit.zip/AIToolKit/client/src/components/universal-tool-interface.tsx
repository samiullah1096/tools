import { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Upload, Download, Settings, Share, FileText, Volume2, Image as ImageIcon, Type, RotateCcw, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';
import AdSlot from '@/components/ui/ad-slot';

interface ToolConfig {
  id: string;
  name: string;
  category: 'pdf' | 'audio' | 'image' | 'text' | 'converter' | 'productivity';
  icon: React.ReactNode;
  acceptedFiles: string[];
  description: string;
  features: string[];
}

interface UniversalToolInterfaceProps {
  isOpen: boolean;
  onClose: () => void;
  tool?: ToolConfig;
}

export default function UniversalToolInterface({ isOpen, onClose, tool }: UniversalToolInterfaceProps) {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState('upload');
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);
  const [files, setFiles] = useState<File[]>([]);
  const [results, setResults] = useState<any[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!tool) return null;

  const handleFileUpload = async (selectedFiles: FileList) => {
    const fileArray = Array.from(selectedFiles);
    setFiles(fileArray);
    setActiveTab('process');

    // Simulate upload progress
    for (let i = 0; i <= 100; i += 10) {
      setUploadProgress(i);
      await new Promise(resolve => setTimeout(resolve, 100));
    }

    toast({
      title: 'Files uploaded successfully!',
      description: `${fileArray.length} file(s) ready for processing.`
    });
  };

  const handleProcessFiles = async () => {
    if (!files.length) {
      toast({
        title: 'No files selected',
        description: 'Please upload files first.',
        variant: 'destructive'
      });
      return;
    }

    setIsProcessing(true);
    
    try {
      // Simulate processing for demo
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      // Create mock results
      const mockResults = files.map((file, index) => ({
        id: `result-${index}`,
        originalName: file.name,
        processedName: `processed_${file.name}`,
        size: file.size,
        status: 'completed',
        downloadUrl: '#'
      }));

      setResults(mockResults);
      setActiveTab('results');
      
      toast({
        title: 'Processing completed!',
        description: `${files.length} file(s) processed successfully.`
      });
    } catch (error) {
      toast({
        title: 'Processing failed',
        description: 'An error occurred while processing your files.',
        variant: 'destructive'
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'pdf': return <FileText className="w-5 h-5" />;
      case 'audio': return <Volume2 className="w-5 h-5" />;
      case 'image': return <ImageIcon className="w-5 h-5" />;
      case 'text': return <Type className="w-5 h-5" />;
      case 'converter': return <RotateCcw className="w-5 h-5" />;
      case 'productivity': return <Zap className="w-5 h-5" />;
      default: return <FileText className="w-5 h-5" />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'pdf': return 'from-red-500 to-pink-500';
      case 'audio': return 'from-purple-500 to-violet-500';
      case 'image': return 'from-blue-500 to-cyan-500';
      case 'text': return 'from-green-500 to-emerald-500';
      case 'converter': return 'from-yellow-500 to-orange-500';
      case 'productivity': return 'from-indigo-500 to-purple-500';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
        >
          <motion.div
            className="w-full max-w-5xl bg-gradient-to-br from-gray-900/95 via-purple-900/95 to-indigo-900/95 border border-white/10 rounded-2xl shadow-2xl backdrop-blur-md"
            initial={{ opacity: 0, scale: 0.8, y: 50 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 50 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            onClick={e => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-center justify-between p-6 border-b border-white/10">
              <div className="flex items-center space-x-4">
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-r ${getCategoryColor(tool.category)} flex items-center justify-center`}>
                  {getCategoryIcon(tool.category)}
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-white">{tool.name}</h2>
                  <p className="text-gray-300 text-sm capitalize">{tool.category} Tool</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-4">
                {/* Header Ad Slot */}
                <AdSlot slotId="modal-header" position="modal" size="small" />
                
                <Button
                  onClick={onClose}
                  variant="outline"
                  size="sm"
                  className="border-white/20 text-white hover:bg-white/10"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Content */}
            <div className="flex h-[600px]">
              {/* Sidebar with Ad */}
              <div className="w-64 border-r border-white/10 p-6 space-y-4">
                <div>
                  <h3 className="text-lg font-semibold text-white mb-2">Tool Features</h3>
                  <ul className="space-y-2 text-sm text-gray-300">
                    {tool.features.map((feature, index) => (
                      <li key={index} className="flex items-center">
                        <div className="w-2 h-2 bg-green-400 rounded-full mr-2" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
                
                <div>
                  <h4 className="text-md font-medium text-white mb-2">Supported Files</h4>
                  <div className="flex flex-wrap gap-1">
                    {tool.acceptedFiles.map((format, index) => (
                      <span
                        key={index}
                        className="px-2 py-1 bg-white/10 rounded text-xs text-gray-300"
                      >
                        {format.toUpperCase()}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Sidebar Ad Slot */}
                <div className="pt-4">
                  <AdSlot slotId="modal-sidebar" position="modal" size="square" />
                </div>
              </div>

              {/* Main Content */}
              <div className="flex-1 p-6">
                <Tabs value={activeTab} onValueChange={setActiveTab}>
                  <TabsList className="grid w-full grid-cols-3 bg-white/5">
                    <TabsTrigger value="upload" className="data-[state=active]:bg-white/10">
                      <Upload className="w-4 h-4 mr-2" />
                      Upload
                    </TabsTrigger>
                    <TabsTrigger value="process" className="data-[state=active]:bg-white/10">
                      <Settings className="w-4 h-4 mr-2" />
                      Process
                    </TabsTrigger>
                    <TabsTrigger value="results" className="data-[state=active]:bg-white/10">
                      <Download className="w-4 h-4 mr-2" />
                      Results
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="upload" className="mt-6">
                    <Card className="bg-white/5 border-white/10">
                      <CardContent className="p-8">
                        <div
                          className="border-2 border-dashed border-white/20 rounded-lg p-12 text-center hover:border-white/40 transition-colors cursor-pointer"
                          onClick={() => fileInputRef.current?.click()}
                        >
                          <Upload className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                          <h3 className="text-xl font-semibold text-white mb-2">Upload Your Files</h3>
                          <p className="text-gray-300 mb-4">{tool.description}</p>
                          <Button className={`bg-gradient-to-r ${getCategoryColor(tool.category)}`}>
                            Choose Files
                          </Button>
                          <input
                            ref={fileInputRef}
                            type="file"
                            multiple
                            accept={tool.acceptedFiles.map(f => `.${f}`).join(',')}
                            onChange={(e) => e.target.files && handleFileUpload(e.target.files)}
                            className="hidden"
                          />
                        </div>

                        {files.length > 0 && (
                          <div className="mt-6">
                            <h4 className="text-lg font-semibold text-white mb-3">Selected Files:</h4>
                            <div className="space-y-2">
                              {files.map((file, index) => (
                                <div key={index} className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                                  <div>
                                    <p className="text-white font-medium">{file.name}</p>
                                    <p className="text-gray-400 text-sm">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
                                  </div>
                                  <div className="text-green-400">✓</div>
                                </div>
                              ))}
                            </div>
                            <Progress value={uploadProgress} className="mt-4" />
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="process" className="mt-6">
                    <Card className="bg-white/5 border-white/10">
                      <CardContent className="p-8 text-center">
                        <div className={`w-20 h-20 rounded-full bg-gradient-to-r ${getCategoryColor(tool.category)} flex items-center justify-center mx-auto mb-6`}>
                          {getCategoryIcon(tool.category)}
                        </div>
                        
                        <h3 className="text-2xl font-bold text-white mb-4">Process Your Files</h3>
                        <p className="text-gray-300 mb-6">
                          Ready to process {files.length} file(s) with {tool.name}
                        </p>

                        {isProcessing ? (
                          <div className="space-y-4">
                            <div className="flex items-center justify-center space-x-2">
                              <div className="w-4 h-4 bg-purple-500 rounded-full animate-bounce" />
                              <div className="w-4 h-4 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                              <div className="w-4 h-4 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                            </div>
                            <p className="text-white">Processing files...</p>
                          </div>
                        ) : (
                          <Button
                            onClick={handleProcessFiles}
                            className={`px-8 py-3 bg-gradient-to-r ${getCategoryColor(tool.category)} text-lg font-semibold`}
                            disabled={files.length === 0}
                          >
                            <Zap className="w-5 h-5 mr-2" />
                            Start Processing
                          </Button>
                        )}
                      </CardContent>
                    </Card>
                  </TabsContent>

                  <TabsContent value="results" className="mt-6">
                    <Card className="bg-white/5 border-white/10">
                      <CardContent className="p-8">
                        {results.length > 0 ? (
                          <div>
                            <h3 className="text-xl font-bold text-white mb-6">Processing Complete!</h3>
                            <div className="space-y-3">
                              {results.map((result, index) => (
                                <div key={index} className="flex items-center justify-between p-4 bg-white/5 rounded-lg">
                                  <div>
                                    <p className="text-white font-medium">{result.processedName}</p>
                                    <p className="text-gray-400 text-sm">Original: {result.originalName}</p>
                                  </div>
                                  <div className="flex items-center space-x-2">
                                    <Button size="sm" className="bg-green-600 hover:bg-green-700">
                                      <Download className="w-4 h-4 mr-1" />
                                      Download
                                    </Button>
                                    <Button size="sm" variant="outline" className="border-white/20 text-white hover:bg-white/10">
                                      <Share className="w-4 h-4" />
                                    </Button>
                                  </div>
                                </div>
                              ))}
                            </div>
                            <div className="flex justify-center mt-6">
                              <Button className="bg-purple-600 hover:bg-purple-700 px-8">
                                Download All Files
                              </Button>
                            </div>
                          </div>
                        ) : (
                          <div className="text-center py-12">
                            <Download className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                            <h3 className="text-xl font-semibold text-white mb-2">No Results Yet</h3>
                            <p className="text-gray-400">Process your files to see results here</p>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </TabsContent>
                </Tabs>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}